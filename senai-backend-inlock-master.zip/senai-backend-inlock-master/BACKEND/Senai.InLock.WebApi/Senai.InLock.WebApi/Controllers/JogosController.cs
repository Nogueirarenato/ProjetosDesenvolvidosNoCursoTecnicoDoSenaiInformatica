﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.InLock.WebApi.Domains;
using Senai.InLock.WebApi.Interfaces;
using Senai.InLock.WebApi.Repositories;

namespace Senai.InLock.WebApi.Controllers
{

    [Produces("Application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class JogosController : ControllerBase
    {
        private JogoRepository JogoRepository { get; set; }

        public JogosController()
        {
            JogoRepository = new JogoRepository();
        }
       // [Authorize]
        [HttpGet]
        public IEnumerable<JogoDomain> Get()

                {
            return JogoRepository.Listar();
                }

        //[Authorize(Roles = "ADMINISTRADOR")]
        [HttpPost]
        public IActionResult Post(JogoDomain jogo)
        {
           

            JogoRepository.Cadastrar(jogo);
            return Ok();
        }


    }
}