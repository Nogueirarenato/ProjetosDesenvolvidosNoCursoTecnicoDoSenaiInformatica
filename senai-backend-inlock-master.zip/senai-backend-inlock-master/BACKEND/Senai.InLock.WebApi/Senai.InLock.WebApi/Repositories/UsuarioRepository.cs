﻿using Senai.InLock.WebApi.Domains;
using Senai.InLock.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.InLock.WebApi.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private string StringConexao = "Server=DESKTOP-DQ5PRKU; Database=InLock_Games_Manha;integrated security=true";

        public UsuarioDomain BuscarPorEmailSenha(string email, string senha)
        {
            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                string QuerySelect = "SELECT USUARIOID, EMAIL, SENHA, TIPOUSUARIO FROM USUARIOS " +
                                                         "WHERE EMAIL = @EMAIL AND SENHA =@SENHA";

                using (SqlCommand cmd = new SqlCommand(QuerySelect, con))
                {
                    cmd.Parameters.AddWithValue("@EMAIL", email);
                    cmd.Parameters.AddWithValue("@SENHA", senha);

                    con.Open();

                    SqlDataReader sdr = cmd.ExecuteReader();

                    if (sdr.HasRows)
                    {
                        UsuarioDomain usuario = new UsuarioDomain();

                        while (sdr.Read())
                        {
                            usuario.Id = Convert.ToInt32(sdr["USUARIOID"]);
                            usuario.Nome = sdr["USUARIOID"].ToString();
                            usuario.Email = sdr["EMAIL"].ToString();
                            usuario.TipoUsuario = sdr["TIPOUSUARIO"].ToString();
                        }

                        return usuario;
                    }
                }
                return null;
            }

        }

        public void Cadastrar(UsuarioDomain usuario)
        {
            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                string QueryInsert = "INSERT INTO USUARIOS(USUARIOID, EMAIL,SENHA,TIPOUSUARIO) VALUES" +
                                                            "(@NOME, @EMAIL,@SENHA,@TIPO_USUARIO)";

                using (SqlCommand cmd = new SqlCommand(QueryInsert, con))
                {
                    cmd.Parameters.AddWithValue("@NOME", usuario.Nome);
                    cmd.Parameters.AddWithValue("@EMAIL", usuario.Email);
                    cmd.Parameters.AddWithValue("@SENHA", usuario.Senha);
                    cmd.Parameters.AddWithValue("@TIPO_USUARIO", usuario.TipoUsuario);

                    con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
