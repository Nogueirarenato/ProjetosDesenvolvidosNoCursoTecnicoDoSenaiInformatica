﻿using Senai.InLock.WebApi.Domains;
using Senai.InLock.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Senai.InLock.WebApi.Repositories
{
    public class JogoRepository : IJogoRepository
    {
        private string StringConexao = "Server=Desktop-dq5prku; Database=InLock_Games_Manha; integrated security=true";

        public void Cadastrar(JogoDomain jogo)
        {
            string Query = "INSERT INTO JOGOS(NomeJogo, DescricaoJogo, DataLancamento, Valor, EstudioId) VALUES(@NomeJogo, @DescricaoJogo, @DataLancamento, @Valor, @EstudioId);";

            
            using (SqlConnection con = new SqlConnection(StringConexao))
                { using (SqlCommand cmd = new SqlCommand(Query, con))
                    

                    {
                    cmd.Parameters.AddWithValue("@NomeJogo", jogo.NomeJogo);
                    cmd.Parameters.AddWithValue("@DescricaoJogo", jogo.DescricaoJogo);
                    cmd.Parameters.AddWithValue("@DataLancamento", jogo.DataLancamento);
                    cmd.Parameters.AddWithValue("@Valor", jogo.Valor);
                    cmd.Parameters.AddWithValue("@EstudioId", jogo.EstudioId);

                    con.Open();

                    cmd.ExecuteNonQuery();

                }

                }
        }

        public List<JogoDomain> Listar()
        {
            string Query = "SELECT JOGOID, NOMEJOGO, DESCRICAOJOGO, DATALANCAMENTO, VALOR, NOMEESTUDIO FROM JOGOS LEFT JOIN ESTUDIOS ON	JOGOS.JogoId = ESTUDIOS.EstudioId;";
            List<JogoDomain> jogos = new List<JogoDomain>();

            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                con.Open();

                SqlDataReader sdr;

                using (SqlCommand cmd = new SqlCommand(Query, con))
                {
                    sdr = cmd.ExecuteReader();

                    while (sdr.Read())
                    {                          
                        
                        
                        

                        JogoDomain jogo = new JogoDomain
                        {
                            JogoId = Convert.ToInt32(sdr["JOGOID"]),

                            NomeJogo = sdr["NOMEJOGO"].ToString(),

                            DescricaoJogo= sdr["DESCRICAOJOGO"].ToString(),

                            DataLancamento = Convert.ToDateTime(sdr["DATALANCAMENTO"]),

                            Valor = Convert.ToDecimal(sdr["VALOR"]),

                            NomeEstudio = sdr["NOMEESTUDIO"].ToString()

                       
                        };
                        jogos.Add(jogo);
                    }

                }
            }


                return jogos;

        }
    }
}
