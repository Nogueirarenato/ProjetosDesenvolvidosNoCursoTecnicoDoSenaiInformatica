﻿using System;

namespace Senai.Projetos.For.Exercicioextra03
{
    class Program
 {
        static void Main(string[] args)
        {


//             DESAFIO DO QUADRADO. 

// Receba do usuário um número inteiro chamado de base e outro chamado de altura. Desenhar um quadrado utilizando o caractere “*” na tela utilizando com base os números recebidos. 

// EXEMPLO: 

// base = 4; 

// altura = 3; 

// SAÍDA: 

// **** 

// **** 

// **** 

        int altura; 
        int baze;
        int cont1;
        int cont2;

        System.Console.WriteLine("Entre com o valor da base: ");
        baze=int.Parse(Console.ReadLine());
        System.Console.WriteLine("Entre com o valor da altura: ");
        altura=int.Parse(Console.ReadLine());


        for(cont2=0; cont2<altura; cont2++){
            for(cont1=0; cont1<baze; cont1++)
            {Console.Write("*");
             if(cont1==baze-1)System.Console.WriteLine("\n");}
       
        }
        
        }
    }
}