﻿using System;

namespace Senai.Projetos.For.Exercicio05
{
    class Program
    {
        static void Main(string[] args)
        {
         
//             Ex. 5 

// Receba uma quantidade n de usuários, em seguida, receba n idades. Exiba para o usuário quantos das idades inseridas: 

// São menores de idade (Considere, menor de idade: idade < 18); 

// São maiores de idade; 

// Possuem mais de 50 anos de idade; 

// Quebra de Página


    int n, Idade, MenorIdade, MaiorIdade, Idoso, cont;
    Idade = MenorIdade = MaiorIdade = Idoso = cont=0;
    System.Console.WriteLine("Entre com o número de usuarios:");
    n=int.Parse(Console.ReadLine());

        for(cont=1; cont <=n ; cont++)
        {
        System.Console.WriteLine("Entre com a idade do usuário nº "+ cont);
        Idade=int.Parse(Console.ReadLine());

        if(Idade<18)MenorIdade++;
        if(Idade>=18)MaiorIdade++;
        if(Idade>50)Idoso++;
        }


        System.Console.WriteLine("Dos usuários "+ MenorIdade+ " são menores de idade.");
        System.Console.WriteLine("Dos usuários "+ MaiorIdade+ " são maiores de idade.");
        System.Console.WriteLine("Dos usuários "+ Idoso+ " tem mais de 50 anos.");
        }
    }
}
