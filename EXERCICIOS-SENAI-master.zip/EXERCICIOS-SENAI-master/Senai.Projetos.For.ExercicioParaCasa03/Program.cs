﻿using System;

namespace Senai.Projetos.For.ExercicioParaCasa03
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ex. 3 

// Receber um número n do usuário. Receber n pesos e n alturas. Calcular o IMC para cada peso e altura recebido. Exibir a média dos IMCs calculado. 
        
        int quantidade;

        System.Console.WriteLine("Entre com o numero de pessoas das quais deseja calcular o imc:");
        quantidade=int.Parse(Console.ReadLine());

        int cont=1;
        double massa;
        double altura;
        double media=0;
        double imc;

        for(cont=1; cont<=quantidade; cont++){
        System.Console.WriteLine("Entre com a massa da pessoa nº "+cont);
        massa=double.Parse(Console.ReadLine());
        System.Console.WriteLine("Entre com a altura da pessoa nº "+cont);
        altura=double.Parse(Console.ReadLine());

        imc=massa/(altura*altura);
        media=media+imc/quantidade;
        System.Console.WriteLine("O IMC da pessoa "+cont+ " é "+imc);

        }

        System.Console.WriteLine("O IMC médio das  "+quantidade+ " pessoas é "+media);
        
        
        }
    }
}
