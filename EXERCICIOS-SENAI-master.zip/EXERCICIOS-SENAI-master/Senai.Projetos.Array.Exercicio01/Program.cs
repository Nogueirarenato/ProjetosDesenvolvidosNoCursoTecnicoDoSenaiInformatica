﻿using System;

namespace Senai.Projetos.Array.Exercicio01
{
    class Program
     {
        static void Main(string[] args)
        {       bool correto=false;
                int contador=0;
                int contador2=0;
                int [] passagem = new int[5];
                string [] nome = new string [5];
                DateTime[] data = new DateTime[5];



                string opcoes;

                do{
                    if(contador==5){
                        do{System.Console.WriteLine("Digite [2] para exibir viagens agendadas");
                             System.Console.WriteLine("Digire [0] para sair do programa");
                             opcoes= Console.ReadLine();
                        }while(opcoes!="0" && opcoes!="2");
                    }
                    else{
                 System.Console.WriteLine("Escolha uma opção");
                    System.Console.WriteLine("Digite [1] para agendar viagem");
                    System.Console.WriteLine("Digite [2] para exibir viagens agendadas");
                    System.Console.WriteLine("Digire [0] para sair do programa");
                    opcoes= Console.ReadLine();
                    }

    switch(opcoes){


            case "1":{ System.Console.WriteLine("Bem vindo!! ");
                    
                    do{System.Console.WriteLine("Digite o nome do passageiro:");
                    nome[contador]=Console.ReadLine();
                    System.Console.WriteLine("Digite a data e horário da viagem (dd/mm/aaa hh:mm:ss):");
                    data[contador]= DateTime.Parse(Console.ReadLine());
                    System.Console.WriteLine("Digite o número da passagem");
                    passagem[contador] =int.Parse(Console.ReadLine());
                    System.Console.WriteLine("Verifique se os dados estão corretos:");
                    System.Console.WriteLine($"reserva nº {contador+1} Passageiro: {nome[contador]} passagem nº {passagem[contador]} Data: {data[contador].ToShortDateString()}");
                    System.Console.WriteLine("Digite [1] Para confirmar ou qualquer outra tecla para corrigir erros");
                    

                    if(Console.ReadLine()=="1") correto=true;            
                    }while(!correto);
                    correto=false;
                    
                    contador++;

                  

            break;
            }

            case "2":{

                    while(contador2<contador){
                             System.Console.WriteLine($"reserva nº {contador2+1} Passageiro: {nome[contador2]} passagem nº {passagem[contador2]} Data: {data[contador2].ToShortDateString()}");
                        contador2++;
                    }
                        contador2=0;

                break;
                
            }

           


    }


                }while(opcoes!="0");

                System.Console.WriteLine("Fechando o programa");
        }
    }
}