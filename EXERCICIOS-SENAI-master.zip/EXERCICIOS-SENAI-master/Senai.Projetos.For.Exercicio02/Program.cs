﻿using System;

namespace Senai.Projetos.For.Exercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            
// Ex. 2 

// Faça um algoritmo que imprima os números de 200 até 0. 


  int cont=200;

  while(cont>=0){

      Console.WriteLine(""+cont);
      cont--;
  }

            System.Console.WriteLine("Pressione enter para sair...");
            Console.ReadLine();
        }
    }
}
