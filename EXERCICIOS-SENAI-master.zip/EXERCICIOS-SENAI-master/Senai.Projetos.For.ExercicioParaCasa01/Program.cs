﻿using System;

namespace Senai.Projetos.For.ExercicioParaCasa01
{
    class Program
    {
        static void Main(string[] args)
        {


// Ex. 1 

// Receba um número n (>0) do usuário. Exibir os números entre n e 0 no console. 



    int numero;
    

    System.Console.WriteLine("Digite um numero:");
    numero=int.Parse(Console.ReadLine());

        int cont;
        for(cont=numero; cont>=0; cont--)
        {
            System.Console.Write(" "+cont);
        }

        }
    }
}
