﻿using System;

namespace Senai.Projetos.For.Exercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
              
//             Ex. 1 

// Receber um número inteiro n e outro limite do usuário. Exibir a tabuada do número n do 0 até o limite. 

            int n;
            int limite;
            int cont=0;

            System.Console.WriteLine("com o numero de qual deseja a tabuada: ");
            n=int.Parse(Console.ReadLine());
            System.Console.WriteLine("Entre com ultimo numero da tabuada:");
            limite=int.Parse(Console.ReadLine());

            System.Console.WriteLine("\n\n ******CALCULANDO A TABUADA******\n\n");

            while(cont<=limite){

                System.Console.WriteLine($"{n} x {cont} = {n*cont}");
                cont++;

            }

            System.Console.WriteLine("Pressione enter para sair...");
            Console.ReadLine();

        }
    }
}
