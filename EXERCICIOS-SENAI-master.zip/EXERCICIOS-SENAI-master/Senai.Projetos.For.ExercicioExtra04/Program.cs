﻿using System;

namespace Senai.Projetos.For.ExercicioExtra04
{
    class Program
    {
        static void Main(string[] args)
        {
            

// Ex. 4 

// Receba um número n do usuário. Calcular o fatorial deste. 

// DICA: CÁLCULO DO FATORIAL: 

// O cálculo do fatorial se resume as seguintes regras: 

// Dado um número n. Deve-se multiplicar do número 1 até o número n incrementando as unidades. Desta forma, o fatorial de 5 seria: 1 * 2 * 3 * 4 * 5, que por sua é vez é igual a 120. 


    int fatorial;
    int n;
    int soma;
    soma=1;
    System.Console.WriteLine("Entre com o número do qual deseja saber o fatorial: ");
    fatorial= int.Parse(Console.ReadLine());

    for(n=fatorial; n>0; n-- ){
        soma=soma*n;
    }

System.Console.WriteLine(""+fatorial+"! = "+soma);



        }
    }
}
