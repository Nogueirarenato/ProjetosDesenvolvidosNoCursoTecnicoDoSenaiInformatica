﻿using System;

namespace Senai.Projetos.Array.Exercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            int cont=0;
            int n;
            Console.WriteLine("Entre com o tamanho do vetor");

            n = int.Parse(Console.ReadLine());

            int[] vetorInteiro = new int[n];
            bool[] vetorBoleano = new bool[n];

            while (cont < n)
            {
                Console.WriteLine("Entre com o valor da posição "+(cont+1));
                vetorInteiro [cont] = int.Parse(Console.ReadLine());
                if (vetorInteiro[cont] >= 0) vetorBoleano[cont] = true;
                else vetorBoleano [cont] = false;
                Console.WriteLine("O valor retorna " +vetorBoleano[cont]);
                cont++;

            }
            Console.ReadLine();
        }
    }
}
