﻿using System;

namespace Senai.Projetos.For.ExercicioParaCasa02
{
    class Program
    {
        static void Main(string[] args)
        {
         
//          Ex. 2 

// Receber do usuário um número n. Receber n salários do usuário. Exibir no console: 

// Quantidade de salários menor ou igual ao salário mínimo (Considere o salário mínimo como: R$ 834,97); 

// Quantidade de salários maior que o salário mínimo; 
         
        int quantidade;
        int cont;
        
        System.Console.WriteLine("Digite a quantidade de salarios que deseja processar");
        quantidade = int.Parse(Console.ReadLine());
        int maior=0;
        int menor=0;
        int salario;
        for(cont=1; cont<=quantidade; cont++)
            {
            System.Console.WriteLine("digite o "+cont+"º salário");
            salario=int.Parse(Console.ReadLine());

            if(salario>=834.97)maior++;
            else menor++;
            }

            System.Console.WriteLine($"{maior} salários são maiores ou iguais ao salário mínimo de R$ 834,97");
            System.Console.WriteLine($"{menor} salarios são menores que o minimo");



         }
    }
}
