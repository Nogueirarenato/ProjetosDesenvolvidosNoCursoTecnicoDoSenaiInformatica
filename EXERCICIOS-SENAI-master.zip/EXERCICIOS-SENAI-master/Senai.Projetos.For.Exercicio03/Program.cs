﻿using System;

namespace Senai.Projetos.For.Exercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            
            // Ex. 3 

            // Receba um número inteiro par do usuário. Exibir os próximos 100 números pares após o número inserido pelo usuário. 


        int n; 

        System.Console.WriteLine("Entre com um número:");
        n=int.Parse(Console.ReadLine());

        if(n%2==1)n=n+1;
        int cont;
        System.Console.WriteLine("Os próximos 100 numeros pares são:");
        for(cont=0; cont<=200; cont=cont+2  )
        {
            System.Console.WriteLine($"{n+cont}");
        }





            System.Console.WriteLine("Pressione enter para sair...");
            Console.ReadLine();
        }
    }
}
