﻿using System;

namespace Senai.Projetos.For.ExercicioExtra01
{
    class Program
    {
        static void Main(string[] args)
        {

//             Ex. 1 

// Receba do usuário um número n. Receba x valores (> 0) do usuário. Exiba no console qual dos valores foi o menor e qual deles foi o maior. 
        
        int tamanho;

        System.Console.WriteLine("Entre com o tamanho do vetor:");
        tamanho=int.Parse(Console.ReadLine());
        int [] vetor = new int[tamanho];
        int contador=1;
        int maior=0;
        int menor= 999999;
        for(contador=1; contador<=tamanho; contador++)
        {
            System.Console.WriteLine("Entre com o "+contador+"ºvalor.");
            vetor[contador-1]=int.Parse(Console.ReadLine());
            if(vetor[contador-1]>maior)maior=vetor[contador-1];
            if(vetor[contador-1]<menor)menor=vetor[contador-1];


        }

        System.Console.WriteLine("O menor numero digitado foi "+menor);
        System.Console.WriteLine("O maior numero digitado foi "+maior);
        
        
        
        
        }
    }
}
