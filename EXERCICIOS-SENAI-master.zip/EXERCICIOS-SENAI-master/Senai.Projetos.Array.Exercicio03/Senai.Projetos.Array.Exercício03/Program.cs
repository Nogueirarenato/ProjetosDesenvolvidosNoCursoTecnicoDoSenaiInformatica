﻿using System;

namespace Senai.Projetos.Array.Exercício03
{
    class Program
    {
        static void Main(string[] args)
        {
            //3) Elabore um programa em C# que tenha como parâmetros de entrada um vetor (cujos elementos são do tipo inteiro) e o número de elementos do vetor, e forneça como saída a média aritmética dos números do vetor.	
            int cont = 0;
            int n;
            
            Console.WriteLine("Entre com o tamanho do vetor: ");
            n = int.Parse(Console.ReadLine());
            int[] vetor = new int[n];
            int soma;
            soma = 0;

            while (cont < n)
            {
                Console.WriteLine("Entre com o valor");
                soma = soma + int.Parse(Console.ReadLine());
                cont++;
            }

            soma = soma / n;


            Console.WriteLine("O valor da média é: "+soma);

            Console.WriteLine("Digite alguma coisa para encerrar o programa...");
            Console.ReadLine();

        }
    }
}
