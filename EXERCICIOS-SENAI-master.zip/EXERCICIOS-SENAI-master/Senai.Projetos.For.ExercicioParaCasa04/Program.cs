﻿using System;

namespace Senai.Projetos.For.ExercicioParaCasa04
{
    class Program
    {
        static void Main(string[] args)
        {
//             Ex. 4 

// Fornecido um número limite (>0) e um número base (>0). Exiba no console todos os múltiplos do número base de 0 até limite. 

            int numero;
            System.Console.WriteLine("Entre com um numero");
            numero=int.Parse(Console.ReadLine());
            int cont;
            System.Console.WriteLine("Os multiplos de "+numero+" são:");
            for(cont=1; cont<=numero; cont++){

                if(numero%cont==0)System.Console.Write(" "+cont);
            }


        }
    }
}
