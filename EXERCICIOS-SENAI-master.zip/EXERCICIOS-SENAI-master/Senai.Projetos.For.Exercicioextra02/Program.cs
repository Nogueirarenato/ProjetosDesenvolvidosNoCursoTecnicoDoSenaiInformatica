﻿using System;

namespace Senai.Projetos.For.Exercicioextra02
{
    class Program
    {
        static void Main(string[] args)
     {
//             Ex. 2 

// Mostrar n números da sequência de Fibonacci. Iniciar a sequência com 0 e em seguida 1. 

// DICA: Sequência de Fibonacci: 

// A sequência de Fibonacci tem como base a seguinte regra: dado um número N, seu valor será a soma de seu antecessor com seu “anti antecessor”. A expressão da regra seria: Nx = Nx-1 + Nx-2 

        int tamanho;
        System.Console.WriteLine("entre com a quantidade de numeros que deseja da sequencia de fibonacci");
        tamanho=int.Parse(Console.ReadLine());

        int []fibonaci=new int [tamanho];

        if(tamanho<=2){
            if(tamanho==1)System.Console.WriteLine("O 1º numero da sequencia de fibonacci é 1");
            if(tamanho==2)System.Console.WriteLine("O 1º numero da sequencia de fibonacci é 1\nO 2º numero da sequencia de fibonacci é 1");
        }

        else{

            System.Console.WriteLine("O 1º numero da sequencia de fibonacci é 1\nO 2º numero da sequencia de fibonacci é 1");
            int cont =3;
            fibonaci[0]=1;
            fibonaci[1]=1;
            for(cont=2; cont<tamanho; cont++){
                fibonaci[cont]=(fibonaci[cont-2]+fibonaci[cont-1]);
                System.Console.WriteLine("O "+(cont+1)+"º numero da sequencia de fibonacci é "+(fibonaci[cont]));

            }





        }



        }
    }
}
