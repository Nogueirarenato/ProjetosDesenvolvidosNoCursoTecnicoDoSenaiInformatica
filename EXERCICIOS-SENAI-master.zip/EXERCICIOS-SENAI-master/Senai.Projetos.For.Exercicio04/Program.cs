﻿using System;

namespace Senai.Projetos.For.Exercicio04
{
    class Program
    {
        static void Main(string[] args)
        {
 //      Ex. 4 

// Receba um número inteiro n do usuário. Em seguida, Receba n números do usuário. Exiba a somatória dos x números inseridos e também a média. 

// DICA: Somatória: É a soma de um conjunto de números. 

// DICA: Média: É a somatória de um conjunto numérico divido por sua quantidade. 

// EXEMPLO: Conjunto A = {1; 2; 3; 4} 

// Somatória do conjunto A: 1 + 2 + 3 + 4 = 10 

// Média do conjunto A: 10 / 4 = 2; onde 10 é a somatória e 4 é a quantidade de elementos do conjunto. 


        int n, soma;
        soma=0;
        System.Console.WriteLine("Entre com o número de itens do qual deseja cacular a média");
        n=int.Parse(Console.ReadLine());
        int cont, item;

        for(cont=0; cont<n; cont++)
             {

        System.Console.WriteLine("Entre com o "+(cont+1)+"º numero de um total de "+n+" numeros");
        item=int.Parse(Console.ReadLine());
        soma=soma+item;
                }
System.Console.WriteLine("O valor do somatório é "+soma);
System.Console.WriteLine("O valor da média é: "+(soma/n));
    



    }
}}
