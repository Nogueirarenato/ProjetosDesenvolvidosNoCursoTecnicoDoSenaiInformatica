--Script de Select

USE SENAI_HROADS_MANHA;

--4. Atualizar o nome do personagem Fer8 para Fer7
UPDATE PERSONAGENS SET NOME = 'Fer7'
WHERE ID=3;

--5. Atualizar o nome da classe de Necromante para Necromancer; 
UPDATE CLASSES SET NOME = 'Necromancer'
WHERE ID=5;

--6. Selecionar todos os personagens;
SELECT * FROM PERSONAGENS;

--7. Selecionar todos as classes; 
SELECT * FROM CLASSES;

--8. Selecionar somente o nome das classes;
SELECT NOME FROM CLASSES;

--9. Selecionar todas as habilidades; 
SELECT * FROM HABILIDADES;

--10. Realizar a contagem de quantas habilidades est�o cadastradas; 
SELECT COUNT(*) AS QUANTIDADE_REGISTROS FROM HABILIDADES;

--11. Selecionar somente os id�s das habilidades classificando-os por ordem crescente; 
SELECT ID FROM HABILIDADES ORDER BY ID asc;

--12. Selecionar todos os tipos de habilidades; 
SELECT * FROM TIPOS_DE_HABILIDADE;

--13. Selecionar todas as habilidades e a quais tipos de habilidades elas fazem parte; 
SELECT * FROM HABILIDADES INNER JOIN TIPOS_DE_HABILIDADE ON  TIPOS_DE_HABILIDADE.ID = HABILIDADES.ID_TIPO_DE_HABILIDADE ;

--14. Selecionar todos os personagens e suas respectivas classes;
SELECT * FROM PERSONAGENS INNER JOIN CLASSES ON CLASSES.ID = PERSONAGENS.ID_CLASSE;

--15. Selecionar todos os personagens e as classes (mesmo que elas n�o tenham correspond�ncia em personagens);
 SELECT * FROM PERSONAGENS RIGHT JOIN CLASSES ON CLASSES.ID = PERSONAGENS.ID_CLASSE;

-- 16. Selecionar todas as classes e suas respectivas habilidades; 
SELECT * FROM CLASSES_HABILIDADES INNER JOIN CLASSES ON CLASSES.ID = CLASSES_HABILIDADES.ID_CLASSE  INNER JOIN HABILIDADES ON HABILIDADES.ID = CLASSES_HABILIDADES.ID_HABILIDADE;

--17. Selecionar todas as habilidades e suas classes (somente as que possuem correspond�ncia); 
SELECT * FROM CLASSES_HABILIDADES LEFT JOIN HABILIDADES ON HABILIDADES.ID = CLASSES_HABILIDADES.ID_HABILIDADE LEFT JOIN CLASSES ON CLASSES.ID = CLASSES_HABILIDADES.ID_CLASSE  ;

--18. Selecionar todas as habilidades e suas classes (mesmo que elas n�o tenham correspond�ncia). 
SELECT * FROM CLASSES_HABILIDADES RIGHT JOIN HABILIDADES ON HABILIDADES.ID = CLASSES_HABILIDADES.ID_HABILIDADE RIGHT JOIN CLASSES ON CLASSES.ID = CLASSES_HABILIDADES.ID_CLASSE  ;
