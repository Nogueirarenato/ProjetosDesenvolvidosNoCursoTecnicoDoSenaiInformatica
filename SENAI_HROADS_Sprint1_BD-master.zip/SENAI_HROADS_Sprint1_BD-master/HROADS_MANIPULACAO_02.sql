--Script de inser��o

USE SENAI_HROADS_MANHA;

--Inserindo dados da tabela "CLASSES"
INSERT INTO CLASSES(NOME) 
VALUES('B�rbaro')
,('Cruzado')
,('Ca�adora de Dem�nios')
,('Monge')
,('Necromante')
,('Feiticeiro')
,('Arcanista');


--Inserindo dados da tabela "TIPOS DE HABILIDADE"
INSERT INTO TIPOS_DE_HABILIDADE(NOME) 
VALUES('Ataque')
,('Defesa')
,('Cura')
,('Magia');

--Inserindo dados da tabela "TIPOS DE HABILIDADE"
INSERT INTO HABILIDADES(NOME,ID_TIPO_DE_HABILIDADE) 
VALUES ('Lan�a Mortal', 1)
		,('Escudo Supremo', 2)
		,('Recupar Vida', 3);


--Inserindo dados da tabela "CLASSES_HABILIDADES"
INSERT INTO CLASSES_HABILIDADES(ID_CLASSE,ID_HABILIDADE) 
VALUES   (1,1)
		,(1,2)
		,(2,2)
		,(3,1)
		,(4,3)
		,(4,2)
		,(6,3);

--Inserindo dados da tabela "Personagens"
INSERT INTO PERSONAGENS(NOME, ID_CLASSE, CAPACIDADE_MAX_VIDA, CAPACIDADE_MAX_MANA, DATA_ATUALIZACAO, DATA_CRIACAO)
VALUES ('DeuBug', 1, 100, 80, SYSDATETIME(), '18/01/2019')
		,('BitBug', 4, 70, 100, SYSDATETIME(), '17/03/2016') 
		,('Fer8', 7, 75, 60, SYSDATETIME(), '18/03/2018') ;
