const UrlApi = "http://ricardoribeiro21-001-site1.gtempurl.com";
export default UrlApi;