
import {createStackNavigator, createAppContainer, createBottomTabNavigator, createSwitchNavigator} from "react-navigation";
import Entrar from './pages/login'
import Cadastro from './pages/cadastro'
import Inicio from './pages/inicio'
import Consultas from './pages/listarConsultas'

const AuthStack = createStackNavigator({ Entrar });

const MainNavigator = createBottomTabNavigator({
    Consultas
    

},
{
 
    swipeEnabled: true,
    tabBarOptions:{
        labelStyle: { fontSize: 15},
        showLabel:true,
        showIcon: true,
        inactiveBackgroundColor: "#428bca",
        activeBackgroundColor: "#54AFFF",
        activeTintColor:"white",
        inactiveTintColor: "white",
        
      
    }
}
)

export default createAppContainer (
    createSwitchNavigator(
    {
      MainNavigator,
      AuthStack
    },
    {
      initialRouteName: "AuthStack"
    }
  ))
