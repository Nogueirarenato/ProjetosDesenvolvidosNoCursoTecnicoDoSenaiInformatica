import React, {Component} from "react";
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from "react-native";

class Cadastro extends Component{

  static navigationOptions ={
    tabBarIcon: ({tintColor}) => (
      <Image
        source ={require("../assets/img/cracha.png")}
        style={{width:25, height: 25, tintColor: "white"}}
      />
      
      
    )
  }

render(){
    return  (
    
        <View style={styles.container}>
        <Text style={styles.welcome}>Bem Vindo ao SPMedical Group!</Text>
        <Text style={styles.instructions}>"Sua Saúde em Primeiro Lugar!</Text>
        <TextInput
            style={styles.inputLogin}
            placeholder="Nome"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
      <TextInput
            style={styles.inputLogin}
            placeholder="Data de Nascimento"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="CPF"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="RG"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
      
      <TextInput
            style={styles.inputLogin}
            placeholder="Endereço"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="Telefone"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="Email"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="Senha"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
           
             
      />
          <TouchableOpacity
            style={styles.btnLogin}
            onPress={this._realizarLogin}
          >
            <Text style={styles.btnLoginText}>CADASTRAR</Text>
          </TouchableOpacity>

        </View>
    )
}

}

export default Cadastro;


 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#428bca',    
  },
  inputLogin: {
    width: 240,
    marginBottom: 10,
    fontSize: 15
  },
  welcome: {
    fontSize: 40,
    textAlign: 'center',
    margin: 0,
    color: 'white',
  },
  instructions: {
    textAlign: 'center',
    color: 'white',
   
    fontSize:20,
  },
  btnLogin: {
    height: 38,
    shadowColor: "rgba(0,0,0, 0.4)", // IOS
    shadowOffset: { height: 1, width: 1 }, // IOS
    shadowOpacity: 1, // IOS
    shadowRadius: 1, //IOS
    elevation: 3, // Android
    width: 240,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "#FFFFFF",
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10
  },
  btnLoginText: {
    fontSize: 15,
    fontFamily: "OpenSans-Light",
    color: "#0D1140",
    letterSpacing: 4
  }
});
