import React, { Component } from "react";
import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, ImageBackground, AsyncStorage } from "react-native";
import api from "../services/api";
import jwt from "jwt-decode"
import { FlatList } from "react-native-gesture-handler";

class ListarConsultas extends Component {
  static navigationOptions = {
    tabBarIcon: ({ tintColor }) => (
      <Image
        source={require("../assets/img/logo.png")}
        style={{ width: 30, height: 30, tintColor: "white" }}
      />


    )
  }


  // static navigationOptions = {
  //   header: {
  //     Authorization: `Bearer ${this.state.tk}` 
  //   }
  // };

  constructor(props) {
    super(props);
    this.state = {
      listaConsultas: [],
      tk: AsyncStorage.getItem("userToken")
    };
  }


  componentDidMount() {
    // realizar a chamada a api
    // emulator -list-avds
    // emulator -avd nomeAVD
    this.carregarConsultas();
    this.pegarToken();
  }

  pegarToken = async () => {
    console.warn(await AsyncStorage.getItem("userToken"));
  }

  carregarConsultas = async () => {
    const resposta = await api.get("/Paciente/ExibirMinhasConsultas", { header: {
          Authorization: `Bearer ${this.state.tk}` 
        }});
    const dadosDaApi = resposta.data;
    this.setState({ listaConsultas: dadosDaApi });
  };




  render() {
    return (
      <View>
        <Text>Rick</Text>
        <FlatList
          data= {this.state.listaConsultas}
          keyExtractor ={item => item.id}
          renderItem={this.renderizaItem}
        />
        </View>
    )
  }

  renderizaItem = ({ item }) => <View>
    <View>
      <Text>{item.id}</Text>
      <Text>{item.idMedico}</Text>
      <Text>{dataConsulta.id}</Text>
      <Text>{item.idStatus}</Text>
    </View>
  </View>

}

export default ListarConsultas;




const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#428bca'

  },
  welcome: {
    fontSize: 40,
    textAlign: 'center',
    margin: 10,
    color: 'white',
  },
  instructions: {
    textAlign: 'center',
    color: 'white',
    marginBottom: '40%',
    fontSize: 20,
  },
  btnLogin: {
    height: 38,
    shadowColor: "rgba(0,0,0, 0.4)", // IOS
    shadowOffset: { height: 1, width: 1 }, // IOS
    shadowOpacity: 1, // IOS
    shadowRadius: 1, //IOS
    elevation: 3, // Android
    width: 240,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "#FFFFFF",
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10
  },
  btnLoginText: {
    fontSize: 25,
    fontFamily: "OpenSans-Light",
    color: "#0D1140",
    letterSpacing: 4
  },
  inputLogin: {
    width: 240,
    marginBottom: 10,
    fontSize: 25
  },
});
