import React, {Component} from "react";
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, ImageBackground} from "react-native";
import api from "../services/api";
import jwt from "jwt-decode"

class Inicio extends Component{
  static navigationOptions ={
    tabBarIcon: ({tintColor}) => (
      <Image
       // source ={require("../assets/img/door.png")}
        style={{width:30, height: 30, tintColor: "white"}}
      />


    )
  }

  static navigationOptions = {
    header: null
  };

  constructor(props) {
    super(props);
    this.state = { email: "", senha: "" };
  }

  _realizarLogin = async () => {
    // console.warn(this.state.email + this.state.senha);

    const resposta = await api.post("/login", {
      email: this.state.email,
      senha: this.state.senha
    });

    // console.warn(token);
    const token = resposta.data.token;
    await AsyncStorage.setItem("userToken", token);
    this.props.navigation.navigate("MainNavigator");
  };


render(){
    return  (
      
        <View style={styles.container}>
        <Image
      source ={require("../assets/img/logo.png")}
    style={{width:150, height: 150, padding:0}}
    />
        <Text style={styles.welcome}>Bem Vindo ao SPMedical Group!</Text>
        <Text style={styles.instructions}>"Sua Saúde em Primeiro Lugar!</Text>
        <TextInput
            style={styles.inputLogin}
            placeholder="Email"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
            onChangeText={email => this.setState({email})}
           
             
      />
         <TextInput
            style={styles.inputLogin}
            placeholder="Senha"
            placeholderTextColor="#FFFFFF"
            underlineColorAndroid="#FFFFFF"
            onChangeText={senha => this.setState({senha})}
             
      />
          <TouchableOpacity
            style={styles.btnLogin}
            onPress={this._realizarLogin}
          >
            <Text style={styles.btnLoginText}>LOGIN</Text>
          </TouchableOpacity>
          
        </View>
    )
}

}

export default Inicio;


 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#428bca'
    
  },
  welcome: {
    fontSize: 40,
    textAlign: 'center',
    margin: 10,
    color: 'white',
  },
  instructions: {
    textAlign: 'center',
    color: 'white',
    marginBottom: '40%',
    fontSize:20,
  },
  btnLogin: {
    height: 38,
    shadowColor: "rgba(0,0,0, 0.4)", // IOS
    shadowOffset: { height: 1, width: 1 }, // IOS
    shadowOpacity: 1, // IOS
    shadowRadius: 1, //IOS
    elevation: 3, // Android
    width: 240,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "#FFFFFF",
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10
  },
  btnLoginText: {
    fontSize: 25,
    fontFamily: "OpenSans-Light",
    color: "#0D1140",
    letterSpacing: 4
  },
  inputLogin: {
    width: 240,
    marginBottom: 10,
    fontSize: 25
  },
});
