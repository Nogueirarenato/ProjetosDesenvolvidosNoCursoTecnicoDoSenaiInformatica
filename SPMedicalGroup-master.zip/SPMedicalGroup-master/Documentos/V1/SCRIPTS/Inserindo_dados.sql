USE SENAI_SPMEDGROUP_MANHA;

--INSERINDO AS ESPECIALIDADES
INSERT INTO ESPECIALIDADES (NOME)
VALUES ('Acupuntura')
	,('Anestesiologia')
	,('Angiologia')
	,('Cardiologia')
	,('Cirurgia Cardiovascular')
	,('Cirurgia da M�o')
	,('Cirurgia do Aparelho Digestivo')
	,('Cirurgia Geral')
	,('Cirurgia Pedi�trica')
	,('Cirurgia Pl�stica')
	,('Cirurgia Tor�cica')
	,('Cirurgia Vascular')
	,('Dermatologia')
	,('Radioterapia')
	,('Urologia')
	,('Pediatria')
	,('Psiquiatria');

--INSERINDO LOCAIS
INSERT INTO LOCAIS (NOME, RAZAO_SOCIAL, CNPJ, ENDERECO)
VALUES ('Clinica Possarle', 'SP Medical Group',	'86.400.902/0001-30',	'Av. Bar�o Limeira, 532, S�o Paulo, SP');

--INSERINDO USUARIOS
INSERT INTO TIPO_USUARIOS (TIPO_DE_USUARIO)
VALUES ('ADMINISTRADOR'), ('M�DICO'), ('PACIENTE');

--SELECT * FROM ESPECIALIDADES;
--SELECT * FROM LOCAIS;
--SELECT * FROM TIPO_USUARIOS;


--INSERINDO MEDICOS
INSERT INTO MEDICOS ( ID_USUARIO, CRM, NOME, EMAIL, ID_ESPECIALIDADE, ID_LOCAL)
VALUES 	(2, '	54356-SP	','	Ricardo Lemos	','	ricardo.lemos@spmedicalgroup.com.br	',	2	,	1	)
,	(2, '	53452-SP	','	Roberto Possarle	','	roberto.possarle@spmedicalgroup.com.br	',	17	,	1	)
,	(2, '	65463-SP	','	Helena Strada	','	helena.souza@spmedicalgroup.com.br	',	16	,	1	);


--SELECT * FROM MEDICOS;


--INSERINDO STATUS DAS CONSULTAS
INSERT INTO  STATUS_CONSULTA (STATUS_CONSULTA)
VALUES ('AGENDADA'), ('REALIZADA'), ('CANCELADA');

--INSERINDO PACIENTES
INSERT INTO PACIENTES (ID_USUARIO, NOME, EMAIL, DATA_NASCIMENTO, TELEFONE, RG, CPF, ENDERECO_RESIDENCIAL, SENHA, TELEFONE_EMERGENCIA, PESO, ALTURA)
VALUES (3,'	Ligia	','	ligia@gmail.com	',	13/10/1983	,'	11 3456-7654	','	43522543-5	','	94839859000	','	Rua Estado de Israel 240,�S�o Paulo, Estado de S�o Paulo, 04022-000',12345, '000', 70 , 1.78	)
,(3,'	Alexandre	','	alexandre@gmail.com	',	23/07/2001	,'	11 98765-6543	','	32654345-7	','	73556944057	','	Av. Paulista, 1578 - Bela Vista, S�o Paulo - SP, 01310-200', 12345, '000', 70 , 1.78	)
,(3,'	Fernando	','	fernando@gmail.com	',	10/10/1978	,'	11 97208-4453	','	54636525-3	','	16839338002	','	Av. Ibirapuera - Indian�polis, 2927,  S�o Paulo - SP, 04029-200',12345, '000', 70 , 1.78	)
,(3,'	Henrique	','	henrique@gmail.com	',	13/10/1985	,'	11 3456-6543	','	54366362-5	','	14332654765	','	R. Vit�ria, 120 - Vila Sao Jorge, Barueri - SP, 06402-030',12345, '000'	, 70 , 1.78)
,(3,'	Jo�o	','	joao@hotmail.com	',	27/08/1975	,'	11 7656-6377	','	t32544444-1	','	91305348010	','	R. Ver. Geraldo de Camargo, 66 - Santa Luzia, Ribeir�o Pires - SP, 09405-380',12345, '000', 70 , 1.78	)
,(3,'	Bruno	','	bruno@gmail.com	',	21/03/1972	,'	11 95436-8769	','	54566266-7	','	79799299004	','	Alameda dos Arapan�s, 945 - Indian�polis, S�o Paulo - SP, 04524-001', 12345, '000' , 70 , 1.78	)
,(3,'	Mariana	','	mariana@outlook.com	',	05/03/2018	,'	0	','	54566266-8	','	13771913039	','	R Sao Antonio, 232 - Vila Universal, Barueri - SP, 06407-140', 12345, '000', 70	, 1.78);

--SELECT * FROM PACIENTES;

--INSERINDO CONSULTAS

--SELECT * FROM PACIENTES;
--SELECT * FROM MEDICOS;
--SELECT * FROM STATUS_CONSULTA;

INSERT INTO CONSULTAS (ID_PACIENTE, ID_MEDICO, DATA_CONSULTA, ID_STATUS)
VALUES  (11, 3, '20/01/2019 15:00', 2)
		,(6, 2, '06/01/2018 10:00', 3)
		,(7, 2, '07/02/2019 11:00', 2)
		,(6, 2, '06/02/2018 10:00', 2)
		,(8, 1, '07/02/2019 11:00', 3)
		,(11, 3, '08/02/2019 15:00', 1)
		,(8, 1,	'09/02/2019 11:00', 1);
	
SELECT * FROM PACIENTES;

--ATUALIZANDO AS DATAS DE NASCIMENTO
UPDATE PACIENTES SET DATA_NASCIMENTO = '13/10/1983'
WHERE ID=5;

UPDATE PACIENTES SET DATA_NASCIMENTO = '23/07/2001'
WHERE ID=6;

UPDATE PACIENTES SET DATA_NASCIMENTO = '10/10/1978'
WHERE ID=7;

UPDATE PACIENTES SET DATA_NASCIMENTO = '13/10/1985'
WHERE ID=8;

UPDATE PACIENTES SET DATA_NASCIMENTO = '27/08/1975'
WHERE ID=9;

UPDATE PACIENTES SET DATA_NASCIMENTO = '21/03/1972'
WHERE ID=10;

UPDATE PACIENTES SET DATA_NASCIMENTO = '05/03/2018'
WHERE ID=11;

