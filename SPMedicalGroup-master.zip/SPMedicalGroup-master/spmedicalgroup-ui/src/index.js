import React from 'react';
import ReactDOM from 'react-dom';
import { Route, BrowserRouter as Router, Switch, Redirect} from "react-router-dom";
import './index.css';
import App from './pages/App';
import * as serviceWorker from './serviceWorker';
import ListarUsuarios from './pages/ListarUsuarios/ListarUsuarios';
import ListarMedicos from './pages/ListarMedicos/ListarMedicos';
import ListarConsultas from './pages/ListarConsultas/ListarConsultas';
import NaoEncontrada from './pages/ListarUsuarios/ListarUsuarios';
import CadastrarUsuario from './pages/CadastrarUsuario/CadastrarUsuario';
import CadastrarAdm from './pages/CadastrarAdm/CadastrarAdm';
import CadastrarMedico from './pages/CadastrarMedico/CadastrarMedico';
import CadastrarConsulta from './pages/CadastrarConsulta/CadastrarConsulta';
import Login from './pages/Login/Login'
import PainelDoAdm from './pages/PainelDoAdm/PainelDoAdm'
import PainelDoMedico from "./pages/PainelDoMedico/PainelDoMedico"
import PainelDoPaciente from "./pages/PainelDoPaciente/PainelDoPaciente"
import ListarMinhasConsultasPaciente from "./pages/ListarMinhasConsultasPaciente/ListarMinhasConsultasPaciente"
import ListarMinhasConsultasMedico from "./pages/ListarMinhasConsultasMedico/ListarMinhasConsultasMedico"
import ExcluirConsulta from "./pages/ExcluirConsulta/ExcluirConsulta"
import EditarStatusDescricao from "./pages/EditarStatusDescricao/EditarStatusDescricao"
import { usuarioAutenticado, getToken } from "../src/Services/auth";
import ListarDoencas from "./pages/ListarDoencas/ListarDoencas"
import CadastrarDoencas from "./pages/CadastrarDoencas/CadastrarDoenca"

const PermissaoADM = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props =>
      usuarioAutenticado()  && getToken().regra == "1" ?(
        <Component {...props} />
      ) : (
        <Redirect to={{ pathname: "/", state: { from: props.location } }} />
      )
    }
  />
);


const PermissaoPaciente = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props =>
      usuarioAutenticado()  && getToken().regra == "3" ?(
        <Component {...props} />
      ) : (
        <Redirect to={{ pathname: "/", state: { from: props.location } }} />
      )
    }
  />
);


const PermissaoMedico = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props =>
      usuarioAutenticado()  && getToken().regra == "2" ?(
        <Component {...props} />
      ) : (
        <Redirect to={{ pathname: "/", state: { from: props.location } }} />
      )
    }
  />
);



const routing = (
    <Router>
        <div>
            <Switch>
                <Route exact path="/" component={App} />
                <PermissaoADM path="/ListarUsuarios" component={ListarUsuarios} />
                <PermissaoADM path="/ListarMedicos" component={ListarMedicos} />
                <PermissaoADM path="/ListarConsultas" component={ListarConsultas} />
                <PermissaoADM path="/CadastrarUsuario" component ={CadastrarUsuario}/>
                <PermissaoADM path="/CadastrarAdm" component ={CadastrarAdm}/>
                <PermissaoADM path="/CadastrarMedico" component ={CadastrarMedico}/>
                <PermissaoADM path="/CadastrarConsulta" component ={CadastrarConsulta}/>
                <PermissaoADM path="/CadastrarDoenca" component ={CadastrarDoencas}/>
                <Route path="/NaoEncontrada" component={NaoEncontrada} />
                <Route path="/Login" component={Login}/>
                <Route path ="/MapaDasEpidemias" component={ListarDoencas}/>
                <PermissaoADM path="/PainelDoAdm" component={PainelDoAdm}/>
                <PermissaoMedico path="/PainelDoMedico" component={PainelDoMedico}/>
                <PermissaoPaciente path="/PainelDoPaciente" component={PainelDoPaciente}/>
                <PermissaoPaciente path="/ListarMinhasConsultasPaciente" component={ListarMinhasConsultasPaciente}/>
                <PermissaoMedico path="/ListarMinhasConsultasMedico" component={ListarMinhasConsultasMedico}/>
                <PermissaoADM path="/ExcluirConsulta" component={ExcluirConsulta}/>
                <PermissaoMedico path="/EditarStatusDescricao" component={EditarStatusDescricao}/>
            </Switch>
        </div>
    </Router>
);



ReactDOM.render(routing, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
