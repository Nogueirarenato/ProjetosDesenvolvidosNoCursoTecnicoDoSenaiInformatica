import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Footer from "../../components/Footer/footer.js"



class CadastrarMedico extends Component {
    constructor() {
        super();
        this.state = {
            nome: "",
            email: "",
            senha: "",
            crm: "",
            idEspecialidade: "",
            idUsuario: "2",
            idLocal:"",
            erro:""
                    }

        this.autualizaNome = this.autualizaNome.bind(this);
        this.atualizaEmail = this.atualizaEmail.bind(this);
        this.atualizaSenha = this.atualizaSenha.bind(this);
        this.atualizaCrm = this.atualizaCrm.bind(this);
        this.atualizaIdEspecialidade = this.atualizaIdEspecialidade.bind(this);
        this.atualizaIdLocal =this.atualizaIdLocal.bind(this);
    }



    autualizaNome(event) {
        this.setState({ nome: event.target.value });
    }

    atualizaEmail(event) {
        this.setState({ email: event.target.value });
    }

    atualizaSenha(event) {
        this.setState({ senha: event.target.value });
    }

    atualizaCrm(event) {
        this.setState({ crm: event.target.value });
    }

    atualizaIdEspecialidade(event) {
        this.setState({ idEspecialidade: event.target.value });
    }

    atualizaIdLocal(event) {
        this.setState({ idLocal: event.target.value });
    }

 







    cadastraMedico(event) {
        event.preventDefault();



    fetch('http://localhost:5000/api/Medico',
    {
      method: 'POST',
      body : JSON.stringify({  nome : this.state.nome
        , email: this.state.email
        , senha: this.state.senha
        , crm: this.state.crm
        , idEspecialidade: this.state.idEspecialidade
        , idUsuario: "2"
        , idLocal: this.state.idLocal


      }),   





      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
        
        
      }
    })
    .then(resposta => resposta,
        this.setState({erro: "Médico Cadastrado com sucesso!!!"}))
    .catch(erro => console.log(erro))
}
componentDidMount(){
  document.title = "Cadastrar Médico"
}

    render() {
        return (
            <div>
<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color: 'red', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form className="container margem10" onSubmit={this.cadastraMedico.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}>
      Nome do Médico
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Nome" type="text" value={this.state.nome} onChange={this.autualizaNome} />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword"  value={this.state.email} onChange={this.atualizaEmail}>
    <Form.Label column sm={2}>
      Email
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o email do médico" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.senha} onChange={this.atualizaSenha}>
    <Form.Label column sm={2}>
      Senha
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Difina uma senha para o médico" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.crm} onChange={this.atualizaCrm}>
    <Form.Label column sm={2}>
      CRM
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o CRM do médico"/>
    </Col>
  </Form.Group>
  <Button href="#"  target="_blank">Verificar Especialidades</Button>
  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.idEspecialidade} onChange={this.atualizaIdEspecialidade}>

    <Form.Label column sm={2}>
    
      Digite o número da Especialidade  
    </Form.Label>
    
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a especialidade" />
    </Col>
  </Form.Group>

  <Button href="#"  target="_blank">Verificar Locais</Button>
  <Form.Group as={Row} controlId="formHorizontalEmail"value={this.state.idLocal} onChange={this.atualizaIdLocal}>
    <Form.Label column sm={2}>
      Digite o número do local
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o local" />
    </Col>
  </Form.Group>

  
  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Enviar</Button>
    </Col>
  </Form.Group>
</Form>;

<Footer className="a"/>

            </div>
        );
    }
}

export default CadastrarMedico;

