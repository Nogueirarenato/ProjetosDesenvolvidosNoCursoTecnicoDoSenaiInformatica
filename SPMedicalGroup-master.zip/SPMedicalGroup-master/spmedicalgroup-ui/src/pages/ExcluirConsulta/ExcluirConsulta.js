import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Footer from "../../components/Footer/footer.js"



class ExcluirConsulta extends Component {
    constructor() {
        super();
        this.state = {
            id: "",
            idStatus: "3"        
                               }

        this.autualizaId = this.autualizaId.bind(this);
       
    }



    autualizaId(event) {
        this.setState({ id: event.target.value });
       
    }

    



    excluirConsulta(event) {
        event.preventDefault();



    fetch('http://localhost:5000/api/Consulta/',
    {
      method: 'PUT',
      body : JSON.stringify({ 
      
            id: this.state.id,
            idStatus: this.state.idStatus

      }),   





      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
        
      }
    })
    .then(resposta => resposta,
        this.setState({erro: "Consulta Cancelada"}))
    .catch(erro => console.log(erro))
}
componentDidMount(){
  document.title = "Cancelar Consulta"
}

    render() {
        return (
            <div>
<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color: 'red', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form className="container margem10" onSubmit={this.excluirConsulta.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}>
      Id
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o Id da Consulta que deseja excluir" type="text" value={this.state.id} onChange={this.autualizaId} />
    </Col>
  </Form.Group>

  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Enviar</Button>
    </Col>
  </Form.Group>
</Form>;


<Footer className="a"/>
            </div>
        );
    }
}

export default ExcluirConsulta;

