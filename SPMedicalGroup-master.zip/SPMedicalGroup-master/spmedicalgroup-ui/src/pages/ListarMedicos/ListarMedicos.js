import React, { Component } from "react";
import Table from "../../../node_modules/react-bootstrap/Table"
import "../../assets/css/style.css"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import {Link} from "react-router-dom";
import Footer from "../../components/Footer/footer.js"



class ListarMedicos extends Component {
    constructor(){
        super();
        this.state = {
          lista : [],
          nome: "",
          tituloPagina : "Listar Medicos"
        }
  
        this.atualizaEstadoNome = this.atualizaEstadoNome.bind(this);
    }
  
    listarMedicos(){
        fetch('http://192.168.3.152/api/Medico',    {
          method: 'GET',
          headers: {
            "Content-Type" : "application/json",
            Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
          }
        })
          .then(resposta => resposta.json())
          .then(data => this.setState({lista : data}))
          .catch((erro) => console.log(erro))
    }
  
    componentDidMount(){
      
        document.title = "Listar Médicos"
    
    
        this.listarMedicos();
    }
  
    atualizaEstadoNome(event){
      this.setState({ nome : event.target.value });
    }
  
  
    render() {
      return (
        <div>
       
       <Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Admninstrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>


<Table striped bordered hover className="container">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Médico</th>
                      <th>Email</th>
                      <th>Senha</th>
                      <th>CRM</th>
                      <th>Especialidade</th>
                      <th>Tipo de Usuario</th>
                      <th>Local de Atendimento</th>
                    </tr>
                  </thead>
  
                  <tbody>
                      {


                          this.state.lista.map(function(medico){
                              return (
                                  <tr key={medico.id}>
                                      <td>{medico.id}</td>
                                      <td>{medico.nome}</td>
                                      <td>{medico.email}</td>
                                      <td>{medico.senha}</td>
                                      <td>{medico.crm}</td>
                                      <td>{medico.idEspecialidadeNavigation.nome}</td>
                                      <td>{medico.idUsuarioNavigation.tipoDeUsuario}</td>
                                      <td>{medico.idLocalNavigation.nome}</td>
                                      
                                     
                                      

                                  </tr>
                              );
                          })
                      }
                  </tbody>
                </Table>
                <Footer className="a"/>
        </div>
      );
    }
  }
  
  export default ListarMedicos;
  
   