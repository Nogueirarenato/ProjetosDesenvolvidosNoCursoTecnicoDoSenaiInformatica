import React, { Component } from "react";
import Table from "../../../node_modules/react-bootstrap/Table"
import "../../assets/css/style.css"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import {Link} from "react-router-dom";
import ButtonGroup from "../../../node_modules/react-bootstrap/ButtonGroup"
import Footer from "../../components/Footer/footer.js"



class PainelDoMedico extends Component {
  
  
    render() {
      return (
        <div>       



<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/">Sair</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>
<div className="d-flex flex-row" >
<ButtonGroup vertical className="center" size="lg">
  <Button href="/ListarMinhasConsultasMedico/" >Listar minhas consultas/pacientes</Button><br></br><br></br>
  <Button href="/EditarStatusDescricao/">Editar Status/Descrição</Button><br></br><br></br>
  
</ButtonGroup>;
</div>



<Footer className="a"/>

        </div>
      )
    }
  }
  
  export default PainelDoMedico;
  