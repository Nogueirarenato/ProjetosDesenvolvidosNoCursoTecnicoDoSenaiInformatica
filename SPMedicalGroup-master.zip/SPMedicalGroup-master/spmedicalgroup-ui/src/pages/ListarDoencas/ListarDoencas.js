
import React, { Component } from "react";
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import Footer from "../../components/Footer/footer.js"
import {Map, InfoWindow, Marker, GoogleApiWrapper} from 'google-maps-react';


const style = {
  width: '100%',
  height: '100%'
}




export class MapContainer extends Component {


  constructor(){
    super();
    
    this.state = {
      lista :[],
      tituloPagina : "Mapa das Epidemias"
    }

  
}

listarDoencas(){
    fetch('http://localhost:5000/api/Localizacoes',{
      method : 'GET',
      headers: {
        'Content-Type': 'application/json',
       // Authorization : 'Bearer ' + localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
      }
    })
      .then(resposta => resposta.json())
      .then(data => this.setState({lista : data}))
      .catch((erro) => console.log(erro))
}

componentDidMount(){
  document.title = "Mapa de Epidemias"
    this.listarDoencas();
}







  render() {


  
    return ( <div>



      <Navbar bg="primary" expand="lg">
        <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
         
          <Form inline>
          <Button variant="light"href="../">Home</Button>
          </Form>
        </Navbar.Collapse>
      </Navbar>
      {/* <Map google={this.props.google} zoom={14}
            initialCenter={{
              lat: -23.5345442,
              lng: -46.6493879
            }}
            style={style}
            >
            
          <Marker
          title={''}
          name={'SOMA'}
          position={{lat: -23.5345442, lng:-46.6493879}} />
      
              <InfoWindow onClose={this.onInfoWindowClose}>
                  <div>
                    
                  </div>
              </InfoWindow>
              >
            </Map>
           */}
           
      <Map google={this.props.google}
      initialCenter={{
        lat: -23.5345442,
        lng: -46.6493879
      }}
    
    style={{width: '100%', height: '100%', position: 'relative'}}
    className={'map'}
    zoom={14}>

  {/* <Marker
    title={'Renato'}
    name={'SOMA'}
    position={{lat: 37.778519, lng: -122.405640}} />
  <Marker
  title={'Ricardo'}
    name={'Dolores park'}
    position={{lat: 37.759703, lng: -122.428093}} />
  <Marker />
  <Marker
  title={'Guilherme'}
    name={'Your position'}
    position={{lat: 37.762391, lng: -122.439192}}
     /> */}
     {
         this.state.lista.map(map => {
            return(
                <Marker 
                title={`Especialidade: ${map.especialidade},  Doença: ${map.doenca},  Idade do Paciente: ${map.idade}`}
                position={{lat: map.latitude, lng: map.longitude}}
                />
            )
         })
     }
</Map>
        
      
      
      <Footer/>
      
                  </div>
     
    );
  }
}

export default GoogleApiWrapper({
  apiKey: ("AIzaSyD6g51cxMvwPJnVZ-Aj7edXMdq64qa6M1Y")
})(MapContainer)
