import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Footer from "../../components/Footer/footer.js"



class CadastrarDoenca extends Component {
    constructor() {
        super();
        this.state = {
            latitude: "",
            longitude: "",
            doenca: "",
            especialidade: ""
        }

        this.atualizalatitude = this.atualizalatitude.bind(this);
        this.atualizalongitude = this.atualizalongitude.bind(this);
        this.atualizadoenca = this.atualizadoenca.bind(this);
        this.atualizaespecialidade = this.atualizaespecialidade.bind(this);
             
    }



    atualizalatitude(event) {
        this.setState({ latitude: event.target.value });
    }

    atualizalongitude(event) {
        this.setState({ longitude: event.target.value });
    }

    atualizadoenca(event) {
        this.setState({ doenca: event.target.value });
    }

    atualizaespecialidade(event) {
        this.setState({ especialidade: event.target.value });
    }

    
    cadastraDoenca(event) {
        event.preventDefault();



    fetch('http://localhost:5000/api/Localizacoes',
    {
      method: 'POST',
      body : JSON.stringify({  
          longitude : this.state.longitude,
          latitude: this.state.latitude
        , doenca: this.state.doenca
        , especialidade: this.state.especialidade
        }),
      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
        
      }
    })
    .then(resposta => resposta,
      this.setState({erro: "Ocorrência Cadastrada com sucesso!!!"}))
    .catch(erro => console.log(erro))
}

componentDidMount(){
  document.title = "Cadastrar Ocorrência"
}


    render() {
        return (
            <div>
<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color: 'red', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form className="container margem10" onSubmit={this.cadastraDoenca.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}>
      Longitude
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a Longitude" type="text" defaultvalue={this.state.longitude} onChange={this.atualizalongitude} />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword"  defaultvalue={this.state.latitude} onChange={this.atualizalatitude}>
    <Form.Label column sm={2}>
      Latitude
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a Latitude" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" defaultvalue={this.state.doenca} onChange={this.atualizadoenca}>
    <Form.Label column sm={2}>
      Doença
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a Doença" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" defaultvalue={this.state.especialidade} onChange={this.atualizaespecialidade}>
    <Form.Label column sm={2}>
      Especialidade
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a especialidade"/>
    </Col>
  </Form.Group>

  
  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Enviar</Button>
    </Col>
  </Form.Group>
</Form>;


<Footer className="a"/>
            </div>
        );
    }
}

export default CadastrarDoenca;

