import React, {Component} from 'react'
import {Link, withRouter} from 'react-router-dom';
import "../../assets/css/style.css"
import logo2 from "../../assets/images/logo.png"

class Titulo extends Component{
    render() {
        return(
            <div className ="rodape"> 
              
              <div >
                  <img src= {logo2} width="10%"/>
              </div>
              <div><h2>SPMedicalGroup- Desde 2019 Cuidando da Sua Saúde!!!</h2></div>
             <div>
              <h1>Escola Senai de Informática - 2019</h1>
              <h3>Desenvolvido por Renato Nogueira</h3>
              <h3>Todos os Direitos Reservados ©</h3>
              </div>

            </div>
        );
    }
}

export default Titulo;