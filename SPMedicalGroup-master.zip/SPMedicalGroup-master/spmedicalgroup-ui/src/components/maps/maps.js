import {GoogleApiWrapper} from 'google-maps-react';

// ...

export class MapContainer extends React.Component {}

export default GoogleApiWrapper({
  apiKey: ("AIzaSyD6g51cxMvwPJnVZ-Aj7edXMdq64qa6M1Y")
})(MapContainer)
