﻿using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{ 
[Produces("application/json")]
[Route("api/[controller]")]
[ApiController]
public class LocalizacoesController : ControllerBase
{

    private ILocalizacaoRepository LocalizacaoRepository { get; set; }

    public LocalizacoesController()
    {
        LocalizacaoRepository = new LocalizacaoRepository();
    }

    [HttpPost]
    public IActionResult Cadastrar(Localizacoes localizacao)
    {
        try
        {
            LocalizacaoRepository.Cadastrar(localizacao);
            return Ok();
        }
        catch (System.Exception)
        {
            return BadRequest();
        }
    }

    [HttpGet]
    public IActionResult ListarTodos()
    {
        try
        {
            return Ok(LocalizacaoRepository.ListarTodos());
        }
        catch (System.Exception)
        {
            return BadRequest();
        }
    }

}
}