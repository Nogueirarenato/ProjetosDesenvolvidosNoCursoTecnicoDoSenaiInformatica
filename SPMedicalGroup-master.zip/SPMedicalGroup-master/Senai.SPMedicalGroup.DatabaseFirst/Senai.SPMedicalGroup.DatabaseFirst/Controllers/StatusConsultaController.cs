﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class StatusConsultaController : ControllerBase
    {
        private IStatusConsultaRepository StatusConsultaRepositorie { get; set; }

        public StatusConsultaController()
        {
            StatusConsultaRepositorie = new StatusConsultaRepositorie();
        }

        //Listar os Status de Consulta
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                
                return Ok(StatusConsultaRepositorie.Listar());
            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Um Status de Consulta
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Post(StatusConsulta status)
        {
            try
            {
                StatusConsultaRepositorie.Cadastrar(status);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar um Status de Consulta
        [Authorize(Roles = "1")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                StatusConsultaRepositorie.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }


        //Modificar uma Consulta
        [Authorize(Roles = "1")]
        [HttpPut()]
        public IActionResult Put(StatusConsulta consulta)
        {

            StatusConsultaRepositorie.Editar(consulta);
            if (StatusConsultaRepositorie.Editar(consulta) == null) { return NotFound(); }
            return Ok();

        }


    }
}