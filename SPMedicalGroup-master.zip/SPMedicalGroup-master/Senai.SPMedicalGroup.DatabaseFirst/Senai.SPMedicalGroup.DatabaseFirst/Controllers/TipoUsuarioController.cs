﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{

    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class TipoUsuarioController : ControllerBase
    {

        private ITipoUsuarioRepository TipoUsuarioRepository { get; set; }

        public TipoUsuarioController()
        {
            TipoUsuarioRepository = new TipoUsuarioRepository();
        }



        //Listar os tipos de usuarios
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                
                return Ok(TipoUsuarioRepository.Listar());
            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Um Tipo de Usuario
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Post(TipoUsuarios tipoUsuario)
        {
            try
            {
                TipoUsuarioRepository.Cadastrar(tipoUsuario);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar um tipo de usuario
        [Authorize(Roles = "1")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                TipoUsuarioRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //Modificar um TipoUsuario
        [Authorize(Roles = "1")]
        [HttpPut()]
        public IActionResult Put(TipoUsuarios tipo)
        {

            TipoUsuarioRepository.Editar(tipo);
            if (TipoUsuarioRepository.Editar(tipo) == null) { return NotFound(); }
            return Ok();

        }



    }



}