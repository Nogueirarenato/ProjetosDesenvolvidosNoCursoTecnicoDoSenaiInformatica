﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IEspecialidadeRepository
    {
        List<Especialidades> Listar();
        void Cadastrar(Especialidades especialidade);
        void Apagar(int id);
        Especialidades Editar(Especialidades especialidade);
    }
}
