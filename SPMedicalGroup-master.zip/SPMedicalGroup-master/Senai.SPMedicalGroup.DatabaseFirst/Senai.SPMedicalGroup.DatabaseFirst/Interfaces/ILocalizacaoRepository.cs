﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;



namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface ILocalizacaoRepository
    {
        void Cadastrar(Localizacoes localizacao);
        List<Localizacoes> ListarTodos();
    }
}
