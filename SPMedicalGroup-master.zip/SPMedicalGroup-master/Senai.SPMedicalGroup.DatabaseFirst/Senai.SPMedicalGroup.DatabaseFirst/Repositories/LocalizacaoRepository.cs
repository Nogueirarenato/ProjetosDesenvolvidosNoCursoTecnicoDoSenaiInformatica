﻿using MongoDB.Driver;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class LocalizacaoRepository : ILocalizacaoRepository
    {

        private readonly IMongoCollection<Localizacoes> _localizacoes;

        public LocalizacaoRepository()
        {
            // var client = new MongoClient("mongodb://localhost:27017");
            var client = new MongoClient("mongodb://localhost:27017/spmedicalgroup");

            var database = client.GetDatabase("spmedicalgroup");
            _localizacoes = database.GetCollection<Localizacoes>("mapas");
        }

        public void Cadastrar(Localizacoes localizacao)
        {
            _localizacoes.InsertOne(localizacao);
        }

        public List<Localizacoes> ListarTodos()
        {
            // _localizacoes.Find(null).ToList();
            return _localizacoes.Find(localizacao => true).ToList();
        }
    }
}
