﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class EspecialidadeRepository : IEspecialidadeRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();


        public void Apagar(int id)
        {
            Especialidades especialidadeProcurada = ctx.Especialidades.Find(id);
            ctx.Especialidades.Remove(especialidadeProcurada);
            ctx.SaveChanges();

        }


        public void Cadastrar(Especialidades especialidade)
        {
            ctx.Especialidades.Add(especialidade);
            ctx.SaveChanges();
        }

        public Especialidades Editar(Especialidades especialidade)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {

                Especialidades especialidadeExiste = ctx.Especialidades.Find(especialidade.Id);

                if (especialidadeExiste != null)
                {
                    especialidadeExiste.Medicos = especialidade.Medicos;
                    especialidadeExiste.Nome = especialidade.Nome;
                    ctx.Especialidades.Update(especialidadeExiste);
                    ctx.SaveChanges();

                    return especialidadeExiste;
                }

                return null;
            }
        }

        public List<Especialidades> Listar()
        {
            return (ctx.Especialidades.ToList());
        }
    }
}
