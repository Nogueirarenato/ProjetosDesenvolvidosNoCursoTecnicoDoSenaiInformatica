﻿using System;

namespace Senai.SPMedicalGroup.DatabaseFirst.Domains
{
    public partial class Consultas
    {
        public int Id { get; set; }
        public int? IdPaciente { get; set; }
        public int? IdMedico { get; set; }
        public DateTime DataConsulta { get; set; }
        public string DescricaoDaConsulta { get; set; }
        public int? IdStatus { get; set; }

        public Medicos IdMedicoNavigation { get; set; }
        public Pacientes IdPacienteNavigation { get; set; }
        public StatusConsulta IdStatusNavigation { get; set; }
    }
}
