﻿using MongoDB.Bson.Serialization.Attributes;

namespace Senai.SPMedicalGroup.DatabaseFirst.Domains
{
    public class Localizacoes
    {
        [BsonId]
        // _id
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string Id { get; set; }
        [BsonElement("latitude")]
        [BsonRequired]
        public string Latitude { get; set; }
        [BsonElement("longitude")]
        public string Longitude { get; set; }
        [BsonElement("doenca")]
        public string Doenca { get; set; }
        [BsonElement("idade")]
        public string Idade { get; set; }
        [BsonElement("especialidade")]
        public string Especialidade { get; set; }
    }
}
