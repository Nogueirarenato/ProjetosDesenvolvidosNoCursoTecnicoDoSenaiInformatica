using System;
using System.Collections.Generic;
using System.IO;
using CheckPoint.Models;
using CheckPointComentarios.Repositorios;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CheckPoint.Controllers
{   
    public class UsuarioController:Controller
    {     public string nomeComentario;
          public string cidadeComentario;

        [HttpGet]
         public ActionResult Cadastrar () {
            return View();
        }
        [HttpPost]
        public ActionResult Cadastrar (IFormCollection form) {            
            UsuarioModel usuario = new UsuarioModel(
                                            nome: form["nome"], 
                                            email: form["email"],
                                            senha: form["senha"],
                                            cidade: form["cidade"],
                                            tipo: "Usuario"
            );
            bool confirmaEmail=false;
            bool confirmaSenha=false;
            bool valido=true;
            string emailValido;
            string senhaValida;
            string nomeValido;
            string cidadeValida;
            string email2;
            string senha2;
            usuario.Nome=form["nome"];
            nomeValido=form["nome"];
            if(nomeValido=="")valido=false;
            if(valido==false){ViewBag.Mensagem2="Digite um nome válido!!!";
                return View(); 
                        }




            usuario.Email=form["email"];
            emailValido=form["email"];
            valido= emailValido.Contains("@") && emailValido.Contains(".");
            if(valido==false){ViewBag.Mensagem2="Digite um email válido!!!";
                return View(); 
                        }
            usuario.Email=usuario.Email.ToLower();
            email2=form["email2"];
            email2=email2.ToLower();
            if(usuario.Email==email2) confirmaEmail=true;
            usuario.Senha=form["senha"];

            senhaValida=form["senha"];
            if(senhaValida=="")valido=false;
            if(valido==false){ViewBag.Mensagem2="Digite uma senha válida!!!";
                return View(); 
                        }
            



            senha2=form["senha2"];
            if(usuario.Senha==senha2)confirmaSenha=true;
            usuario.Cidade=form["cidade"];
            cidadeValida=form["cidade"];
             if(cidadeValida=="")valido=false;
            if(valido==false){ViewBag.Mensagem2="Digite uma senha válida!!!";
                return View(); 
                        }
            

            

            bool existe=false;

        if (System.IO.File.Exists ("usuarios.csv")) existe=true;
        
        
        
            if(existe==false){ using (StreamWriter sw = new StreamWriter ("usuarios.csv", true)){sw.WriteLine("1;Administrador;admin@carfel.com;admin;São Paulo;administrador");}
                     }

            using(StreamReader sr = new StreamReader("usuarios.csv")){
                while(!sr.EndOfStream){
                    string [] linha = sr.ReadLine().Split(";");
                    if(linha[2] == form["email"]){ViewBag.Mensagem2="Email já cadastrado!!"; return View();}
                }}

            if(!confirmaEmail){ViewBag.Mensagem2="O email não foi digitado corretamente";
                return View(); 
                        }
            
            if(!confirmaSenha){ViewBag.Mensagem2="As senhas não coincidem";
                return View(); 
                        }

            UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorio();
            usuarioRepositorio.Cadastrar(usuario);

         TempData["Mensagem2"] = "Usuário Cadastrado com sucesso! Efetue Login";
           
            return RedirectToAction ("Login", "Usuario");
        }
    



       [HttpGet]
        public IActionResult Login(){
            return View();   
        }    
    
   
        [HttpPost]
        public IActionResult Login (IFormCollection form) {
          
            string email2 = form["email"];
            email2=email2.ToLower();

            UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorio();
            UsuarioModel usuario = usuarioRepositorio.Login(email2, form["senha"]);
            if(usuario!=null){

                    using(StreamReader sr = new StreamReader("usuarios.csv")){
                while(!sr.EndOfStream){
                    string [] linha = sr.ReadLine().Split(";");
                    if(linha[2] == email2){cidadeComentario=linha[4]; nomeComentario=linha[1];}
                }}



            if(usuario.Tipo == "Usuario"){

                

            
                HttpContext.Session.SetString("idUsuario", usuario.Id.ToString());
                HttpContext.Session.SetString("nomeUsuario", nomeComentario.ToString());
                HttpContext.Session.SetString("cidadeUsuario", cidadeComentario.ToString());
                HttpContext.Session.SetString("idAdministrador", "");
                return RedirectToAction ("InserirComentarios", "Lista");
            }

            if(usuario.Tipo == "administrador"){
               
               HttpContext.Session.SetString("idAdministrador", usuario.Id.ToString());
               HttpContext.Session.SetString("nomeUsuario", "Administrador");
                HttpContext.Session.SetString("cidadeUsuario", "São Paulo");
                HttpContext.Session.SetString("idUsuario", "");
                return RedirectToAction ("PainelAdm", "Principal");
            }}

            ViewBag.Mensagem = "Usuário e/ou senha inválidos";
            return View ();
        }



            [HttpGet]
            public IActionResult Listar () {
            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorio();

            ViewData["Usuarios"] = usuarioRepositorio.Listar();

            return View ();}
            TempData["Mensagem"] = "Você precisa ser administrador para acessar esta página";
            return RedirectToAction ("Login", "Usuario");
            
        }   
 
    
        [HttpGet]
        public IActionResult Excluir (int id) {
            
            UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorio();
            usuarioRepositorio.Excluir(id);

            TempData["Mensagem"] = "Usuário excluído";

            return RedirectToAction ("Listar");
        }
    
        [HttpGet]
        public IActionResult Sair(){
            HttpContext.Session.SetString("idAdministrador", "");
            HttpContext.Session.SetString("idUsuario", "");
            return RedirectToAction ("Index", "Principal");
        }    
    
      
  
    

    }

}