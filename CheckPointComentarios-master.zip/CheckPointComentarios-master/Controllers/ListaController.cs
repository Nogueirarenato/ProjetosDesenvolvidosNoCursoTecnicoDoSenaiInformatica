using CheckPoint.Controllers;
using CheckPoint.Models;
using CheckPointComentarios.Models;
using CheckPointComentarios.Repositorios;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;

namespace CheckPointComentarios.Controllers
{
    public class ListaController: Controller
    {
        

        [HttpGet]
        public IActionResult InserirComentarios(){
            if(HttpContext.Session.GetString("idUsuario")==""&& HttpContext.Session.GetString("idAdministrador")==""){
            
            TempData["Mensagem"] = "Você precisa estar logado para acessar esta página";
            return RedirectToAction ("Login", "Usuario");}
            if(HttpContext.Session.GetString("idUsuario")==null && HttpContext.Session.GetString("idAdministrador")==null){
            
            TempData["Mensagem"] = "Você precisa estar logado para acessar esta página";
            return RedirectToAction ("Login", "Usuario");}
            

            return View();   
        }    
        [HttpPost]
        public ActionResult InserirComentarios (IFormCollection form) {  

      
            
            ComentarioModel comentario = new ComentarioModel(
                                            id:1,
                                            nome2: HttpContext.Session.GetString("nomeUsuario"), 
                                            cidade2: HttpContext.Session.GetString("cidadeUsuario"),
                                            comentario: form["comentario"],
                                            aceito: false,
                                            data: DateTime.Now

            );
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();
            comentarioRepositorio.InserirComentarios(comentario);

           TempData["Mensagem3"] = "Comentário enviado para aprovação...";
           
           return RedirectToAction ("Depoimentos", "Lista");

    

        }

            [HttpGet]
            public IActionResult ListarComentarios () {

            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();

            ViewData["Comentarios"] = comentarioRepositorio.ListarComentarios();

            return View ();}
            TempData["Mensagem"] = "Você precisa ser administrador para acessar esta página";
            return RedirectToAction ("Login", "Usuario");

        }   

            [HttpGet]
             public IActionResult ExcluirComentario (string comentario) {
            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();
            comentarioRepositorio.ExcluirComentario(comentario);
            return RedirectToAction ("ListarComentarios");
            }
            TempData["Mensagem"] = "Você precisa ser administrador para acessar esta página";
            return RedirectToAction ("Login", "Usuario");
        }

      [HttpGet]
             public IActionResult AprovarComentarios (string comentario) {
            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();
            comentarioRepositorio.AprovarComentarios(comentario);

            

            return RedirectToAction ("ListarComentarios");}
            TempData["Mensagem"] = "Você precisa ser administrador para acessar esta página";
            return RedirectToAction ("Login", "Usuario");
            

        }

          [HttpGet]
            public IActionResult Depoimentos () {
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();
               using (StreamWriter sw = new StreamWriter ("ComentariosAprovados.csv", true)) {
            }
               using (StreamWriter sw = new StreamWriter ("comentarios.csv", true)) {
            }

            ViewData["Comentarios"] = comentarioRepositorio.Depoimentos();

            return View ();
        }   


          [HttpGet]
            public IActionResult ListarComentariosExcluidos () {

            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            ComentarioRepositorio comentarioRepositorio = new ComentarioRepositorio();

            ViewData["Comentarios"] = comentarioRepositorio.ListarComentariosExcluidos();

            return View ();}
            TempData["Mensagem"] = "Você precisa ser administrador para acessar esta página";
            return RedirectToAction ("Login", "Usuario");}




    }
}