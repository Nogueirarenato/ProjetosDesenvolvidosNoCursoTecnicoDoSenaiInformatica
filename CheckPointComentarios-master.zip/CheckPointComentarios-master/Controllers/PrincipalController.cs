using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Http;
using CheckPointComentarios.Models;


namespace CheckPoint.Controllers
{
    public class PrincipalController : Controller
    {
           [HttpGet]
        public IActionResult Carfel(){
            return View();   
        }    

           [HttpGet]
        public IActionResult Contato(){
            return View();   
        }    

           [HttpGet]
        public IActionResult Duvidas(){
            return View();   
        }    

           [HttpGet]
        public IActionResult Funcionamento(){
            return View();   
        }   

           [HttpGet]
        public IActionResult Historia(){
            return View();   
        }    

           [HttpGet]
        public IActionResult Index(){

            return View();   
        }    

           [HttpGet]
        public IActionResult Planos(){
            return View();   
        }     

            [HttpGet]
        public IActionResult Depoimentos(){
            return View();   
        }    

           
        [HttpGet]
        public IActionResult PainelAdm(){
            if(HttpContext.Session.GetString("idAdministrador")=="1"){
            return View();  }
            TempData["Mensagem"] = "Você precisa ser administrador para acessa esta página";
            return RedirectToAction ("Login", "Usuario");
        }    

        [HttpGet]
        public IActionResult InserirComentarios(){
            return View();   
        }   

    }
}