using System.Collections.Generic;
using System.IO;
using CheckPointComentarios.Models;
using CheckPointComentarios_master.Interfaces;
using CheckPoint.Models;
using System;
using System.Linq;


namespace CheckPointComentarios.Repositorios
{
    public class ComentarioRepositorio : ILista
    {
        public ComentarioModel InserirComentarios (ComentarioModel comentario)
        {
                
          

            //Grava as informações no arquivo usuarios.csv
            using (StreamWriter sw = new StreamWriter ("comentarios.csv", true)) {
                sw.WriteLine ($"{comentario.Comentario};{comentario.Nome2};{comentario.Cidade2};{comentario.Aceito};{comentario.Data}");
            

            return comentario;
        }}


         public List<ComentarioModel> ListarComentarios()
        {
            List <ComentarioModel> lsComentarios = new List <ComentarioModel> ();

            string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");

            ComentarioModel comentario;

            foreach (var item in linhas) {

                //Verifica se a linha é vazia
                if (string.IsNullOrEmpty (item)) {
                    //Retorna para o foreach
                    continue;
                }

                string[] linha = item.Split (';');

                comentario = new ComentarioModel (
                                            id:1,
                                            nome2: linha[1],
                                            comentario: linha[0],
                                            cidade2: linha[2],
                                            aceito: bool.Parse(linha[3]),
                                            data: DateTime.Parse( linha[4])

                                            
                                        );

                lsComentarios.Add (comentario);
            }

            return lsComentarios;
        }




        public void ExcluirComentario(string comentario)
        {
            //Pega os dados do arquivo comentarios.csv
            string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");

            //Percorre as linhas do arquivo
            for (int i = 0; i < linhas.Length; i++) {
                //Separa as colunas da linha
                string[] linha = linhas[i].Split (';');

                //Verifica se o id da linha é o id passado
                if (comentario == linha[0]) {
                       using (StreamWriter sw = new StreamWriter ("ComentariosExcluidos.csv", true)) {
                sw.WriteLine ($"{linha[0]};{linha[1]};{linha[2]};{linha[4]}");
                  }

                    //Defino a linha como vazia
                    linhas[i] = "excluido;excluido;excluido;False;25/04/1987 00:00:00";
                    break;
                }
            }

            //Armazeno no arquivo csv todas as linhas
            System.IO.File.WriteAllLines ("comentarios.csv", linhas);
        }

        public ComentarioModel AprovarComentarios(string comentario)
        {
            
          
            //Pega os dados do arquivo comentarios.csv
            string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");

            //Percorre as linhas do arquivo
            for (int i = 0; i < linhas.Length; i++) {
                //Separa as colunas da linha
                string[] linha = linhas[i].Split (';');


                 if (linha[0]!="Aprovado" && linha[0]!="excluido") {


                                                            
            

                //Verifica se o id da linha é o id passado
                if (comentario == linha[0]) {


                                                                int id;

                                                    //Verifica se o arquivo existe
                                                if(File.Exists("ComentariosAprovados.csv")){
                                                    //Se arquivo existe Pega a quantidade de linhas e incrementa 1
                                                    id = File.ReadAllLines("ComentariosAprovados.csv").Length + 1;
                                                } else {
                                                    //caso não exista seta como 1
                                                    id = 1;
                                                }

                    //Grava as informações no arquivo ComentariosAprovados.csv
                 using (StreamWriter sw = new StreamWriter ("ComentariosAprovados.csv", true)) {
                sw.WriteLine ($"{id};{linha[0]};{linha[1]};{linha[2]};{linha[4]}");
            }





                    //Defino a linha como vazia
                    linhas[i] = ("Aprovado;Aprovado;Aprovado;True;01/12/2018 16:35:23");
                    break;
                }
            }
    }
            //Armazeno no arquivo csv todas as linhas
            System.IO.File.WriteAllLines ("comentarios.csv", linhas);
            return null;


        }

        public List<ComentarioModel> Depoimentos()
        {
            List <ComentarioModel> lsComentarios = new List <ComentarioModel> ();
            

            string[] linhas = System.IO.File.ReadAllLines ("comentariosAprovados.csv");
            
            ComentarioModel comentario;

            foreach (var item in linhas) {
               
                //Verifica se a linha é vazia
                if (string.IsNullOrEmpty (item)) {
                    //Retorna para o foreach
                    continue;
                }

                string[] linha = item.Split (';');

                comentario = new ComentarioModel (
                                            id: int.Parse(linha[0]),
                                            comentario: linha[1],
                                            nome2: linha[2],
                                            cidade2: linha[3],
                                            aceito: true,
                                            data: DateTime.Parse(linha[4])
                                                                                       
                                        );
               
                lsComentarios.Add(comentario);
                
            }
            
            lsComentarios.Reverse(); 
             
            return lsComentarios;
            
     
        }

        public List<ComentarioModel> ListarComentariosExcluidos()
        {
            List <ComentarioModel> lsComentarios = new List <ComentarioModel> ();

            string[] linhas = System.IO.File.ReadAllLines ("ComentariosExcluidos.csv");

            ComentarioModel comentario;

            foreach (var item in linhas) {

                //Verifica se a linha é vazia
                if (string.IsNullOrEmpty (item)) {
                    //Retorna para o foreach
                    continue;
                }

                string[] linha = item.Split (';');

                comentario = new ComentarioModel (
                                            id:1,
                                            nome2: linha[1],
                                            comentario: linha[0],
                                            cidade2: linha[2],
                                            data: DateTime.Parse( linha[3]),
                                            aceito: true

                                            
                                        );

                lsComentarios.Add (comentario);
            }

            return lsComentarios;
        }












    }
}
