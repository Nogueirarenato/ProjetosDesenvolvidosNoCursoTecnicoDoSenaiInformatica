using System;
using Microsoft.Extensions.Primitives;
using CheckPointComentarios.Models;

namespace CheckPoint.Models
{
    public class UsuarioModel
    {

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public string Tipo { get; set; }
        public string Cidade {get; set;}

        public UsuarioModel(string nome, string email, string senha, string cidade, string tipo)
        {
            this.Nome = nome;
            this.Email = email;
            this.Senha = senha;
            this.Cidade = cidade;
            this.Tipo = tipo;
        }

        public UsuarioModel(int id, string nome, string email, string senha, string cidade, string tipo)
        {
            this.Id = id;
            this.Nome = nome;
            this.Email = email;
            this.Senha = senha;
            this.Cidade = cidade;
            this.Tipo = tipo;
        }
 
    }
}