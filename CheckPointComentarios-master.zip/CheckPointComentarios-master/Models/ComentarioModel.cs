using CheckPoint.Controllers;
using CheckPointComentarios.Repositorios;
using CheckPointComentarios.Models;
using System;



namespace CheckPointComentarios.Models
{
    public class ComentarioModel 
    {
        public int Id {get;set;}
        public string Nome2 { get; set; }
        public string Comentario { get; set; }
        public string Cidade2 {get; set;}
        public bool Aceito {get; set;}

        public DateTime Data {get;set;}



        public ComentarioModel(int id, string nome2, string comentario, string cidade2, bool aceito, DateTime data)
        {
            this.Id = id;
            this.Nome2= nome2;
            this.Comentario= comentario;
            this.Cidade2= cidade2;
            this.Aceito= aceito;
            this.Data=data;

        }
    }
}