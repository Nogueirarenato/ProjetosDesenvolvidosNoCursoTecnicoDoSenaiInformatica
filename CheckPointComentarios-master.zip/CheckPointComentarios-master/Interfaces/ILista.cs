using System.Collections.Generic;
using CheckPointComentarios.Models;
using CheckPoint.Models;
using System.IO;
using CheckPointComentarios_master.Interfaces;



namespace CheckPointComentarios_master.Interfaces
{
    public interface ILista
    {
        
   
        /// <summary>
        /// Lista todos os comentarios
        /// </summary>
        /// <returns>Retorna um List<ComentarioModel></returns>
         List<ComentarioModel> ListarComentarios();


         /// <summary>
        /// Cadastrar um novo comentario
        /// </summary>
        /// <param name="comentario">ComentarioModel</param>
        /// <returns>Retorna um comentario</returns>
         ComentarioModel InserirComentarios(ComentarioModel comentario);


        /// <summary>
        /// Exclui um comentario 
        /// </summary>
        /// <param name="comentario">comentario</param>
         void ExcluirComentario(string comentario);

        /// <summary>
        /// Cadastrar um novo comentario
        /// </summary>
        /// <param name="comentario">ComentarioModel</param>
        /// <returns>Retorna um comentario</returns>
         ComentarioModel AprovarComentarios(string comentario);


         /// <summary>
        /// Lista todos os comentarios aprovados
        /// </summary>
        /// <returns>Retorna um List<ComentarioModel></returns>
         List<ComentarioModel> Depoimentos();

         

}}