﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class EspecialidadeController : ControllerBase
    {


        private IEspecialidadeRepository EspecialidadeRepository { get; set; }

        public EspecialidadeController()
        {
            EspecialidadeRepository = new EspecialidadeRepository();
        }


        //Listar as especialidades
        [Authorize]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
               
                    return Ok(EspecialidadeRepository.Listar());
                
            }

            catch
            {
                return BadRequest();
            }
        }


        //Adicionar Uma Especialidade
        [Authorize]
        [HttpPost]
        public IActionResult Post(Especialidades especialidade)
        {
            try
            {
                EspecialidadeRepository.Cadastrar(especialidade);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar uma Especialidade
        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                EspecialidadeRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //Modificar uma especialidade
        [Authorize]
        [HttpPut()]
        public IActionResult Put(Especialidades especialidade)
        {
            
                EspecialidadeRepository.Editar(especialidade);
                if(EspecialidadeRepository.Editar(especialidade)==null) { return NotFound(); }
                return Ok();
          
        }




    }
}