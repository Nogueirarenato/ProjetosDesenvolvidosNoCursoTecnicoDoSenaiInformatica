﻿using System;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;
using Senai.SPMedicalGroup.DatabaseFirst.ViewModels;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IMedicoRepository MedicoRepository { get; set; }
        private IPacienteRepository PacienteRepository { get; set; }


        public LoginController()
        {
            MedicoRepository = new MedicoRepository();
            PacienteRepository = new PacienteRepository();
        }


        [HttpPost]
        public IActionResult Post(LoginViewModel login)
        {
                //Verifica se o usuario buscado está entre os médicos
                Medicos medicoBuscado = MedicoRepository.BuscarPorEmailSenha(login.Email, login.Senha);

         


                    if (medicoBuscado!=null)
                {
                    //Define os dados que serão fornecidos no token - PayLoad
                    var claims = new[]
                    {
                    new Claim(JwtRegisteredClaimNames.Email, medicoBuscado.Email),
                    new Claim(JwtRegisteredClaimNames.Jti, medicoBuscado.Id.ToString()),
                    new Claim(ClaimTypes.Role, medicoBuscado.IdUsuario.ToString()),

                };

                    // Chave de acesso do token
                    var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("spmedicalgroup-chave-autenticacao"));

                    //Credenciais do Token - Header
                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    //Gera o token
                    var token = new JwtSecurityToken(
                        issuer: "Senai.SPMedicalGroup.DatabaseFirst",
                        audience: "Senai.SPMedicalGroup.DatabaseFirst",
                        claims: claims,
                        expires: DateTime.Now.AddMinutes(30),
                        signingCredentials: creds
                    );

                    //Retorna Ok com o Token
                    return Ok(new
                    {
                        token = new JwtSecurityTokenHandler().WriteToken(token)
                    });

                }



                if (medicoBuscado == null)
                {
                    // Caso não esteja entre os médicos, verifica se o usuário buscado está entre os pacientes
                    Pacientes pacienteBuscado = PacienteRepository.BuscarPorEmailSenha(login.Email, login.Senha);
                    


                    if(pacienteBuscado.IdUsuario == 1 || pacienteBuscado.IdUsuario == 3)
                    {
                       
                            //Define os dados que serão fornecidos no token - PayLoad
                            var claims = new[]
                            {
                    new Claim(JwtRegisteredClaimNames.Email, pacienteBuscado.Email),
                    new Claim(JwtRegisteredClaimNames.Jti, pacienteBuscado.Id.ToString()),
                    new Claim(ClaimTypes.Role, pacienteBuscado.IdUsuario.ToString()),

                };

                            // Chave de acesso do token
                            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("spmedicalgroup-chave-autenticacao"));

                            //Credenciais do Token - Header
                            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                            //Gera o token
                            var token = new JwtSecurityToken(
                                issuer: "Senai.SPMedicalGroup.DatabaseFirst",
                                audience: "Senai.SPMedicalGroup.DatabaseFirst",
                                claims: claims,
                                expires: DateTime.Now.AddMinutes(30),
                                signingCredentials: creds
                            );

                            //Retorna Ok com o Token
                            return Ok(new
                            {
                                token = new JwtSecurityTokenHandler().WriteToken(token)
                            });

                        }





                    Exception ek;

                    //Caso também não esteja entre os pacientes, retorna uma mensagem de erro
                    if (pacienteBuscado == null) return BadRequest (new { mensagem = "Email ou senha inválido" });

                }
                return BadRequest(new { mensagem = "Email ou senha inválido" });

            
        }
    
}
}