﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PacienteController : ControllerBase
    {

        private IPacienteRepository PacienteRepository { get; set; }

        public PacienteController()
        {
            PacienteRepository = new PacienteRepository();
        }


        //Listar as pacientes
        
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                
                return Ok(PacienteRepository.Listar());

            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Um Paciente
        [Authorize]
        [HttpPost]
        public IActionResult Post(Pacientes paciente)
        {
            try
            {
                PacienteRepository.Cadastrar(paciente);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar um Paciente
        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                PacienteRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //Modificar um Paciente
        [HttpPut()]
        public IActionResult Put(Pacientes paciente)
        {

            PacienteRepository.Editar(paciente);
            if (PacienteRepository.Editar(paciente) == null) { return NotFound(); }
            return Ok();

        }

    }
}
