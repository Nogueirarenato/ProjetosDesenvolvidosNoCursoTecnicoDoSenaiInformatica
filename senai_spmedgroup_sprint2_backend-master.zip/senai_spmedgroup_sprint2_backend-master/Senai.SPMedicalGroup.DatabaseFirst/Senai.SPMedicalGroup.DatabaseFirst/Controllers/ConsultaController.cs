﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaController : ControllerBase
    {
       
        private IConsultaRepository ConsultaRepository { get; set; }

        public ConsultaController()
        {
            ConsultaRepository = new LocalRepositories();
        }

        //Listar as consultas
        //[Authorize (Roles="1")]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                return Ok (ConsultaRepository.Listar());
            }

            catch
            {
                return BadRequest();
            }
        }


        //Listar todas as consultas de um determinado médico
        [Authorize (Roles = "2")]
        [HttpGet ("/Medico/ExibirMinhasConsultas")]
        public IActionResult GetMedicoConsultas(int id)
        {
            id = Convert.ToInt32(HttpContext.User.Claims.First(c => c.Type == JwtRegisteredClaimNames.Jti).Value);
            


            try
            {
                return Ok(ConsultaRepository.ListarMedicoConsultas(id));
            }

            catch
            {
                return BadRequest();
            }
        }



        //Adicionar Uma Consulta
        [Authorize ]
        [HttpPost]
        public IActionResult Post(Consultas consulta)
        {
            try
            {
                ConsultaRepository.Cadastrar(consulta);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Deletar uma consulta
        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                ConsultaRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

        }



        //Modificar uma consulta
        [Authorize]
        [HttpPut()]
        public IActionResult Put(Consultas consulta)
        {

            ConsultaRepository.Editar(consulta);
            if (ConsultaRepository.Editar(consulta) == null) { return NotFound(); }
            return Ok();

        }


        //Modificar uma consulta
       // [Authorize (Roles = "2") ]
        [HttpPut("/Medico/EditarConsultaMedico")]
        public IActionResult PutMedico(Consultas consulta)
        {

            ConsultaRepository.EditarMedico(consulta);
            if (ConsultaRepository.EditarMedico(consulta) == null) { return NotFound(); }
            return Ok();

        }


    }
}