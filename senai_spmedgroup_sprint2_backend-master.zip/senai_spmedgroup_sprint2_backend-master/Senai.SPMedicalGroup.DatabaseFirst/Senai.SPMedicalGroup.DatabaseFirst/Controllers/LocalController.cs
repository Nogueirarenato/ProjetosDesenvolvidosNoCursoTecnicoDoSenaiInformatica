﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LocalController : ControllerBase
    {
        private ILocalRepository LocalRepository { get; set; }

        public LocalController()
        {
            LocalRepository = new LocalRepository();
        }


        //Listar as clínicas (locais)
       
        [HttpGet]
            public IActionResult Get()
            {
                try
                {
                
                return Ok(LocalRepository.Listar());


                }

                catch
                {
                    return BadRequest();
                }
            }




        //Adicionar Um Local
        [Authorize]
        [HttpPost]
        public IActionResult Post(Locais local)
        {
            try
            {
                LocalRepository.Cadastrar(local);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar um Local
        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                LocalRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //Modificar um Local
        [Authorize]
        [HttpPut()]
        public IActionResult Put(Locais local)
        {

            LocalRepository.Editar(local);
            if (LocalRepository.Editar(local) == null) { return NotFound(); }
            return Ok();

        }


    }
}