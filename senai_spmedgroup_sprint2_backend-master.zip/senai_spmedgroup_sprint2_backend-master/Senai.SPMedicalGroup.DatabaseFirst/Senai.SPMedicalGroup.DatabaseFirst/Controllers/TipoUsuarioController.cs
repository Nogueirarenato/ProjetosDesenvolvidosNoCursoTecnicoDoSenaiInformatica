﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using Senai.SPMedicalGroup.DatabaseFirst.Repositories;

namespace Senai.SPMedicalGroup.DatabaseFirst.Controllers
{

    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class TipoUsuarioController : ControllerBase
    {

        private ITipoUsuarioRepository TipoUsuarioRepository { get; set; }

        public TipoUsuarioController()
        {
            TipoUsuarioRepository = new TipoUsuarioRepository();
        }



        //Listar os tipos de usuarios
        [Authorize]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                
                return Ok(TipoUsuarioRepository.Listar());
            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Um Tipo de Usuario
        [Authorize]
        [HttpPost]
        public IActionResult Post(TipoUsuarios tipoUsuario)
        {
            try
            {
                TipoUsuarioRepository.Cadastrar(tipoUsuario);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Apagar um tipo de usuario
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                TipoUsuarioRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //Modificar um TipoUsuario
        [HttpPut()]
        public IActionResult Put(TipoUsuarios tipo)
        {

            TipoUsuarioRepository.Editar(tipo);
            if (TipoUsuarioRepository.Editar(tipo) == null) { return NotFound(); }
            return Ok();

        }



    }



}