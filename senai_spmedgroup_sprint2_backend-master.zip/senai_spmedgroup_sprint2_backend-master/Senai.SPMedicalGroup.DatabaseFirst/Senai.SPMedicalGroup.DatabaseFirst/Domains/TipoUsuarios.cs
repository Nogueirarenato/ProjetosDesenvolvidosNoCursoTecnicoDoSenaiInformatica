﻿using System;
using System.Collections.Generic;

namespace Senai.SPMedicalGroup.DatabaseFirst.Domains
{
    public partial class TipoUsuarios
    {
        public TipoUsuarios()
        {
            Medicos = new HashSet<Medicos>();
            Pacientes = new HashSet<Pacientes>();
        }

        public int Id { get; set; }
        public string TipoDeUsuario { get; set; }

        public ICollection<Medicos> Medicos { get; set; }
        public ICollection<Pacientes> Pacientes { get; set; }
    }
}
