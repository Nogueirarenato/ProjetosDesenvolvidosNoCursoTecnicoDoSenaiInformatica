﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IPacienteRepository
    {
        List<Pacientes> Listar();
        void Cadastrar(Pacientes paciente);
        void Apagar(int id);
        Pacientes Editar(Pacientes paciente);
        Pacientes BuscarPorEmailSenha(string Email, string Senha);


    }
}
