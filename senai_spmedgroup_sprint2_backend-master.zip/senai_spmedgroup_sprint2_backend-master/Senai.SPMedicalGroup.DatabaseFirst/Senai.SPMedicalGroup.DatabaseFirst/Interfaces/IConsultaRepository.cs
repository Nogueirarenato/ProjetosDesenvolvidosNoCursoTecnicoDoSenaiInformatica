﻿using System;
using System.Collections.Generic;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IConsultaRepository
    {
        List <Consultas> Listar();
        List<Consultas> ListarMedicoConsultas(int id);
        void Cadastrar(Consultas consulta);
        void Apagar(int id);
        Consultas Editar(Consultas consulta);
        Consultas EditarMedico(Consultas consulta);
    }
}
