﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IMedicoRepository
    {
        

        List<Medicos> Listar();
        void Cadastrar(Medicos medico);
        void Apagar(int id);
        Medicos Editar(Medicos medico);
        Medicos BuscarPorEmailSenha(string Email, string Senha);
       
    }
}
