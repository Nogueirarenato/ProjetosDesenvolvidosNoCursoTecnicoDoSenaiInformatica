﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class MedicoRepository : IMedicoRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();


        public void Apagar(int id)
        {
            Medicos MedicoProcurado = ctx.Medicos.Find(id);
            ctx.Medicos.Remove(MedicoProcurado);
            ctx.SaveChanges();
        }

        public Medicos BuscarPorEmailSenha(string Email, string Senha)
        {
            Medicos medicoProcurado = new Medicos();
            medicoProcurado = ctx.Medicos.ToList().Find(c => c.Email == Email);

            if (medicoProcurado == null) {
                return (medicoProcurado);
            }

            else
            {
                if (medicoProcurado.Email == Email && medicoProcurado.Senha == Senha)
                    return (medicoProcurado);
            }

            if (medicoProcurado.IdUsuario != 2)
            {
                medicoProcurado.Id = 0;
                return (medicoProcurado);


            }

            return medicoProcurado;
        }

        public void Cadastrar(Medicos medico)
        {
            ctx.Medicos.Add(medico);
            ctx.SaveChanges();
        }

        public Medicos Editar(Medicos medico)
        {
            
                using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
                {

                    Medicos medicoExiste = ctx.Medicos.Find(medico.Id);

                    if (medicoExiste != null)
                    {
                    medicoExiste.Nome = medico.Nome;
                    medicoExiste.Email = medico.Email;
                    medicoExiste.Senha = medico.Senha;
                    medicoExiste.Crm = medico.Crm;
                        ctx.Medicos.Update(medicoExiste);
                        ctx.SaveChanges();

                        return medicoExiste;
                    }

                    return null;
                }
            
        }

        public List<Medicos> Listar()
        {
            return (ctx.Medicos.ToList());
        }

        public int pegarIdMedico()
        {
            throw new NotImplementedException();
        }
    }
}
