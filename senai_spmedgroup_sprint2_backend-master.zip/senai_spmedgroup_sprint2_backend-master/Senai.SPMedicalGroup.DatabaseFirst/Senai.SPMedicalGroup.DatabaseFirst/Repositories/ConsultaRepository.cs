﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{

   
    

    public class LocalRepositories : IConsultaRepository
    {
        
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();

        public void Cadastrar(Consultas consulta)
        {
            ctx.Consultas.Add(consulta);
            ctx.SaveChanges();
        }

        public void Apagar(int id)
        {
            Consultas consultaProcurada = ctx.Consultas.Find(id);
            ctx.Consultas.Remove(consultaProcurada);
            ctx.SaveChanges();
        
    }

        public List<Consultas> Listar()
        {
            return (ctx.Consultas.ToList());
        }

        public Consultas Editar(Consultas consulta)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {
                

                    Consultas consultaExiste = ctx.Consultas.Find(consulta.Id);

                    if (consultaExiste != null)
                    {
                        consultaExiste.IdMedico = consulta.IdMedico;
                        consultaExiste.IdPaciente = consulta.IdPaciente;
                        consultaExiste.IdStatus = consulta.IdStatus;
                        consultaExiste.DataConsulta = consulta.DataConsulta;
                        consultaExiste.DescricaoDaConsulta = consulta.DescricaoDaConsulta;
                        ctx.Consultas.Update(consultaExiste);
                        ctx.SaveChanges();

                        return consultaExiste;
                    }

                    return null;
                }
            }

        public List<Consultas> ListarMedicoConsultas(int id)
        {
            

            return (ctx.Consultas.ToList().FindAll(c => c.IdMedico == id));
        }




        public Consultas EditarMedico(Consultas consulta)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {


                Consultas consultaExiste = ctx.Consultas.Find(consulta.Id);

                if (consultaExiste != null)
                {
                    consultaExiste.IdMedico = consultaExiste.IdMedico;
                    consultaExiste.IdPaciente = consultaExiste.IdPaciente;
                    consultaExiste.IdStatus = consulta.IdStatus;
                    consultaExiste.DataConsulta = consultaExiste.DataConsulta;
                    consultaExiste.DescricaoDaConsulta = consulta.DescricaoDaConsulta;
                    ctx.Consultas.Update(consultaExiste);
                    ctx.SaveChanges();

                    return consultaExiste;
                }

                Exception er;

                return null;
            }
        }






    }
}

