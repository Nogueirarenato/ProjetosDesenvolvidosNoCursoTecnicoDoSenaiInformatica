﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{


    public class LocalRepository : ILocalRepository
    {

        SPMedicalGroupContext ctx = new SPMedicalGroupContext();

        public void Apagar(int id)
        {
            Locais localProcurado = ctx.Locais.Find(id);
            ctx.Locais.Remove(localProcurado);
            ctx.SaveChanges();
        }

        public void Cadastrar(Locais local)
        {
            ctx.Locais.Add(local);
            ctx.SaveChanges();
        }

        public Locais Editar(Locais local)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {


                Locais localExiste = ctx.Locais.Find(local.Id);

                if (localExiste != null)
                {
                    localExiste.Nome = local.Nome;
                    localExiste.RazaoSocial = local.RazaoSocial;
                    localExiste.Cnpj = local.Cnpj;
                    localExiste.Endereco = local.Endereco;

                    ctx.Locais.Update(localExiste);
                    ctx.SaveChanges();

                    return localExiste;
                }

                return null;
            }
        }



        public List<Locais> Listar()
        {
            using (SPMedicalGroupContext spctx = new SPMedicalGroupContext())
            {
                return (spctx.Locais.Include(c => c.Medicos).ToList());
            }

        }
    }
}
