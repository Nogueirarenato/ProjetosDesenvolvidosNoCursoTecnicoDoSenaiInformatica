﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class TipoUsuarioRepository : ITipoUsuarioRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();

        public void Apagar(int id)
        {
           TipoUsuarios tipoProcurado = ctx.TipoUsuarios.Find(id);
            ctx.TipoUsuarios.Remove(tipoProcurado);
            ctx.SaveChanges();
        }

        public void Cadastrar(TipoUsuarios tipoUsuarios)
        {
            ctx.TipoUsuarios.Add(tipoUsuarios);
            ctx.SaveChanges();
        }

        public TipoUsuarios Editar(TipoUsuarios tipo)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {

                TipoUsuarios tipoExiste = ctx.TipoUsuarios.Find(tipo.Id);

                if (tipoExiste != null)
                {
                    tipoExiste.TipoDeUsuario = tipo.TipoDeUsuario ;
                    ctx.TipoUsuarios.Update(tipoExiste);
                    ctx.SaveChanges();

                    return tipoExiste;
                }

                return null;
            }
        }

        public List<TipoUsuarios> Listar()
        {
            return (ctx.TipoUsuarios.ToList());
        }
    }
}
