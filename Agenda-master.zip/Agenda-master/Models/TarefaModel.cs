
using System;

namespace Agenda.Models
{
    public class TarefaModel
    {
        public int Numero {get; set;}
        public string Titulo {get; set;}

        public string Descricao {get; set;}

        public string Tipo {get; set;}

        public int IdUsuario {get;set;}

        public DateTime DataCriacao {get;set;}



    }
}