using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Agenda.Models;

namespace Agenda.Controllers {
    public class UsuarioController : Controller {
        [HttpGet]
        public ActionResult Cadastrar () {
            return View ();
        }

        [HttpPost]
        public ActionResult Cadastrar (IFormCollection form) {
            Models.UsuarioModel usuario = new Models.UsuarioModel ();

            if (!System.IO.File.Exists ("usuario.cvs")) { using (StreamWriter sw = new StreamWriter ("usuario.csv", true)); } //verifica se existe um arquivo usuario.csv
            int numeroLinhas = System.IO.File.ReadAllLines ("usuario.csv").Length; // Lê a quantidade de linhas do arquivo csv;

            do {
                usuario.Nome = form["nome"]; //solicita o nome e retorna erro caso o nome seja vazio
                if (form["nome"] == "") {
                    ViewBag.Mensagem = "Nome Inválido";
                    return View ();
                }
            } while (form["nome"] == "");

            usuario.Id = numeroLinhas + 1; //cria a id do usuário de acordo com a quantidade de linhas do arquivo usuario.csv
        
            bool valido = false;
            do {
                usuario.Email = form["email"]; //solicita o email e confere se é válido, ou seja se tem @ e . e confere se tem no mínimo 5 caracteres
                

            using(StreamReader sr = new StreamReader("usuario.csv")){
                while(!sr.EndOfStream){
                    string [] linha = sr.ReadLine().Split(";");
                    if(linha[3] == form["email"]){ViewBag.Mensagem="Email já cadastrado!!"; return View();}
                }}



                valido = usuario.Email.Contains ("@") && usuario.Email.Contains (".");
                if (usuario.Email.Length <= 5) valido = false;
                if (valido == false) { ViewBag.Mensagem = "Digite um email válido!!"; return View (); }
            } while (valido == false);

            valido = false;
            do {
                usuario.Senha = form["senha"]; //cria a senha
                string confirmasenha = form["confirmaSenha"]; //verifica se as senhas foram digitadas iguais
                if (form["senha"] != form["confirmaSenha"]) { ViewBag.Mensagem = "As Senhas não conferem!"; return View (); } else valido = true;
                if (usuario.Senha.Length < 6) { ViewBag.Mensagem = "Senha muito curta, digite no mínimo 6 caracteres"; valido = false; return View (); }

            } while (valido == false);

            usuario.Tipo = "usuario"; //determina que todos os usuários são apenas usuários e não administradores;
            usuario.DataCriacao = DateTime.Now;

            using (StreamWriter sw = new StreamWriter ("usuario.csv", true)) {
                sw.WriteLine ($"{usuario.Id};{usuario.Tipo};{usuario.Nome};{usuario.Email};{usuario.Senha};{usuario.DataCriacao};");

            }
            ViewBag.Mensagem = "Usuário Cadastrado Com Sucesso!";
            return View ();
            
        }


        [HttpGet]
        public IActionResult Login(){
            return View();
        }

        [HttpPost]
        public IActionResult Login (IFormCollection form){
        UsuarioModel usuario = new UsuarioModel();
        usuario.Email =form["email"];
        usuario.Senha = form["senha"];

        using(StreamReader sr = new StreamReader("usuario.csv")){
            while(!sr.EndOfStream)
            {
                string[] dados =sr.ReadLine().Split(";");

                if(dados[3]==usuario.Email && dados[4]==usuario.Senha)
                {
                    HttpContext.Session.SetString("emailUsuario", usuario.Email);
                    return RedirectToAction("BemVindo", "Tarefa");
                }
            }

        }




        ViewBag.Mensagem = "Usuario inválido";
        return View();












        }
    }
}