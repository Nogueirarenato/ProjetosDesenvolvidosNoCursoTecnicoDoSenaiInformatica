using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Agenda.Models;


namespace Agenda.Controllers
{
    public class TarefaController : Controller 
    {


 [HttpGet]
        public IActionResult BemVindo(){
            if(string.IsNullOrEmpty(HttpContext.Session.GetString("emailUsuario"))){
                return RedirectToAction("Login", "Usuario");
            }
            
        return View();
        }
    
    
        [HttpPost]
        public IActionResult BemVindo(IFormCollection form){


                      
            return View();
        }







        
    
      [HttpGet]
        public IActionResult CadastrarAtividade(){
            if(string.IsNullOrEmpty(HttpContext.Session.GetString("emailUsuario"))){
                return RedirectToAction("Login", "Usuario");
            }
            
        return View();
        }
    
    
        [HttpPost]
        public IActionResult CadastrarAtividade(IFormCollection form){


            TarefaModel tarefa = new TarefaModel();
            tarefa.Titulo=form["titulo"];
            tarefa.Descricao=form["descricao"];
            tarefa.Tipo=form["tipo2"];
            tarefa.Numero=1;
            tarefa.IdUsuario=1;

            
            tarefa.DataCriacao=DateTime.Now;

            using(StreamWriter sw =new StreamWriter("tarefas.csv",true)){
                sw.WriteLine($"{tarefa.IdUsuario};{tarefa.Numero};{tarefa.DataCriacao};{tarefa.Tipo};{tarefa.Titulo};{tarefa.Descricao};");
            }






            
            return View();
        }
    
     [HttpGet]
        public IActionResult Visualizar(){
            if(string.IsNullOrEmpty(HttpContext.Session.GetString("emailUsuario"))){
                return RedirectToAction("Login", "Usuario");
            }
            
        return View();
        }
    
    
        [HttpPost]
        public IActionResult Visualizar(IFormCollection form){


                       
            return View();
        }
     
    
    
    
    }
}