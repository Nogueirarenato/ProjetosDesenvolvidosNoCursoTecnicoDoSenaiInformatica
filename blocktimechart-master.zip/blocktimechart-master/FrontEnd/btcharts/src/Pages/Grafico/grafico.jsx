
import React, { Component } from 'react';
import './grafico.css'
import Url from '../../Services/apiService'
import { Bar } from 'react-chartjs-2';
import CriarArrayX from '../../Services/CriarArrayX'
import { tsRestType } from '../../../node_modules/@babel/types';

let horario
let contador2 = 0
let hosts = []
let trigger = []
let final = []
let contador = 0
let hosts2 = [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]]
let inicio = localStorage.getItem("dataInicial")
let fim = localStorage.getItem("dataFinal")
let dadosGraficos = CriarArrayX(inicio, fim)
let dadosGraficosTamanho = dadosGraficos.length
let exibir = ""
let f = parseInt(fim) + 82798
let i = parseInt(inicio) - 3600
if (dadosGraficosTamanho > 61) exibir = "rgba(0,0,0,0)"
else exibir = "rgba(0,0,0)"

class Grafico extends Component {
    constructor() {
        super();
        this.state = {
            userLogado: localStorage.getItem("usuario-blocktime"),
            dataInicial: i,
            dataFinal: f,
            grouphostid: localStorage.getItem("Grouphostid"),
            hostName: "",
            triggerId: "",
            teste: []
        }
    }
    componentDidMount() {
        document.title = "Relatório de " + localStorage.getItem("GroupName")
        this.ColetarHosts()
        console.log(dadosGraficos.length)
    }

    async ColetarHosts() {
        let bodyCriado = {
            jsonrpc: "2.0",
            method: "host.get",
            params: {
                output: ["hostid", "host"],
                groupids: this.state.grouphostid,
                hostids: ["11362", "11368"] //limitador de dados, retirar ao final
            },
            auth: this.state.userLogado,
            id: 1
        }

        let dado = await fetch(Url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(bodyCriado)
        })
        let data = await dado.json()
        hosts = await data.result
        this.coletarTriggers()
    }

    coletarTriggers() {
        hosts.map(async (element) => {
            let bodyCriado = {
                jsonrpc: "2.0",
                method: "trigger.get",
                params: {
                    hostids: element.hostid,
                    output: ["triggerid", "description"]
                },
                auth: this.state.userLogado,
                id: 1
            }

            let dado = await fetch(Url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bodyCriado)
            })
            let data = await dado.json()
            let formando = {
                host: element.host,
                hostId: element.hostid,
                trigger: data.result,
                ocorrencias: [],
            }

            formando.trigger.map(element => {
                element.vetor = []
                let cont = 1;
                while (cont <= dadosGraficosTamanho) {
                    element.vetor.push(0)
                    cont++
                }
            })
            trigger.push(formando)
        })
        this.associarEvents()
    }

    async associarEvents() {
        await hosts.map(async (element) => {
            let bodyCriado = {
                jsonrpc: "2.0",
                method: "event.get",
                params: {
                    hostids: element.hostid,
                    value: 1,
                    time_from: this.state.dataInicial,
                    time_till: this.state.dataFinal,
                    sortfield: "clock",
                    output: ["name", "clock", "objectid"]
                },
                auth: this.state.userLogado,
                id: 1
            }

            let dado = await fetch(Url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bodyCriado)
            })
            let data = await dado.json()

            let formando = {
                host: element.host,
                hostId: element.hostid,
                event: data.result
            }
            final.push(formando)
        })
        await this.visualizarDados()
    }
    async visualizarDados() {
        await console.log(trigger)
        await console.log(final)
        await this.tratarDados(trigger)
    }

    async tratarDados() {
        await setTimeout(() => {
            trigger.map(elemento => {
                elemento.trigger.map(elemento2 => {
                    final.map(elemento3 => {
                        elemento3.event.map(elemento4 => {
                            if (elemento2.triggerid === elemento4.objectid) {
                                elemento.ocorrencias.push(elemento4)
                                // console.log(elemento)
                            }
                        })
                    })
                })
            })
        }, 1000)
        await setTimeout(function () {
            trigger.map(element => {
                element.trigger.map(element1 => {
                    element.ocorrencias.map(element2 => {
                        if (element2.objectid === element1.triggerid) {
                            i = parseInt(inicio) - 3600;
                            contador2 = 0;
                            horario = parseInt(element2.clock)

                            while (i <= f) {
                                if (horario >= i && horario <= (i + 86400)) {
                                    element1.vetor[contador2] = element1.vetor[contador2] + 1
                                }
                                contador2++
                                i = i + 86400;
                            }
                        }
                    })
                })
            })
            console.log(trigger)
            this.setState({ teste: trigger })
        }.bind(this), 1000)
    }

    render() {
        return (
            this.state.teste.map((element) => {
                console.log(element.host)              
                return (
                    <div>{
                        element.trigger.map((element2, index )=> {
                            console.log(element.trigger[index].vetor)
                            contador++
                            const data = {
                                labels: dadosGraficos,
                                datasets: [
                                    {
                                        backgroundColor: 'red',
                                        borderColor: 'black',
                                        borderWidth: 0,
                                        hoverBackgroundColor: 'yellow',
                                        hoverBorderColor: 'black',
                                        data: element2.vetor
                                    }
                                ],
                                legend: {
                                    display: "none"
                                }
                            };                
                            const options = {
                                legend: {
                                    display: false
                                },
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            fontColor: "black",
                                            min: 0,
                                            stepSize: 3
                                        }
                                    }],
            
                                    xAxes: [{
                                        barPercentage: 1.10,
                                        ticks: {
                                            fontColor: exibir,
                                            display: "none",
                                        }
                                    }]
                                },
                                title: {
                                    display: "center",
                                    text: element.trigger[index].description,
                                    fontColor: "black"
                                }
                            }
                            return (
                                <div>
                                    <div style={{ maxHeight: "5cm", maxWidth: "10cm" }}>
                                        <tr>
                                            <td class="colunaOK">{element.trigger[index].triggerid}das</td>
                                            <td class="colunaNome">{element2.triggerid}</td>
                                            <td class="colunaErros">{element.hostId}</td>
                                            <td class="colunaGrafico" ><div class="grafico" style={{ backgroundColor: "green" }}><Bar
                                                width={500}
                                                height={100}
                                                data={data}
                                                options={options}
                                            /></div></td>
                                        </tr>
                                    </div>
                                </div>
                            )
                        })
                    }
                        <p>Funcionei</p>
                    </div>
                )
            })
        )
    }
}

export default Grafico;

