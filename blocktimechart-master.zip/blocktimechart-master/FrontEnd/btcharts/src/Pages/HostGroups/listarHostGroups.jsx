
import React, { Component } from 'react';
import './listarHostGroups.css';
import './hostGroupModal.css'
import Logo from '../../Assets/img/Logo_Tecnologia_600x150.png'
import Url from '../../Services/apiService';
import Logoff from '../../Services/logoff'
import 'bootstrap/dist/css/bootstrap.min.css'
import Breadcrumb from 'react-bootstrap/Breadcrumb'
import CriarArrayX from '../../Services/CriarArrayX'



let vetor = []
let vetorNome=[]
let indice =-1
let displayModal = "none"
let displayTabela = ""
 

class grouphost extends Component {
    constructor() {
        super();
        this.state = {
            listGroupHost: [],
            errorMessage: "",
            search: '',
            groupid:'',
            userLogado: localStorage.getItem("usuario-blocktime"),
            modal: false,
            nome:"",
            id:"",
            dataInicial:"X",
            dataFinal:"Y"
        }
    }

    //Chama os métodos antes da página ser carregada
    componentDidMount() {
        this.listaGroupHost();
        document.title ="Lista de Clientes"
              
    }

    dataInicial(event){
        this.setState({dataInicial: event.target.value})
        
    }

    convertTimestamp(_dataInicial, _dataFinal){
        let _inicialStamp= (new Date(_dataInicial).getTime())
        _inicialStamp=(_inicialStamp/1000)+14401
        this.setState({dataInicial: _inicialStamp})
        let _finalStamp= (new Date(_dataFinal).getTime())
        _finalStamp=(_finalStamp/1000)+14401
        this.setState({dataFinal: _finalStamp})
        localStorage.setItem("dataInicial", _inicialStamp)
        localStorage.setItem("dataFinal", _finalStamp)
        CriarArrayX(_inicialStamp, _finalStamp)
        this.props.history.push('/Grafico')

    }

    dataFinal(event){
        this.setState({dataFinal: event.target.value})
    }

    janelaModal(_id, _nome){
        localStorage.setItem("GroupName", _nome);
        localStorage.setItem("Grouphostid", _id);
        this.setState({nome: _nome})
        this.setState({id: _id})
        this.setState({modal:!this.state.modal})
    }
   
    updateSearch(event) {
        this.setState({ search: event.target.value.substr(0, 20) });
    }


    logoff(){
        Logoff.efetuarLogoff()
        this.props.history.push('/Login');
    }

    setarGroupid(idHostGroup,vetorNome){

       
        localStorage.setItem("Grouphostid", idHostGroup);
        this.setarGroupName(vetorNome)
        this.props.history.push('/Hosts')
    }

    setarGroupName(groupName){
      localStorage.setItem("GroupName", groupName);
      
    }
  

    listaGroupHost() {

        
        let bodyCriado = {
            
                jsonrpc: "2.0",
                method: "hostgroup.get",
                params: {
                    output:["groupid", "name"]
                },
                auth: this.state.userLogado,
                id: 1
            
        }
      
   

       


             fetch(Url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bodyCriado)
            })
                .then( resposta => resposta.json())
                .then(data => {
                     this.setState({ listGroupHost: data.result })
                    
                    console.log(data.result)
                    console.log(this.state.listGroupHost);
                })
                .catch(erro => console.log(erro))
            
        }


    render() {
        //Criando o filtro de nossa lista 
        if(this.state.modal===true){
                displayModal = ""
                displayTabela = "none"  
        }
        else{
                displayModal = "none"
                displayTabela = ""  
        }

     
        return (<div>
            


            <div className="containerModal" style={{display: displayModal}}>
        <div className="fundo-modal">

             
        <h2 className="h1-modal">Empresa: {this.state.nome}</h2> 
        <h2 className="h1-modal">Defina o período para a geração do relatório gráfico</h2>  

        <div className="h1-modal-esquerda">
        <h2 className="h1-modal">Data Inicial</h2> 
        <input type="date" value={this.state.dataInicial} onChange={this.dataInicial.bind(this)}/>  
        
        <h2 className="h1-modal">Data Final</h2>     
        <input type="date" value={this.state.dataFinal} onChange={this.dataFinal.bind(this)}/> 
        
        </div>

        <div className="botao-modal">
        <button  className="margin1" onClick={ this.janelaModal.bind(this, vetor[indice], vetorNome[indice])  } >Cancelar</button>
        <button  className="margin1" onClick={this.convertTimestamp.bind(this, this.state.dataInicial, this.state.dataFinal)} >Visualizar Gráficos</button>
        </div>
    </div>








            

            </div>


            <div className="container"  style={{display: displayTabela}}>




                
                <div className="fundoHostGroup">

                <Breadcrumb style={{display: displayTabela}}>
  
  <Breadcrumb.Item active>HostGroups</Breadcrumb.Item>
</Breadcrumb>


                <button   onClick={ this.logoff.bind(this)} style={{margin:"5%", marginLeft:"80%"}}>Logoff</button>
                
                   
                    <div id="logo" >
                   
                        <img src={Logo} alt="Logo da empresa BlockTime" width="300 px" />
                    </div>


                    
                    








                    <div>  
                    <div id="tituloHostGroup">
                        <h1>Empresas   </h1>
                    </div>
                    <div className="divBusca">
                      
                    </div>
                    <div className="tabela" >
                        <table className="tableHostGroup">
                            <thead className="primeiralinhaHostGroup">
                                <tr>
                                    <th>ID</th>
                                    <th className="leftHostGroup">Nome do Host</th>
                                     <th>#</th>
                                     <th>#</th>
                                </tr>
                            </thead>
                            <tbody id="myTable">
                                


                          {  
                              this.state.listGroupHost.map(element =>{   
                                  vetor.push(element.groupid)
                                  vetorNome.push(element.name)
                                  indice++
                                
                               return(
                                   
                            <tr className="linhaHostGroup" key={element.groupid}>
                              <td className="centerNum" >{element.groupid}</td>
                              <td className="leftHostGroup">{element.name}</td>
                              <td className="centerNum"><button  onClick={ this.setarGroupid.bind(this, vetor[indice], vetorNome[indice]) } >Listar Hosts</button></td>
                              <td className="centerNum"><button  onClick={ this.janelaModal.bind(this, vetor[indice], vetorNome[indice])  } >Gerar Relatório</button></td>
                              


                              
                        
                                </tr>)
                                


                               
                         
                          })
                          }




                            </tbody>
                        </table>
                        
                        </div> 
                    </div>
                </div>
            </div>
            </div>
        )
    }
}

export default grouphost;
