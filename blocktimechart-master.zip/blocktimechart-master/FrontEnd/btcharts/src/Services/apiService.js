

const Url = "https://monitor.blocktime.com.br/zabbix/api_jsonrpc.php"

export default Url;