import React, { Component } from 'react';
import './grafico.css'
import Url from '../../Services/apiService'
import { Bar } from 'react-chartjs-2';




let hosts = []
let triggers = []
let events = []
let contador = 0
let triggersSeparados = []







class Grafico extends Component {




    constructor() {
        super();
        this.state = {
            userLogado: localStorage.getItem("usuario-blocktime"),
            dataInicial: localStorage.getItem("dataInicial"),
            dataFinal: localStorage.getItem("dataFinal"),
            grouphostid: localStorage.getItem("Grouphostid"),

        }
    }
    componentDidMount() {
        document.title = "Relatório de " + localStorage.getItem("GroupName")
        this.buscarInformacoesEvents()

    }

    async buscarInformacoesEvents() {
        let bodyCriado = {


            jsonrpc: "2.0",
            method: "event.get",
            params: {

                groupids: this.state.grouphostid,
                value: 1,
                time_from: this.state.dataInicial,
                time_till: this.state.dataFinal,
                sortfield: "clock",
                output: ["objectid", "name", "clock"]
            },
            auth: this.state.userLogado,
            id: 1

        }
        let dado = await fetch(Url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(bodyCriado)
        })
        let data = await dado.json()
        events = data.result
        this.ColetarHosts()
        
        
        
        console.log(triggers)
        
        


    }

    async ColetarHosts() {

        

        let bodyCriado = {


            jsonrpc: "2.0",
            method: "host.get",
            params: {
                output: ["hostid", "host"],
                groupids: this.state.groupid

            },
            auth: this.state.userLogado,
            id: 1


        }

        let dado = await fetch(Url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(bodyCriado)
        })
        let data = await dado.json()
        hosts = await data.result
        console.log(hosts)
        this.separarTriggers()
        
        
    }

    async separarTriggers(){
        
        hosts.map(async (element)=>{

            let bodyCriado = {


                jsonrpc: "2.0",
                method: "trigger.get",
                params: {
                    hostids: element.hostid,
                    output: "triggerid"
    
                },
                auth: this.state.userLogado,
                id: 1
            }

              let dado = await fetch(Url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bodyCriado)
            })
            let data = await dado.json()
            triggers = await {
                    id:element.host,
                    triggers: data.result
            }
            console.log(triggers)
            
    



        })
    }
   
   






    render() {



        return (

            hosts.map(element => {
                contador++
                const data = {
                    labels: localStorage.getItem("ArrayX"),
                    datasets: [
                        {

                            backgroundColor: 'red',
                            borderColor: 'grey',
                            borderWidth: 1,
                            hoverBackgroundColor: 'pink',
                            hoverBorderColor: 'black',
                            data: hosts[contador - 1]
                        }
                    ],
                    legend: {
                        display: "none"
                    }
                };

                return (
                    <div>
                        <div style={{ maxHeight: "3cm", maxWidth: "3", }}>

                            <tr>
                                <td class="colunaOK">OK</td>
                                <td class="colunaNome">Computador do Rick</td>
                                <td class="colunaErros">0</td>
                                <td class="colunaGrafico" style={{ backgroundColor: "rgba(0, 100, 0, 0.7)" }}><div class="grafico"><Bar
                                    width={200}
                                    height={100}
                                    data={data}
                                    options={{
                                        maintainAspectRatio: false

                                    }}
                                /></div></td>

                            </tr>




                        </div>
                    </div>

                )
            }))
    };


}

export default Grafico;