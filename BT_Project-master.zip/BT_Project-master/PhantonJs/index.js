const phantom = require ('phantom')

const takeScreenshot = async (url) =>{
    const instance = await phantom.create()
    const page =await instance.createPage()
    const status = await page.open(url)
    console.log(status)


    await page.render('teste.png')
    await instance.exit()

}

takeScreenshot('http://localhost:3000')