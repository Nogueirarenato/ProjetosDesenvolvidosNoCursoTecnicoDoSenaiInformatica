import React from 'react';
import {Bar} from 'react-chartjs-2';



const estilo ={
width: 500,
height: 500,
backgroundColor: "green",
margin: "5%"

}

const data = {
  labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'],
  datasets: [
    {
      //label: 'Banana é a melhor fruta do mundo',
      backgroundColor: 'red',
      borderColor: "black",
      borderWidth: 3,
      hoverBackgroundColor: 'red',
      hoverBorderColor: 'orange',
      data: [65, 59, 80, 81, 56, 55,65, 59, 80, 81, 56, 55,65, 59, 80, 81, 56, 55,65, 59, 80, 81, 56, 55,65, 59, 80, 81, 56, 55,]
    }
  ]
};

const banana = ()=>({
    displayName: 'BarExample',
  
    render() {
      return (
        <div style={estilo}>
          <h2>Bar Example (custom size)</h2>
          <Bar
            data={data}
            width={3}
            height={10}
            options={{
              maintainAspectRatio: false
            }}
          />
        </div>
      );
    }
  });

  export default banana