import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import ReactPDF, { Page, Document, Font, Text, View } from '../node_modules/@react-pdf/renderer';
import { PDFViewer } from '@react-pdf/renderer';









function App() {
// Create styles
const styles ={
  teste : {
    height: 1122.5196,
    width: 793.700,
    backgroundColor: 'yellow',
}
,

teste2 : {
    height: 1122.5196,
    width: 793.700,
    backgroundColor: 'red'
}
}


// Create Document Component
const MyDocument = () => (
  <Document>
    <Page size="A4" style={styles.page}>
      Droga
    </Page>
  </Document>
);

ReactPDF.render(<MyDocument />);
}



export default App;
