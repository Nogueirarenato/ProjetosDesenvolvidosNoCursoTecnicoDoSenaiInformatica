import React from 'react';
import ReactDOM from 'react-dom';
import { PDFViewer, PDFDownloadLink, BlobProvider  } from '@react-pdf/renderer';
import MyDocument from './App'
import Grafico from './grafico'
import BomDia from './componentes/bomdia'



const tamanho =
{
    
    
    width: 793,
    height:1122
}

const App = () => (
  <PDFViewer style ={tamanho}>
    <MyDocument />
  </PDFViewer>
);

ReactDOM.render(<Grafico/>, document.getElementById('root'));


