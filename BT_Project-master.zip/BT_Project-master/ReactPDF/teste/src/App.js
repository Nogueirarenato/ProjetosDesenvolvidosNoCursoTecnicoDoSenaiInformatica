import React from 'react';
import { Page, Text, View, Document, StyleSheet, Canvas, Image } from '@react-pdf/renderer';
import Grafico from './grafico'

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: 'row',
    backgroundColor: 'red'
  },
  section: {
    margin: 10,
    padding: 10,
    width: 793,
    height: 1122

  }
});

// Create Document Component
const MyDocument = () => (
  <Document>
     <Page size="A4" style={styles.page}>
      <View style={styles.section}>
        <Text>Raça Negra dididieeee
          <Grafico/>
        </Text>
      </View>
      <View style={styles.section}>
        <Text>Section #2</Text>
      </View>
    </Page>
  </Document>
);

export default MyDocument