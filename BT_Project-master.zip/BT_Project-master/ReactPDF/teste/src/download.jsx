import React from 'react'
import App from './index'

const imprimir = () => <button onClick="App()">Banana</button>

export default imprimir