import React from 'react';
import {Bar} from 'react-chartjs-2';


const eixox = [1] 
const eixoy = [1]




const estilo ={
width: 500,
height: 100,
backgroundColor: "grey",
margin: "1%"


}

const data = {
  labels: eixox,
  datasets: [
    {
      label: 'Banana é a melhor fruta do mundo',
      backgroundColor: 'red',
      borderColor: "black",
      borderWidth: 3,
      hoverBackgroundColor: 'red',
      hoverBorderColor: 'orange',
      data: eixoy
    }
  ]
};





const banana = ()=>({
    displayName: 'BarExample',


    
  
    render() {
      return (
        <div style={estilo}>
         
          <Bar
            data={data}
            width={30}
            height={50}
            options={{
              maintainAspectRatio: false
            }}
          />

          </div>

      );
    }
  });


 
  export default banana