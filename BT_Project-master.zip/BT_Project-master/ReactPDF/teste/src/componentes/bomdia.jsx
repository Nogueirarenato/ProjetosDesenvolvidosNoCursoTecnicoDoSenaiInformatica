import React from 'react'


export default props => <div>Bom dia {props.nome}</div>