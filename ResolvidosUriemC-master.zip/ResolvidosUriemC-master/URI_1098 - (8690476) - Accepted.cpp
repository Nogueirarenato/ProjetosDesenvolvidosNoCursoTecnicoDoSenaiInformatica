#include <stdio.h>

int main()
{
printf("I=0 J=1\n");
printf("I=0 J=2\n");
printf("I=0 J=3\n");
printf("I=0.2 J=1.2\n");
printf("I=0.2 J=2.2\n");
printf("I=0.2 J=3.2\n");
printf("I=0.4 J=1.4\n");
printf("I=0.4 J=2.4\n");
printf("I=0.4 J=3.4\n");
printf("I=0.6 J=1.6\n");
printf("I=0.6 J=2.6\n");
printf("I=0.6 J=3.6\n");
printf("I=0.8 J=1.8\n");
printf("I=0.8 J=2.8\n");
printf("I=0.8 J=3.8\n");
printf("I=1 J=2\n");
printf("I=1 J=3\n");
printf("I=1 J=4\n");
printf("I=1.2 J=2.2\n");
printf("I=1.2 J=3.2\n");
printf("I=1.2 J=4.2\n");
printf("I=1.4 J=2.4\n");
printf("I=1.4 J=3.4\n");
printf("I=1.4 J=4.4\n");
printf("I=1.6 J=2.6\n");
printf("I=1.6 J=3.6\n");
printf("I=1.6 J=4.6\n");
printf("I=1.8 J=2.8\n");
printf("I=1.8 J=3.8\n");
printf("I=1.8 J=4.8\n");
printf("I=2 J=3\n");
printf("I=2 J=4\n");
printf("I=2 J=5\n");


return(0);

}
