#include<stdio.h>
#include<math.h>
int main()
{   int distancia, tempo;
    scanf("%d",&distancia);
    tempo=2*distancia;
    printf("%d minutos\n",tempo);

return(0);
}
