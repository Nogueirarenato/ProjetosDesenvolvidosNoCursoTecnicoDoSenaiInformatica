#include <stdio.h>
#include<math.h>
int main()
{int cont, estancias;

cont=0;
scanf("%d", &estancias);
while(cont<estancias){

    printf("Y\n");

    cont++;
}


return(0);
}


