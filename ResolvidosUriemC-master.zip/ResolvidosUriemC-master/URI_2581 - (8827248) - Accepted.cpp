#include <stdio.h>
#include<math.h>
int main()
{int cont, estancias;

cont=0;
scanf("%d", &estancias);
while(cont<estancias){

    printf("I am Toorg!\n");

    cont++;
}


return(0);
}


