#include <stdio.h>

int main()

{   
    printf("Ciencia da Computacao\n");




    return(0);
}
