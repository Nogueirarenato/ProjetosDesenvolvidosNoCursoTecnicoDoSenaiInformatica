#include<stdio.h>
int main () {
int a,b,x;
scanf("%d", & a);
scanf("%d", & b);
x=a+b;
printf("X = %d\n", x);
return 0;
}