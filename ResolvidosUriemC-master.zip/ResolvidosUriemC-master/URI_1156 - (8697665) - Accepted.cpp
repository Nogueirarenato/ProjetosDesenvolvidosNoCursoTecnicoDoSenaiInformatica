#include <stdio.h>

int main ()
{

printf("6.00\n");

return(0);
}
