#include <stdio.h>

int main ()
{ printf("5.19\n");
return(0);
}
