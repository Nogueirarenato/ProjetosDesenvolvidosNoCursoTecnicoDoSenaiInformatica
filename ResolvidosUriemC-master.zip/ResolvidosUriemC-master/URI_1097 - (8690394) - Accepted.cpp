#include <stdio.h>

int main()
{   printf("I=1 J=7\n");
    printf("I=1 J=6\n");
    printf("I=1 J=5\n");
    printf("I=3 J=9\n");
    printf("I=3 J=8\n");
    printf("I=3 J=7\n");
    printf("I=5 J=11\n");
    printf("I=5 J=10\n");
    printf("I=5 J=9\n");
    printf("I=7 J=13\n");
    printf("I=7 J=12\n");
    printf("I=7 J=11\n");
    printf("I=9 J=15\n");
    printf("I=9 J=14\n");
    printf("I=9 J=13\n");
return(0);

}
