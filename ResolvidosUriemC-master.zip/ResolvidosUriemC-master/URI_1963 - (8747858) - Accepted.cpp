#include <stdio.h>
#include <math.h>

int main ()

{ double a,b,c;

scanf("%lf %lf", &a, &b);



c=(b/a-1)*100;

printf("%.2lf%%\n",c);



return(0);
}
