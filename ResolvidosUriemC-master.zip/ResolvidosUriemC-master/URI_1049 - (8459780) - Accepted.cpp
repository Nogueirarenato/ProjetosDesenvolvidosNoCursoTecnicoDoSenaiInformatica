#include <stdio.h>
#include <stdlib.h>


int main()
{char vert[30],man [30], oni[30];
scanf("%s %s %s", vert, man, oni);

if(vert[0]=='v'){if(man[0]=='a'){if(oni[0]=='c')printf ("aguia\n");

                                 if(oni[0]=='o')printf ("pomba\n");

                                 }


                 if(man[0]=='m'){if(oni[0]=='h')printf ("vaca\n");

                                 if(oni[0]=='o')printf ("homem\n");

                                 }

}





if(vert[0]=='i'){if(man[0]=='i'){if(oni[2]=='m')printf ("pulga\n");

                                 if(oni[2]=='r')printf ("lagarta\n");

                                 }


                 if(man[0]=='a'){if(oni[0]=='h')printf ("sanguessuga\n");

                                 if(oni[0]=='o')printf ("minhoca\n");

                                 }







}



 return(0);
  }
