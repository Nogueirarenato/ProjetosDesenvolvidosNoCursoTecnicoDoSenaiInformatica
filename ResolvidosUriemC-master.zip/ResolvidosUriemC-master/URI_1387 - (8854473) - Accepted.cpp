#include <stdio.h>

int main()
{ int a, b;

a=1;
b=1;

while(a!=0||b!=0){

    scanf("%d %d", &a, &b);

    if(a!=0||b!=0)
    {
        printf("%d\n", a+b);

    }
}
return(0);
}
