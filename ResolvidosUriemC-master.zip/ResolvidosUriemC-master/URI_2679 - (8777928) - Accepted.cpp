#include <stdio.h>

int main()
{int maior;
scanf("%d", &maior);

if(maior%2==1)printf("%d\n", maior+1);
else printf("%d\n", maior+2);



return(0);

}
