#include <iostream>
 
using namespace std;
 
int main() {
 int a, b, PROD;

scanf("%d%d", &a, &b);
PROD= a*b;
printf ("PROD = %d\n", PROD);

  return 0;
}