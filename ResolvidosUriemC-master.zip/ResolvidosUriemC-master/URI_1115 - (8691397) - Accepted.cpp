#include <stdio.h>

int main ()
{int a,b;
a=1;
b=1;
while(a!=0 && b!=0){
    if(a!=0 && b!=0){scanf("%d %d", &a, &b);

    if(a!=0 && b!=0){if(a>0 && b>0)printf("primeiro\n");
    if(a<0 && b>0)printf("segundo\n");
    if(a<0 && b<0)printf("terceiro\n");
    if(a>0 && b<0)printf("quarto\n");
    }}





}


return(0);
}
