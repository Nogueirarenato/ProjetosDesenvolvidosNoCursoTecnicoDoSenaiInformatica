#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
int a,b,c,d, diferenca;
scanf("%d%d%d%d", &a, &b,&c,&d);
diferenca=(a*b-c*d);
printf("DIFERENCA = %d\n", diferenca);


    return 0;
}
