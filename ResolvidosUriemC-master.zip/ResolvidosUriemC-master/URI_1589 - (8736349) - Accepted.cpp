#include <stdio.h>

int main()
{ unsigned long long int casos, contador, a, b;
contador=0;
scanf("%llu7",&casos);

while(contador<casos){

    scanf("%llu %llu", &a, &b);

    printf("%llu\n",a+b);




    contador++;
}






  return(0);
}
