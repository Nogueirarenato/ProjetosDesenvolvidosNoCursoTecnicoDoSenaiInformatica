#include <stdio.h>

int main()

{   int c1;
scanf("%d", &c1);

if(c1==34)printf("LIFE IS NOT A PROBLEM TO BE SOLVED\n");
if(c1==33)printf("LIFE IS NOT A PROBLEM TO BE SOLVE\n");
if(c1==32)printf("LIFE IS NOT A PROBLEM TO BE SOLV\n");
if(c1==31)printf("LIFE IS NOT A PROBLEM TO BE SOL\n");
if(c1==30)printf("LIFE IS NOT A PROBLEM TO BE SO\n");
if(c1==29)printf("LIFE IS NOT A PROBLEM TO BE S\n");
if(c1==28)printf("LIFE IS NOT A PROBLEM TO BE \n");
if(c1==27)printf("LIFE IS NOT A PROBLEM TO BE\n");
if(c1==26)printf("LIFE IS NOT A PROBLEM TO B\n");
if(c1==25)printf("LIFE IS NOT A PROBLEM TO \n");
if(c1==24)printf("LIFE IS NOT A PROBLEM TO\n");
if(c1==23)printf("LIFE IS NOT A PROBLEM T\n");
if(c1==22)printf("LIFE IS NOT A PROBLEM \n");
if(c1==21)printf("LIFE IS NOT A PROBLEM\n");
if(c1==20)printf("LIFE IS NOT A PROBLE\n");
if(c1==19)printf("LIFE IS NOT A PROBL\n");
if(c1==18)printf("LIFE IS NOT A PROB\n");
if(c1==17)printf("LIFE IS NOT A PRO\n");
if(c1==16)printf("LIFE IS NOT A PR\n");
if(c1==15)printf("LIFE IS NOT A P\n");
if(c1==14)printf("LIFE IS NOT A \n");
if(c1==13)printf("LIFE IS NOT A\n");
if(c1==12)printf("LIFE IS NOT \n");
if(c1==11)printf("LIFE IS NOT\n");
if(c1==10)printf("LIFE IS NO\n");
if(c1==9)printf("LIFE IS N\n");
if(c1==8)printf("LIFE IS \n");
if(c1==7)printf("LIFE IS\n");
if(c1==6)printf("LIFE I\n");
if(c1==5)printf("LIFE \n");
if(c1==4)printf("LIFE\n");
if(c1==3)printf("LIF\n");
if(c1==2)printf("LI\n");
if(c1==1)printf("L\n");




    return(0);
}
