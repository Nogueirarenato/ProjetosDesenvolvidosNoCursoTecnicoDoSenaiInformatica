#include <stdio.h>

int main ()
{	
printf("I=1 J=7\n");
printf("I=1 J=6\n");
printf("I=1 J=5\n");
printf("I=3 J=7\n");
printf("I=3 J=6\n");
printf("I=3 J=5\n");
printf("I=5 J=7\n");
printf("I=5 J=6\n");
printf("I=5 J=5\n");
printf("I=7 J=7\n");
printf("I=7 J=6\n");
printf("I=7 J=5\n");
printf("I=9 J=7\n");
printf("I=9 J=6\n");
printf("I=9 J=5\n");

return(0);
}

