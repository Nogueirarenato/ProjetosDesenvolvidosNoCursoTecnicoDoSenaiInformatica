#include <stdio.h>
#include <string.h>


int main ()
{int n, c;
c=0;
scanf("%d", &n);
printf("Feliz nat");

while(c<n){
    printf("a");
    c++;
}

printf("l!\n");

return(0);
}