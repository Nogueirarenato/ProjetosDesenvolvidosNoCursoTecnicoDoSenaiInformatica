#include <stdio.h>

int main()
{ unsigned long long int casos, contador, a, b;
contador=0;
while(scanf("%llu7",&a)!=EOF){



   if(a==0)printf("vai ter copa!\n");
   else printf("vai ter duas!\n");




}






  return(0);
}
