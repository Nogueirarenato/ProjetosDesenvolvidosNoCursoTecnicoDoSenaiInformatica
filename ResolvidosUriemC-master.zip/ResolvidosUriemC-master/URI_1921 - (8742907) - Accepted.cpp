#include <stdio.h>

int main()

{   unsigned long long int c1, c2, n1;
    scanf("%llu", &c2);

    n1=c2*(c2-3)/2;

    printf("%llu\n", n1);




    return(0);
}
