#include <stdio.h>
#include <math.h>
#include <string.h>

int main (){
int a;
a=2;

while (a<=100)
{
    printf("%d\n",a);
    a++;
    a++;
}

return(0);
}
