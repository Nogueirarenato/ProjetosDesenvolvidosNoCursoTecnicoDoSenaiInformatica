#include <stdio.h>
int main ()
{ int x, soma,a;


    scanf("%d", &x);
    soma=1;
    while(soma<=x){
    printf("%d\n",soma);
    soma++;
    soma++;}


return(0);
}
