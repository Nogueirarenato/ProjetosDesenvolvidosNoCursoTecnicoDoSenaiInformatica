#include <stdio.h>

int main ()
{int entrada;

while(scanf("%d", &entrada)!=EOF){


    printf("%d\n", entrada-1);

}


    return(0);
}
