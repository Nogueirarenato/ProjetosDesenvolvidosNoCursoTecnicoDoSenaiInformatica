#include <stdio.h>
#include <string.h>

int main ()
{  double cachorro, participantes, media;

scanf("%lf %lf", &cachorro, &participantes);

media=cachorro/participantes;

printf("%.2lf\n", media);







    return(0);
}
