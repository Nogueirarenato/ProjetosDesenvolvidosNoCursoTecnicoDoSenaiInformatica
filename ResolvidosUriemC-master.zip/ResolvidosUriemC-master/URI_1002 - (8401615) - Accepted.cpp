#include <iostream>
 
using namespace std;
 
int main() {
 double r,a;

    scanf ("%lf", &r);
    a=r*r*3.14159;
    printf("A=%.4lf\n", a);

  return 0;
 
    return 0;
}