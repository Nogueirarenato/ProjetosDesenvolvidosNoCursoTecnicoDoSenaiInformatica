#include <stdio.h>

int main()

{   int a,b,c,d,t;

    scanf("%d %d %d %d", &a, &b, &c, &d);
    t=a+b+c+d-3;
    printf("%d\n", t);








    return(0);
}
