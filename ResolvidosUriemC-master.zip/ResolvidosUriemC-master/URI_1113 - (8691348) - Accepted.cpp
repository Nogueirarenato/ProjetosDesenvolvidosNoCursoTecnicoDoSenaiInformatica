#include <stdio.h>

int main ()
{int a,b,c,d,e,cont,cont1,soma;

a=2;
b=3;
while(a!=b)

        if(a!=b){scanf("%d %d", &a, &b);


if(a!=b){
    if(a<b){printf("Crescente\n");}
    else{printf("Decrescente\n");}

}}

return(0);
}
