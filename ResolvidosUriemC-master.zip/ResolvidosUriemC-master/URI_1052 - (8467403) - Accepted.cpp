#include <stdio.h>

int main ()
{   int m;
    scanf("%d", &m);
    if(m==1)printf("January\n");
    if(m==2)printf("February\n");
    if(m==3)printf("March\n");
    if(m==4)printf("April\n");
    if(m==5)printf("May\n");
    if(m==6)printf("June\n");
    if(m==7)printf("July\n");
    if(m==8)printf("August\n");
    if(m==9)printf("September\n");
    if(m==10)printf("October\n");
    if(m==11)printf("November\n");
    if(m==12)printf("December\n");

    return(0);
}
