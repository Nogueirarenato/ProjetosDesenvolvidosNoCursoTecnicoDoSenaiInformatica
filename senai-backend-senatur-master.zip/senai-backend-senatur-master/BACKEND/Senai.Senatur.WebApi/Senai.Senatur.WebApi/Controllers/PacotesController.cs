﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.Senatur.WebApi.Domains;
using Senai.Senatur.WebApi.Interfaces;
using Senai.Senatur.WebApi.Repositories;

namespace Senai.Senatur.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PacotesController : ControllerBase
    {
        private IPacoteRepository PacoteRepository { get; set; }

        public PacotesController()
        {
            PacoteRepository = new PacoteRepository();
        }

        [HttpPost]
        public IActionResult Post(PacoteDomain pacoteRecebido)
        {

            try
            {
                PacoteRepository.Cadastrar(pacoteRecebido);
                return Ok();
            }


            catch (Exception ex)
            {
                
                return BadRequest();
            }


        }
            [HttpGet]
            public IEnumerable <PacoteDomain> Get()
        {


            return PacoteRepository.Listar();
        }


        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            PacoteDomain pacote = PacoteRepository.BuscarPorId(id);

            if (pacote == null)
            {
                return NotFound();
            }

            return Ok(pacote);
        }


        [HttpPut("{id}")]
        public IActionResult Put(int id, PacoteDomain pacoteEditar)
        {
            try
            {
                PacoteRepository.Atualizar(id, pacoteEditar);
                return Ok();
            }

            catch
            {
                return BadRequest();
            }
        }
















    }
    }
