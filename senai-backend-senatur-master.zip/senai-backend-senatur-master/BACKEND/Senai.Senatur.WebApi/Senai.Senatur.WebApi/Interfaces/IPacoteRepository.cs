﻿using Senai.Senatur.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Senatur.WebApi.Interfaces
{
    interface IPacoteRepository
    {
        void Cadastrar(PacoteDomain pacote);

        List<PacoteDomain> Listar();

        PacoteDomain BuscarPorId(int id);

        void Atualizar(int id, PacoteDomain pacoteEditar);

    }
}
