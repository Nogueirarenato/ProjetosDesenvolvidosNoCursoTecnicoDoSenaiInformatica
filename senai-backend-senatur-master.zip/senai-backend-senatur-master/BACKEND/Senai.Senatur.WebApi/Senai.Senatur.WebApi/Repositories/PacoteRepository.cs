﻿using Senai.Senatur.WebApi.Domains;
using Senai.Senatur.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Senai.Senatur.WebApi.Repositories
{
    public class PacoteRepository : IPacoteRepository

    {
        private string StringConexao = "Server=DESKTOP-DQ5PRKU; Database=Senatur_Manha;integrated security=true";


        public void Cadastrar(PacoteDomain pacote)
        { using (SqlConnection con = new SqlConnection(StringConexao))
            {
                string Query = "INSERT INTO PACOTES ( NomePacote, Descricao, DataIda, DataVolta, Valor, Ativo, NomeCidade)" +
                              "VALUES (@NomePacote, @Descricao, @DataIda, @DataVolta, @Valor, @Ativo, @NomeCidade);";
               

                using (SqlCommand cmd = new SqlCommand(Query, con))
                {

                    cmd.Parameters.AddWithValue("@NomePacote", pacote.NomePacote);
                    cmd.Parameters.AddWithValue("@Descricao", pacote.Descricao);
                    cmd.Parameters.AddWithValue("@DataIda", pacote.DataIda);
                    cmd.Parameters.AddWithValue("@DataVolta", pacote.DataVolta);
                    cmd.Parameters.AddWithValue("@Valor", pacote.Valor);
                    cmd.Parameters.AddWithValue("@Ativo", pacote.Ativo);
                    cmd.Parameters.AddWithValue("@NomeCidade", pacote.NomeCidade);

                    con.Open();

                    cmd.ExecuteNonQuery();


                }

            }
        }

        public List<PacoteDomain> Listar()
        {

            List<PacoteDomain> lista = new List<PacoteDomain>();

            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                string Query = "SELECT PacoteId, NomePacote, Descricao, DataIda, DataVolta, Valor, Ativo , NomeCidade from Pacotes";

                con.Open();
                SqlDataReader rdr;

                using (SqlCommand cmd = new SqlCommand(Query, con))
                {
                    //Executa a query
                    rdr = cmd.ExecuteReader();


                    //Percorre os dados 
                    while (rdr.Read())
                    {
                        PacoteDomain pacoteAdicionar = new PacoteDomain()

                        {
                            PacoteId = Convert.ToInt32(rdr["PacoteId"]),

                            NomePacote = rdr["NomePacote"].ToString(),

                            Descricao = rdr["Descricao"].ToString(),

                            DataIda = Convert.ToDateTime(rdr["DataIda"]),

                            DataVolta = Convert.ToDateTime(rdr["DataVolta"]),

                            Valor = Convert.ToDecimal(rdr["Valor"]),

                            Ativo = Convert.ToInt32(rdr["Ativo"]),

                            NomeCidade = rdr["NomeCidade"].ToString()
                        };



                        lista.Add(pacoteAdicionar);
                    }
                }




            }




            return (lista);
        }

        public PacoteDomain BuscarPorId(int id)
        {
            
            string Query = "SELECT PacoteId, NomePacote, Descricao, DataIda, DataVolta, Valor, Ativo , NomeCidade from Pacotes where PacoteId= @id";
            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                SqlDataReader rdr;
                con.Open();
                using (SqlCommand cmd = new SqlCommand(Query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();

                    rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {

                        while (rdr.Read())
                        {

                            PacoteDomain pacoteId = new PacoteDomain
                            {

                                PacoteId = Convert.ToInt32(rdr["PacoteId"]),

                                NomePacote = rdr["NomePacote"].ToString(),

                                Descricao = rdr["Descricao"].ToString(),

                                DataIda = Convert.ToDateTime(rdr["DataIda"]),

                                DataVolta = Convert.ToDateTime(rdr["DataVolta"]),

                                Valor = Convert.ToDecimal(rdr["Valor"]),

                                Ativo = Convert.ToInt32(rdr["Ativo"]),

                                NomeCidade = rdr["NomeCidade"].ToString()
                            };
                            return pacoteId;
                        }
                    }




                }
            }

            return null;
        }

        public void Atualizar(int id, PacoteDomain pacoteEditar)
        {
            string QueryUpdate = "UPDATE Pacotes set NomePacote = @NomePacote, Descricao = @Descricao, DataIda = @DataIda, DataVolta = @DataVolta, Valor = @Valor , Ativo = @Ativo , NomeCidade = @NomeCidade where PacoteId = @id";

            using (SqlConnection con = new SqlConnection(StringConexao))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(QueryUpdate, con);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@NomePacote", pacoteEditar.NomePacote);
                cmd.Parameters.AddWithValue("@Descricao", pacoteEditar.Descricao);
                cmd.Parameters.AddWithValue("@DataIda", pacoteEditar.DataIda);
                cmd.Parameters.AddWithValue("@DataVolta", pacoteEditar.DataVolta);
                cmd.Parameters.AddWithValue("@Valor", pacoteEditar.Valor);
                cmd.Parameters.AddWithValue("@Ativo", pacoteEditar.Ativo);
                cmd.Parameters.AddWithValue("NomeCidade", pacoteEditar.NomeCidade);

                cmd.ExecuteNonQuery();





            }
        }
    }

}