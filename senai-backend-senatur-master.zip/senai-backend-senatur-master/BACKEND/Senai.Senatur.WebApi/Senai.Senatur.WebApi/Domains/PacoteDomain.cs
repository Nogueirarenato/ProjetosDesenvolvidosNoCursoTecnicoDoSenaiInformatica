﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Senatur.WebApi.Domains
{
    public class PacoteDomain
    { 
        public int PacoteId { get; set; }

        public string NomePacote { get; set; }

        public string Descricao { get; set; }

        public DateTime DataIda { get; set; }

        public DateTime DataVolta { get; set; }
        
        public decimal Valor { get; set; }

        public int Ativo { get; set; }

        public string NomeCidade { get; set; }



    }
}
