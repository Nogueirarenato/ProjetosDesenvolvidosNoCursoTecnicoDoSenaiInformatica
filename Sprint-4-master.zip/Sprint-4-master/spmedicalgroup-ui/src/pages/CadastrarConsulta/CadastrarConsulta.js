import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"


class CadastrarConsulta extends Component {
    constructor() {
        super();
        this.state = {
            idPaciente: "",
            idMedico: "",
            dataConsulta: "",
            descricaoDaConsulta: "",
            idStatus: "",
            tituloPagina: "Cadastrar Consultas"
        }

        this.atualizaidPaciente = this.atualizaidPaciente.bind(this);
        this.atualizaidMedico = this.atualizaidMedico.bind(this);
        this.atualizadataConsulta = this.atualizadataConsulta.bind(this);
        this.atualizadescricaoDaConsulta = this.atualizadescricaoDaConsulta.bind(this);
        this.atualizaidStatus = this.atualizaidStatus.bind(this);
        }



    atualizaidPaciente(event) {
        this.setState({ idPaciente: event.target.value });
    }

    atualizaidMedico(event) {
        this.setState({ idMedico: event.target.value });
    }

    atualizadataConsulta(event) {
        this.setState({ dataConsulta: event.target.value });
    }

    atualizadescricaoDaConsulta(event) {
        this.setState({ descricaoDaConsulta: event.target.value });
    }

    atualizaidStatus(event) {
        this.setState({ idStatus: event.target.value });
    }



    cadastraConsulta(event) {
        event.preventDefault();



    fetch('http://localhost:5000/api/Consulta',
    {
      method: 'POST',
      body : JSON.stringify({  
          idPaciente : this.state.idPaciente
        , idMedico: this.state.idMedico
        , dataConsulta: this.state.dataConsulta
        , descricaoDaConsulta: this.state.descricaoDaConsulta
        , idStatus: this.state.idStatus}),
      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
      }
    })
    .then(resposta => resposta,
      this.setState({erro: "Consulta Cadastrada com sucesso!!!"}))
    .catch(erro => console.log(erro))
}
componentDidMount(){
    document.title = "Cadastrar Consulta"
}

    render() {
        return (
            <div>
<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color: 'red', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form className="container margem10" onSubmit={this.cadastraConsulta.bind(this)}>


<Form.Group as={Row} controlId="formHorizontalPassword"  value={this.state.idPaciente} onChange={this.atualizaidPaciente}>
    <Form.Label column sm={2}>
      Id do Paciente
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o id do Paciente" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword"  value={this.state.idMedico} onChange={this.atualizaidMedico}>
    <Form.Label column sm={2}>
      Id do Médico
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o id do médico" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.dataConsulta} onChange={this.atualizadataConsulta}>
    <Form.Label column sm={2}>
      Data da Consulta
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="datetime-local" placeholder="Digite a data da consulta" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.descricaoDaConsulta} onChange={this.atualizadescricaoDaConsulta}>
    <Form.Label column sm={2}>
      Descrição da Consulta
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite a descrição da consulta"/>
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.idStatus} onChange={this.atualizaidStatus}>
    <Form.Label column sm={2}>
      Status da Consulta
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o Status da consulta" />
    </Col>
  </Form.Group>


  
  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Enviar</Button>
    </Col>
  </Form.Group>
</Form>;



            </div>
        );
    }
}

export default CadastrarConsulta;

