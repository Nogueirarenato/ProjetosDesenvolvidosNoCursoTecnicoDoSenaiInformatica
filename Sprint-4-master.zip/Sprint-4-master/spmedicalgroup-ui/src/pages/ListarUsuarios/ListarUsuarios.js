import React, { Component } from "react";
import Table from "../../../node_modules/react-bootstrap/Table"
import "../../assets/css/style.css"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import {Link} from "react-router-dom";
import Titulo from "../../components/Titulo/Titulo"

class ListarUsuarios extends Component {
    constructor(){
        super();
        this.state = {
          lista : [],
          nome: "",
          tituloPagina : "Listar Usuarios"
        }
  
        this.atualizaEstadoNome = this.atualizaEstadoNome.bind(this);
        this.cadastraTipoEvento = this.cadastraTipoEvento.bind(this);
    }
  
    listarUsuarios(){
        fetch('http://localhost:5000/api/Paciente',{
          method : 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization : 'Bearer ' + localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
          }
        })
          .then(resposta => resposta.json())
          .then(data => this.setState({lista : data}))
          .catch((erro) => console.log(erro))
    }
  
    componentDidMount(){
      document.title = "Lista de Usuários"
        this.listarUsuarios();
    }
  
    atualizaEstadoNome(event){
      this.setState({ nome : event.target.value });
    }
  
    cadastraTipoEvento(event){
      event.preventDefault();
      
      fetch('http://localhost:5000/api/Paciente',
          {
            method: 'POST',
            body : JSON.stringify({ nome : this.state.nome }),
            headers: {
              "Content-Type" : "application/json",
              Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
            }
          })
          .then(resposta => resposta)
          .then(this.listarUsuarios())
          .catch(erro => console.log(erro))
    }
  
    render() {
      return (
        
        <div>       
    

<Navbar bg="primary" expand="lg">

  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>



          <Table striped bordered hover className="container">
          <thead>
                    <tr>
                      <th>#</th>
                      <th>Usuário</th>
                      <th>Email</th>
                      <th>Senha</th>
                      <th>Telefone</th>
                      <th>Data de Nascimento</th>
                      <th>CPF</th>
                      <th>RG</th>
                      <th>Tipo de Usuario</th>
                      <th>Endereço Residencial</th>
                    </tr>
                  </thead>
  <tbody>
  {
                          this.state.lista.map(function(usuario){
                              return (
                                  <tr key={usuario.id}>
                                      <td>{usuario.id}</td>
                                      <td>{usuario.nome}</td>
                                      <td>{usuario.email}</td>
                                      <td>{usuario.senha}</td>
                                      <td>{usuario.telefone}</td>
                                      <td>{usuario.dataNascimento}</td>
                                      <td>{usuario.cpf}</td>
                                      <td>{usuario.rg}</td>
                                      <td>{usuario.idUsuarioNavigation.tipoDeUsuario}</td>
                                      <td>{usuario.enderecoResidencial}</td>
                                     
                                      

                                  </tr>
                              );
                          })
                      }
                  </tbody>
</Table>




        </div>
      );
    }
  }
  
  export default ListarUsuarios;
  
   