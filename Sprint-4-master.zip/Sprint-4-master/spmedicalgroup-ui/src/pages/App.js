import React, { Component } from 'react';
import './App.css';
import "../assets/css/style.css"
import "../assets/css/style/bootstrap.css"
import {Link} from "react-router-dom";
import logo2 from "../assets/images/logo.png"
import slide1 from "../assets/images/slide01.jpg"
import slide2 from "../assets/images/slide02.jpg"
import slide3 from "../assets/images/slide03.jpg"
import slide4 from "../assets/images/slide04.jpg"
import Carousel from '../../node_modules/react-bootstrap/Carousel'
import Navbar from "../../node_modules/react-bootstrap/Navbar"
import Nav from "../../node_modules/react-bootstrap/Nav"
import NavDropdown from "../../node_modules/react-bootstrap/NavDropdown"
import Form from "../../node_modules/react-bootstrap/Form"
import Button from "../../node_modules/react-bootstrap/Button"
import FormControl from "../../node_modules/react-bootstrap/FormControl"
import Footer from "../components/Footer/footer"



class App extends Component {
  render() {
    return (
       
      <div>
     
     
 





<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light"href="/Login/">Login</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>



<Carousel>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={slide1}
      alt="First slide"
    />
    <Carousel.Caption>
      <div class="slide001">
      <h2>Cuidando de você,<br/>e de quem você ama!</h2>
      </div>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={slide2}
      alt="Third slide"
    />

    <Carousel.Caption>
      <div className= "slide002">
      <h3>Excelentes instalações!</h3>
      </div>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={slide3}
      alt="Third slide"
    />

    <Carousel.Caption>
    <div className="slide003">
      <h2>Equipe médica altamente qualificada!</h2>
      
      </div>
    </Carousel.Caption>
  </Carousel.Item>

  <Carousel.Item>
    <img
      className="d-block w-100"
      src={slide4}
      alt="Third slide"
    />

    <Carousel.Caption>
      <div className="slide004">
      <h2>Atenção total ao paciente!</h2>
      </div>
    </Carousel.Caption>
  </Carousel.Item>


</Carousel>

<Footer className="a"/>

 </div>


    );
  }
}

export default App;
