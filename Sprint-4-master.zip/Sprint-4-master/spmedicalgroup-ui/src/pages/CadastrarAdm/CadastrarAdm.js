import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"


class CadastrarAdm extends Component {
    constructor() {
        super();
        this.state = {
            nome: "",
            dataNascimento: "",
            enderecoResidencial: "",
            cpf: "",
            email: "",
            senha: "",
            telefone: "",
            rg: "",
            idUsuario: "1",
            tituloPagina: "Cadastrar Administrador"
        }

        this.autualizaNome = this.autualizaNome.bind(this);
        this.atualizadataNascimento = this.atualizadataNascimento.bind(this);
        this.atualizaenderecoResidencial = this.atualizaenderecoResidencial.bind(this);
        this.atualizacpf = this.atualizacpf.bind(this);
        this.atualizaemail = this.atualizaemail.bind(this);
        this.atualizasenha = this.atualizasenha.bind(this);
        this.atualizatelefone = this.atualizatelefone.bind(this);
        this.atualizarg = this.atualizarg.bind(this);
      
    }



    autualizaNome(event) {
        this.setState({ nome: event.target.value });
    }

    atualizadataNascimento(event) {
        this.setState({ dataNascimento: event.target.value });
    }

    atualizaenderecoResidencial(event) {
        this.setState({ enderecoResidencial: event.target.value });
    }

    atualizacpf(event) {
        this.setState({ cpf: event.target.value });
    }

    atualizaemail(event) {
        this.setState({ email: event.target.value });
    }

    atualizasenha(event) {
        this.setState({ senha: event.target.value });
    }

    atualizatelefone(event) {
        this.setState({ telefone: event.target.value });
    }


    atualizarg(event) {
        this.setState({ rg: event.target.value });
    }


  







    cadastraUsuario(event) {
        event.preventDefault();



    fetch('http://localhost:5000/api/Paciente',
    {
      method: 'POST',
      body : JSON.stringify({  nome : this.state.nome,
        dataNascimento: this.state.dataNascimento
        , enderecoResidencial: this.state.enderecoResidencial
        , cpf: this.state.cpf
        , email: this.state.email
        , senha: this.state.senha
        , telefone: this.state.telefone
        , rg: this.state.rg
        , idUsuario: "1"}),
      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
        
      }
    })
    .then(resposta => resposta,
      this.setState({erro: "Administrador Cadastrado com sucesso!!!"}))
    .catch(erro => console.log(erro))
}

componentDidMount(){
  document.title = "Cadastrar Administrador"
}


    render() {
        return (
            <div>
<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoAdm/ ">Retornar ao Painel do Administrador</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color: 'red', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form className="container margem10" onSubmit={this.cadastraUsuario.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}>
      Nome do Administrador
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Nome" type="text" value={this.state.nome} onChange={this.autualizaNome} />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword"  value={this.state.dataNascimento} onChange={this.atualizadataNascimento}>
    <Form.Label column sm={2}>
      Data de Nascimento
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="date" placeholder="Data de nascimento" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.enderecoResidencial} onChange={this.atualizaenderecoResidencial}>
    <Form.Label column sm={2}>
      Endereço Residencial
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Enderço Residencial" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.cpf} onChange={this.atualizacpf}>
    <Form.Label column sm={2}>
      CPF
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o CPF do administrador"/>
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.email} onChange={this.atualizaemail}>
    <Form.Label column sm={2}>
      Email
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o email do administrador" />
    </Col>
  </Form.Group>


  <Form.Group as={Row} controlId="formHorizontalEmail"value={this.state.senha} onChange={this.atualizasenha}>
    <Form.Label column sm={2}>
      Senha
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Crie uma senha de acesso para o administrador" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail"value={this.state.telefone} onChange={this.atualizatelefone}>
    <Form.Label column sm={2}>
      Telefone
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o telefone de contato do administrador" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.rg} onChange={this.atualizarg}>
    <Form.Label column sm={2}>
      RG
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o numero do RG do administrador" />
    </Col>
  </Form.Group>


  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Enviar</Button>
    </Col>
  </Form.Group>
</Form>;



            </div>
        );
    }
}

export default CadastrarAdm;

