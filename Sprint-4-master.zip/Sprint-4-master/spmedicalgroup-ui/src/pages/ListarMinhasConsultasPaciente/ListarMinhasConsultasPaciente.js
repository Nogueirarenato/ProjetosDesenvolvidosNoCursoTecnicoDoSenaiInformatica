import React, { Component } from "react";
import Table from "../../../node_modules/react-bootstrap/Table"
import "../../assets/css/style.css"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import logo2 from "../../assets/images/logo.png"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import {Link} from "react-router-dom";


class ListarMinhasConsultasPaciente extends Component {
    constructor(){
        super();
        this.state = {
          lista : [],
          nome: "",
          tituloPagina : "Listar Minhas Consultas"
        }
  
        this.atualizaEstadoNome = this.atualizaEstadoNome.bind(this);
      
    }
  
    listarMinhasConsultasPaciente(){
        fetch('http://localhost:5000/Paciente/ExibirMinhasConsultas',
        {
          method: 'GET',
          headers: {
            "Content-Type" : "application/json",
            Authorization : 'Bearer '+ localStorage.getItem("Senai.SPMedicalGroup.DatabaseFirst")
           
          }
        })          .then(resposta => resposta.json())
          .then(data => this.setState({lista : data}))
          .catch((erro) => console.log(erro))
    }
  
    componentDidMount(){
      
        document.title = "Minhas Consultas"
    
    
        this.listarMinhasConsultasPaciente();
    }
  
    atualizaEstadoNome(event){
      this.setState({ nome : event.target.value });
    }
  
  
    render() {
      return (
        <div>       



<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light" href="/PainelDoPaciente/" >Retornar ao Painel do Paciente</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>



          <Table striped bordered hover className="container">
          <thead>
                    <tr>
                      <th>#</th>
                      <th>Paciente</th>
                      <th>Medico</th>
                      <th>Data da Consulta</th>
                      <th>Descrição</th>
                      <th>Status</th>
                     
                    </tr>
                  </thead>
  <tbody>
  {
                          this.state.lista.map(function(usuario){
                              return (
                                  <tr key={usuario.id}>
                                      <td>{usuario.id}</td>
                                      <td>{usuario.idPacienteNavigation.nome}</td>
                                      <td>{usuario.idMedicoNavigation.nome}</td>
                                      <td>{usuario.dataConsulta}</td>
                                      <td>{usuario.descricaoDaConsulta}</td>
                                      <td>{usuario.idStatusNavigation.statusConsulta1}</td>                                     

                                  </tr>
                              );
                          })
                      }
                  </tbody>
</Table>




        </div>
      );
    }
  }
  
  export default ListarMinhasConsultasPaciente;
  
   