
import React, { Component } from "react";
import Axios from "axios";
import logo2 from "../../assets/images/logo.png"
import {Link} from "react-router-dom";
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import { parseJwt } from "../../Services/auth";

class Login extends React.Component{

    constructor(){
        super();
        this.state = {
            email: "",
            senha: "",
            erro: "",
        };
    }

    atualizaEstadoEmail(event) {
        this.setState({email: event.target.value});
    }

    atualizaEstadoSenha(event){
        this.setState({senha: event.target.value});
    }


efetuarLogin(event){
    event.preventDefault();
    Axios
    .post("http://localhost:5000/api/Login", {
        email: this.state.email,
        senha: this.state.senha,

    })
    .then(data=>{
        if(data.status === 200){
           // this.setState({erro : data.data.token});
            localStorage.setItem("Senai.SPMedicalGroup.DatabaseFirst",data.data.token);
            if(parseJwt().regra =="1")
            {this.props.history.push("/PainelDoAdm/");}
            if(parseJwt().regra =="2")
            {this.props.history.push("/PainelDoMedico/");}
            if(parseJwt().regra =="3")
            {this.props.history.push("/PainelDoPaciente/");}
            
            
        }
        else{this.setState({erro: "Usuário ou Senha inválidos, digite corretamente!!"});
             console.log("erro");

         }
    })

    .catch(erro=>{
        this.setState({erro: "Usuário ou senha inválidos!"});
        console.log("erro");
    });

}

componentDidMount(){
  document.title = "Login"
}

    render() {
        return (
            <div>



<Navbar bg="primary" expand="lg">
  <Navbar.Brand href="/" bg="primary"style={{color:"white"}}> <img src={logo2} width="5%"/>SPMedical-Group "A sua saúde em primeiro lugar!"</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
    <Button variant="light"href="../">Home</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>

<Form className="container"style={{margin:"10%", padding:"10%"}}onSubmit ={this.efetuarLogin.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}>
      Email
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="email" placeholder="Digite seu email..."   value ={this.state.email}
                onChange= {this.atualizaEstadoEmail.bind(this)}/>
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword">
    <Form.Label column sm={2}>
      Senha
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="password" placeholder="Digite sua senha..."  value ={this.state.senha}
    onChange= {this.atualizaEstadoSenha.bind(this)}/>
    </Col>
  </Form.Group>
  <fieldset>
    <Form.Group as={Row}>
     
      <Col sm={10}>
   
      </Col>
    </Form.Group>
  </fieldset>
  
  
  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
    <p style={{color: 'red'}}> {this.state.erro} </p>
      <Button type="submit">Entrar</Button>
    </Col>
    
  </Form.Group>
  
</Form>




       
            </div>
    
  
                    
  
        )   
    }






}



export default Login;

