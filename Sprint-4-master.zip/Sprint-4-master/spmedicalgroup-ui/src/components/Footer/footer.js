import React, {Component} from 'react'
import {Link, withRouter} from 'react-router-dom';
import "../../assets/css/style.css"

class Titulo extends Component{
    render() {
        return(
        
              
              <h1>TEXTE</h1>
        );
    }
}

export default Titulo;