import React, {Component} from 'react'
import {Link, withRouter} from 'react-router-dom';

class Titulo extends Component{
    render() {
        return(
        
              
              <head>
  <title>{this.props.titulo}</title>
</head>
        );
    }
}

export default Titulo;