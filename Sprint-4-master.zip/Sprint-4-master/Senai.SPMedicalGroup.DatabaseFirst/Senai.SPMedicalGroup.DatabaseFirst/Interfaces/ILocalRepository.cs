﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface ILocalRepository
    {
        List<Locais> Listar();
        void Cadastrar(Locais local);
        void Apagar(int id);
        Locais Editar(Locais local);
    }
}
