﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IStatusConsultaRepository
    {
        List<StatusConsulta> Listar();
        void Cadastrar(StatusConsulta status);
        void Apagar(int id);
        StatusConsulta Editar(StatusConsulta consulta);
    }
}
