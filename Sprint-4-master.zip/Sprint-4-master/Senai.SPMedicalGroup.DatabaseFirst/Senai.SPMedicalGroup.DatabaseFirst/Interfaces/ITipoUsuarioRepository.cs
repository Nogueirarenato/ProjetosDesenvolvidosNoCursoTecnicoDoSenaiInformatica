﻿using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface ITipoUsuarioRepository
    {
        List<TipoUsuarios> Listar();
        void Cadastrar(TipoUsuarios tipoUsuarios);
        void Apagar(int id);
        TipoUsuarios Editar(TipoUsuarios tipo);
    }
}
