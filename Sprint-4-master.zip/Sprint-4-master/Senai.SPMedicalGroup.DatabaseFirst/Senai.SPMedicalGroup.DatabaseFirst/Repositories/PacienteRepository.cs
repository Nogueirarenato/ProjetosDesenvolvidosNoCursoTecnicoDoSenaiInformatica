﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class PacienteRepository : IPacienteRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();

        public void Apagar(int id)
        {
            Pacientes PacienteProcurado = ctx.Pacientes.Find(id);
            ctx.Pacientes.Remove(PacienteProcurado);
            ctx.SaveChanges();
        }

        public Pacientes BuscarPorEmailSenha(string Email, string Senha)
        {
            Pacientes pacienteProcuradoEmail = new Pacientes();
            pacienteProcuradoEmail = ctx.Pacientes.ToList().Find(d=> d.Email == Email && d.Senha==Senha);
            return (pacienteProcuradoEmail); 
            }


            public void Cadastrar(Pacientes paciente)
        {
            ctx.Pacientes.Add(paciente);
            ctx.SaveChanges();
        }

        public Pacientes Editar(Pacientes paciente)
        {
            using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
            {


                Pacientes pacienteExiste = ctx.Pacientes.Find(paciente.Id);

                if (pacienteExiste != null)
                {
                    pacienteExiste.Nome = paciente.Nome;
                    pacienteExiste.DataNascimento = paciente.DataNascimento;
                    pacienteExiste.EnderecoResidencial = paciente.EnderecoResidencial;
                    pacienteExiste.Cpf = paciente.Cpf;
                    pacienteExiste.Email = paciente.Email;
                    pacienteExiste.Senha = paciente.Senha;
                    pacienteExiste.Telefone = paciente.Telefone;
                    pacienteExiste.Rg = paciente.Rg;
                    pacienteExiste.IdUsuario = paciente.IdUsuario;
                    
                    
                    ctx.Pacientes.Update(pacienteExiste);
                    ctx.SaveChanges();

                    return pacienteExiste;
                }

                return null;
            }
        }

        public List<Pacientes> Listar()
        {
            return (ctx.Pacientes.Include(k=> k.IdUsuarioNavigation).ToList());
        }
    }
}
