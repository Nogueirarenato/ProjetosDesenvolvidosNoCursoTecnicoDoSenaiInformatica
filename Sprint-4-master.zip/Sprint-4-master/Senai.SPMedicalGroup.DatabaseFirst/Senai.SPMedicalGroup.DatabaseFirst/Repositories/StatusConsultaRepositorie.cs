﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class StatusConsultaRepositorie : IStatusConsultaRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();

        public void Apagar(int id)
        {
            StatusConsulta statusProcurado = ctx.StatusConsulta.Find(id);
            ctx.StatusConsulta.Remove(statusProcurado);
            ctx.SaveChanges();
        }

        public void Cadastrar(StatusConsulta status)
        {
            ctx.StatusConsulta.Add(status);
            ctx.SaveChanges();
        }

        public StatusConsulta Editar(StatusConsulta consulta)
        {
           
                using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
                {

                    StatusConsulta consultaExiste = ctx.StatusConsulta.Find(consulta.Id);

                    if (consultaExiste != null)
                    {
                        consultaExiste.StatusConsulta1 = consulta.StatusConsulta1;
                        ctx.StatusConsulta.Update(consultaExiste);
                        ctx.SaveChanges();

                        return consultaExiste;
                    }

                    return null;
                }
            
        }

        public List<StatusConsulta> Listar()
        {
            return (ctx.StatusConsulta.ToList());
        }
    }
}
