﻿using Microsoft.EntityFrameworkCore;
using Senai.SPMedicalGroup.DatabaseFirst.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Senai.SPMedicalGroup.DatabaseFirst.Repositories
{
    public class MedicoRepository : IMedicoRepository
    {
        SPMedicalGroupContext ctx = new SPMedicalGroupContext();


        public void Apagar(int id)
        {
            Medicos MedicoProcurado = ctx.Medicos.Find(id);
            ctx.Medicos.Remove(MedicoProcurado);
            ctx.SaveChanges();
        }

        public Medicos BuscarPorEmailSenha(string Email, string Senha)
        {
            Medicos medicoProcuradoEmail = new Medicos();


            medicoProcuradoEmail = ctx.Medicos.ToList().Find(c => c.Email == Email && c.Senha == Senha);
            return medicoProcuradoEmail; 
        }

        public void Cadastrar(Medicos medico)
        {
            ctx.Medicos.Add(medico);
            ctx.SaveChanges();
        }

        public Medicos Editar(Medicos medico)
        {
            
                using (SPMedicalGroupContext ctx = new SPMedicalGroupContext())
                {

                    Medicos medicoExiste = ctx.Medicos.Find(medico.Id);

                    if (medicoExiste != null)
                    {
                    medicoExiste.Nome = medico.Nome;
                    medicoExiste.Email = medico.Email;
                    medicoExiste.Senha = medico.Senha;
                    medicoExiste.Crm = medico.Crm;
                        ctx.Medicos.Update(medicoExiste);
                        ctx.SaveChanges();

                        return medicoExiste;
                    }

                    return null;
                }
            
        }

        public List<Medicos> Listar()
        {
return (ctx.Medicos.Include(d=> d.IdEspecialidadeNavigation).Include(c=> c.IdUsuarioNavigation).Include(k=> k.IdLocalNavigation).ToList());
            
        }

        public int pegarIdMedico()
        {
            throw new NotImplementedException();
        }
    }
}
