using System;
namespace Senai.Projetos.FolhaDepagamento.V2.Classes

{
    public class Funcionarios
    {
        
        public int codigo;
       


#region Menu
      public  int menu(){

            System.Console.WriteLine("***Bem vindo ao sistema de cadastramento de Funcionários!!!***\n\n\n");
            System.Console.WriteLine("Escolha a opção desejada:\n");
            System.Console.WriteLine("1-Cadastro de novo funcionário.");
            System.Console.WriteLine("2-Exibição da Lista Funcionários:");
            System.Console.WriteLine("3-Exibição da Folha Pagamento individual:");
            System.Console.WriteLine("4-Exibir Total de Custos Bruto da Folha ");
            System.Console.WriteLine("5-Efetuar aumento de salário");
            System.Console.WriteLine("6-Exibir total de Custos Líquidos da Folha");
            System.Console.WriteLine("7-Exibir o maior e o menor salário");
            System.Console.WriteLine("8-Alterar o cadastro de um funcionário");
            System.Console.WriteLine("9-Remover um funcionário");
            System.Console.WriteLine("0- Sair do programa\n\n\n\n");
            codigo=int.Parse(Console.ReadLine());
            return codigo;
      }
    
#endregion

#region CadastrarUsuario

 public string nome {get; set;}
 public double remuneracao {get; set;}
 public double inss {get; set;}
 public double IRPF {get; set;}
public double ValeTransporte {get; set;}
public double TotalDescontos {get; set;}
public double SalarioLiquido {get; set;}

public int apagar;




 public void CadastrarUsuario(){

    string confirma ="000";

    do {    
    System.Console.WriteLine("Entre com o nome do funcionário: \n");
    nome= Console.ReadLine();
    System.Console.WriteLine("Entre com o salário do funcionário: \n");
    remuneracao=Double.Parse(Console.ReadLine());
    System.Console.WriteLine("Funcionário "+nome+ " Salário: "+remuneracao+"\n Digite S para confirmar.");
    confirma=Console.ReadLine();
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;
    
    }while(confirma!="S");
    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
    Console.ReadKey();
                        
    
}
#endregion
public double Faixa1(){
    remuneracao=remuneracao*1.15;
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;
    return 0;}

 public double Faixa2(){
    remuneracao=remuneracao*1.10;
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;
    return 0;}


  public double Faixa3(){
    remuneracao=remuneracao*1.08;
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;
    return 0;}

     public double Faixa4(){
    remuneracao=remuneracao*1.05;
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;
    return 0;}

#region Remover usuario
    
public void RemoverUsuario(){

    string confirma ="000";
    string sair="null"; 
    do {  apagar=0;
    System.Console.WriteLine("Deseja realmente remover o funcionário "+nome+"\nDigite S para confirmar.");
    confirma=Console.ReadLine();
    
    if(confirma=="S"){
    nome="Usuário desligado da empresa"; 
    apagar=1;   
    remuneracao=0;
    inss = remuneracao*11/100;
    IRPF= remuneracao*75/1000;
    ValeTransporte=remuneracao*6/100;
    TotalDescontos= inss+IRPF+ValeTransporte;
    SalarioLiquido = remuneracao-TotalDescontos;}
    else{
        
        System.Console.WriteLine("\n\nCaso deseje voltar ao menu incial digite 'sair'\n\n");
        sair=Console.ReadLine();
    }
    
    }while(confirma!="S" && sair!="sair");
    sair="null"; 
    
                        
    
}
#endregion

    





    }
}