﻿using System;
using Senai.Projetos.FolhaDepagamento.V2.Classes;


namespace Senai.Projetos.FolhaDePagamento.V2
{
    class Program
    {
        static void Main(string[] args)
        {   int k=1;
            int sair;
            int i;
            int desligados=0;
            double totalBruto=0;
            Double totalLiquido=0;
            
            
            Funcionarios[] total = new Funcionarios[k];
            Funcionarios novo =new Funcionarios();
            sair= novo.menu();
          


            do{
                Funcionarios novos= new Funcionarios();
                
            
            switch(sair) {
                case 1: {
                        
                        Array.Resize(ref total, k);                        
                        total [k-1]=new Funcionarios();
                        total[k-1].CadastrarUsuario();
                        k++;
                        sair= novo.menu();
                       
                    break;
                }
                case 2:{
                    
                    for ( i = 0; i < k-1; i++)
                    {
                     System.Console.WriteLine($"Funcionário matricula nº {i+1} Nome: {total[i].nome} " );
                     }
                    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();
                    break;
                }
                 case 3:{
                     System.Console.WriteLine("******Digite a matrícula do funcionario******\n\n");
                     i=int.Parse(Console.ReadLine());
                     i=i-1;
                     if(i<k-1){System.Console.WriteLine($"Funcionário matricula nº {i+1}\nNome: {total[i].nome}\nSalário Bruto: R$ {total[i].remuneracao}\nINSS= R$ {total[i].inss}\nIRPF= R$ {total[i].IRPF}\nVT= R$ {total[i].ValeTransporte}\nDescontos: R$ {total[i].TotalDescontos}\nSalário liquido: R$ {total[i].SalarioLiquido}\n\n\n\n\n" );
                     }
                     else
                     {
                         System.Console.WriteLine("Funcionário não cadastrado, retorne ao menu principal e veja a lista de usuários cadastrados\nOpção'2'\n\n\n");
                     }

                    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();
                    break;
                }
                 case 4:{

                     System.Console.WriteLine($"Atualmente temos {k-1} empregados dos quais {k-1-desligados} estão ativos e  {desligados} estão desligados.");
                    

                     for ( i = 0; i < k-1; i++){totalBruto=totalBruto+total[i].remuneracao;}
                     System.Console.WriteLine("O total Bruto da folha de pagamento é R$ "+totalBruto);
                    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();


                    break;
                }
                 case 5:{

                     
                     System.Console.WriteLine("******Digite a matrícula do funcionario a receber aumento******\n\n");
                     i=int.Parse(Console.ReadLine());
                     i=i-1;
                     
                    
                     
                     if(i<k-1){
                         
                         
                         
                         System.Console.WriteLine("****Salario Anterior****");
                          System.Console.WriteLine($"Funcionário matricula nº {i+1}\nNome: {total[i].nome}\nSalário Bruto: R$ {total[i].remuneracao}\nINSS= R$ {total[i].inss}\nIRPF= R$ {total[i].IRPF}\nVT= R$ {total[i].ValeTransporte}\nDescontos: R$ {total[i].TotalDescontos}\nSalário liquido: R$ {total[i].SalarioLiquido}\n\n\n\n\n" );
                         if(total[i].remuneracao<= 2*834.50)total[i].Faixa1();
                         if(total[i].remuneracao> 2*834.50 && total[i].remuneracao<= 4*834.50)total[i].Faixa2();
                         if(total[i].remuneracao> 4*834.50 && total[i].remuneracao<= 8*834.50)total[i].Faixa3();
                         if(total[i].remuneracao> 8*834.50)total[i].Faixa4();
                         
                    System.Console.WriteLine("****Salario atualizado****");
                    System.Console.WriteLine($"Funcionário matricula nº {i+1}\nNome: {total[i].nome}\nSalário Bruto: R$ {total[i].remuneracao}\nINSS= R$ {total[i].inss}\nIRPF= R$ {total[i].IRPF}\nVT= R$ {total[i].ValeTransporte}\nDescontos: R$ {total[i].TotalDescontos}\nSalário liquido: R$ {total[i].SalarioLiquido}\n\n\n\n\n" );
                            
                     }
                     else
                     {
                         System.Console.WriteLine("Funcionário não cadastrado, retorne ao menu principal e veja a lista de usuários cadastrados\nOpção'2'\n\n\n");
                     }

                    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();

                    break;
                }
                 case 6:{

                     System.Console.WriteLine($"Atualmente temos {k-1} empregados dos quais {k-1-desligados} estão ativos e  {desligados} estão desligados.");
                    

                     for ( i = 0; i < k-1; i++){totalLiquido=totalLiquido+total[i].SalarioLiquido;}
                     System.Console.WriteLine("O total Liquido da folha de pagamento é R$ "+totalLiquido);
                    System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();


                    break;


                }
                 case 7:{


                        double maior=0;
                        double menor=9999999999999999999;


                    for (i=0; i<k-2; i++){
                        if(total[i+1].remuneracao>=total[i].remuneracao && total[i+1].remuneracao>=maior)maior=total[i+1].remuneracao;

                    }


                    for (i=0; i<k-2; i++){
                        if(total[i+1].remuneracao<=total[i].remuneracao && total[i+1].remuneracao<=menor)menor=total[i+1].remuneracao;

                    }



                System.Console.WriteLine("\n\nO maior salário é de R$ "+maior);
                System.Console.WriteLine("\n\nO menor salário é de R$ "+menor);
                System.Console.WriteLine("\n\n");



                     

                System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();





                    break;
                }
                 case 8:{

                System.Console.WriteLine("\n\n*******Digite a matrícula do funcionário o qual deseja efetuar atualizações******\n\n");


                i=int.Parse(Console.ReadLine());

                if(i<k-1){
                            total[i-1].CadastrarUsuario();
                }
                
                else{
                
                System.Console.WriteLine("Funcionário não cadastrado, retorne ao menu principal e veja a lista de usuários cadastrados\nOpção'2'\n\n\n");

                }

                System.Console.WriteLine("\n\n");     

                System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();




                    break;
                }
                 case 9:{
                System.Console.WriteLine("\n\n*******Digite a matrícula do funcionário o qual deseja remover do sistema******\n\n");


                i=int.Parse(Console.ReadLine());

                if(i<k){
                            Funcionarios apag = new Funcionarios();
                            total[i-1].RemoverUsuario(); 
                            desligados= desligados+ apag.apagar;
                }
                
                else{
                
                System.Console.WriteLine("Funcionário não cadastrado, retorne ao menu principal e veja a lista de usuários cadastrados\nOpção'2'\n\n\n");

                }

                System.Console.WriteLine("\n\n");     

                System.Console.WriteLine("Pressione Alguma tecla para voltar ao menu inicial...\n");
                    Console.ReadKey();
                    sair= novo.menu();


                    break;
                }

                 case 0:{System.Console.WriteLine("Opção Digitada: 0 ");
                    break;
                }
                default:

                { System.Console.WriteLine(""+sair);
                      System.Console.WriteLine("opção invalida");
                    break;
                }
            }     
            
            }while(sair!=0);



        }
    }
}
