import React, { Component } from "react";
import Axios from 'axios';
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import Nav from "../../../node_modules/react-bootstrap/Nav"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Logo from "../../assets/pics/logo.png"
import Dropdown from "../../../node_modules/react-bootstrap/Dropdown"




class AdicionarPizzaria extends Component {
    constructor() {
        super();
        this.state = {
            nome: "",
            telefone: "",
            endereco: "",
            vegana: "false",
            categoria: "",
            check:"no"}

        this.atualizaNome = this.atualizaNome.bind(this);
        this.atualizaTelefone = this.atualizaTelefone.bind(this);
        this.atualizaEndereco = this.atualizaEndereco.bind(this);
        this.atualizaVegana = this.atualizaVegana.bind(this);
        this.atualizaCategoria = this.atualizaCategoria.bind(this)
        this.atualizaCategoriaA = this.atualizaCategoriaA.bind(this)
        this.atualizaCategoriaB = this.atualizaCategoriaB.bind(this)
        this.atualizaCategoriaC = this.atualizaCategoriaC.bind(this)
        this.atualizaCheck= this.atualizaCheck.bind(this);
       
    }



    atualizaNome(event) {
        this.setState({ nome: event.target.value });
    }

    atualizaTelefone(event) {
        this.setState({ telefone: event.target.value });
    }

    atualizaEndereco(event) {
        this.setState({ endereco: event.target.value });
    }

    atualizaVegana(event) {
        this.setState({ vegana:"true" });

    }

    atualizaCheck(event){
        this.setState({ check : "yes" });
      }

      atualizaCategoria(event) {
        this.setState({ categoria: event.target.value });
    }

    atualizaCategoriaA(event) {
      this.setState({ categoria: "a" });
  }

  atualizaCategoriaB(event) {
    this.setState({ categoria: "b" });
}
atualizaCategoriaC(event) {
  this.setState({ categoria: "c" });
}


    cadastraPizzaria(event) {
        
        
      event.preventDefault();

    fetch('http://localhost:5000/api/Pizzarias',
    {
      method: 'POST',
      body : JSON.stringify({  nome : this.state.nome
        , telefone: this.state.telefone
        , endereco: this.state.endereco
        , vegana: this.state.vegana
        , categoria: this.state.categoria
      }),   





      headers: {
        
        "Content-Type" : "application/json",
        Authorization: "Bearer "+ localStorage.getItem("webpizzas")
        
        
      }
    })
    .then(resposta => resposta,
        this.setState({erro: "Pizzaria Cadastrada com sucesso!!!"}))
    .catch(erro => console.log(erro))
}
componentDidMount(){
  document.title = "Adicionar Pizzaria"
}

    render() {
        return (
            <div>


<Navbar >
  <Navbar.Brand href="/" ><img src ={Logo} width="100" /></Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
    
     
    </Nav>
    <Form inline>
      <div>
      <Button href="/">Listar Pizzarias</Button>
      <br/>
      </div>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color:"yellow", fontSize:"3em", textAlign:"center"}}>Adicionar Pizzaria</p>

<p style={{color: 'yellow', fontSize: "300%", textAlign: "center"}}> {this.state.erro} </p>
<Form style={{width:"50%", margin:"10%",textAlign:"right"}} onSubmit={this.cadastraPizzaria.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2}style={{color:"yellow", textAlign:"end", fontSize: "1.5em"}}>
      Nome
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o nome da Pizzaria" type="text" value={this.state.nome} onChange={this.atualizaNome} />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword"  value={this.state.telefone} onChange={this.atualizaTelefone}>
    <Form.Label column sm={2} style={{color:"yellow", textAlign:"end", fontSize: "1.5em"}}>
      Telefone
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite o telefone da Pizzaria" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalEmail" value={this.state.endereco} onChange={this.atualizaEndereco}>
    <Form.Label column sm={2} style={{color:"yellow", textAlign:"right", fontSize: "1.5em"}}>
      Endereço
    </Form.Label>
    <Col>
      <Form.Control type="text" placeholder="Digite o endereço da Pizzaria" />
    </Col>
  </Form.Group>

  <Dropdown style={{textAlign:"left", marginLeft:"0"}} id="categoria">
  <Dropdown.Toggle >
   Categoria
  </Dropdown.Toggle>

  <Dropdown.Menu>
    <Dropdown.Item value={"c"} onSelect={this.atualizaCategoriaC.bind(this)}>$ (até 30 reais)</Dropdown.Item>
    <Dropdown.Item value={"b"} onSelect={this.atualizaCategoriaB.bind(this)}>$$ (de 31 até 50 reais)</Dropdown.Item>
    <Dropdown.Item value={"a"} onSelect={this.atualizaCategoriaA.bind(this)}>$$$ (acima de 50 reais)</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>







  <Form.Group controlId="formBasicChecbox">
    <Form.Check  label="Possui opções Veganas?" type="checkbox" style={{color:"yellow", textAlign:"end", fontSize: "1.5em"}} value={this.state.vegana} onChange={this.atualizaVegana} />
  </Form.Group>

 

   
    



  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
      <Button type="submit">Adicionar Pizzaria</Button>
    </Col>
  </Form.Group>
</Form>;


            </div>
        );
    }
}

export default AdicionarPizzaria;

