import React, { Component } from 'react';
import Carousel from "../../../node_modules/react-bootstrap/Carousel"
import slide1 from "../../assets/pics/slide01.png"
import slide2 from "../../assets/pics/slide02.png"
import slide3 from "../../assets/pics/slide03.png"
import slide4 from "../../assets/pics/slide04.png"
import slide5 from "../../assets/pics/slide05.png"
import "../../../node_modules/bootstrap/dist/css/bootstrap.css"
import "../../assets/css/meuEstilo.css"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import Nav from "../../../node_modules/react-bootstrap/Nav"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Logo from "../../assets/pics/logo.png"
import Container from "../../../node_modules/react-bootstrap/Container"
import Table from "../../../node_modules/react-bootstrap/Table"



let check = "no"
let contador = 1;
let mudou;

class Home extends Component {

  constructor() {
    super();
    this.state = {
      lista: [],
      tituloPagina: "Pizzarias",

    }

    this.atualizaCheck = this.atualizaCheck.bind(this);
    this.listarPizzarias = this.listarPizzarias.bind(this);
  }

  listarPizzarias(){

    fetch('http://localhost:5000/api/Pizzarias', {
      method: 'GET',
      headers: {
        "Content-Type": "application/json",
      }
    })
      .then(resposta => resposta.json())
      .then(data => this.setState({ lista: data }))
      .catch((erro) => console.log(erro))
  }

  componentDidMount() {
    document.title = "Pizzarias"
    this.listarPizzarias();
  }

  atualizaCheck(event) {
    mudou=0;
    if (check == "yes") {check = "no"; mudou=1};
    if (check == "no" && mudou ==0) check = "yes";
  }


  render() {
    return (


      <div>



        <Navbar >
          <Navbar.Brand href="/" ><img src={Logo} width="100" /></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">


            </Nav>
            <Form inline >
              <div>
                <Button type="button" onClick={this.listarPizzarias.bind(this)} >Listar Pizzarias</Button>
                <Form.Check type="checkbox" label="Apenas com opções veganas" style={{ color: "yellow", marginTop: "1%" }} value={this.check} onChange={this.atualizaCheck.bind(this)} />
                <br />
              </div>
            </Form>
          </Navbar.Collapse>
        </Navbar>




        <Container>
          <Container>

            <Carousel style={{ width: "95%", marginLeft: "auto", marginRight: "auto", marginTop: "0" }}>
              <Carousel.Item>



                <img
                  className="d-block w-100"
                  src={slide1}
                  alt="First slide"
                />

                <Carousel.Caption>
                  <div >
                  </div>
                </Carousel.Caption>

              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={slide2}
                  alt="Third slide"
                />

                <Carousel.Caption>
                  <div>
                  </div>
                </Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={slide3}
                  alt="Third slide"
                />

                <Carousel.Caption>
                  <div>
                  </div>
                </Carousel.Caption >
              </Carousel.Item>

              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={slide4}
                  alt="Third slide"
                />

                <Carousel.Caption>
                  <div>
                  </div>
                </Carousel.Caption>
              </Carousel.Item>

              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={slide5}
                  alt="Third slide"
                />

                <Carousel.Caption>
                  <div>
                  </div>
                </Carousel.Caption>
              </Carousel.Item>



            </Carousel>

            <Table className="Tabela">

              <thead>
                <tr>
                  <th>#</th>
                  <th>Pizzaria</th>
                  <th>Telefone</th>
                  <th>Endereço</th>
                  <th>Opções Veganas?</th>
                  <th>Categoria</th>
               
                </tr>
              </thead>

              <tbody>
                {

                  this.state.lista.map(


                    function (pizzaria) {


                      if (pizzaria.vegana == '1') pizzaria.vegana = 'sim'
                      if (pizzaria.vegana == '0') pizzaria.vegana = 'não'
                      if (pizzaria.categoria == "a") pizzaria.categoria = "$$$ (acima de 50 reais)"
                      if (pizzaria.categoria == "b") pizzaria.categoria = "$$ (de 31 até 50 reais)"
                      if (pizzaria.categoria == "c") pizzaria.categoria = "$ (até 30 reais)"




                    if(check=="no")
                    {
                      return (




                        <tr key={pizzaria.id}>
                          <td className="textoCentro">{pizzaria.id}</td>
                          <td>{pizzaria.nome}</td>
                          <td className="textoCentro">{pizzaria.telefone}</td>
                          <td>{pizzaria.endereco}</td>
                          <td className="textoCentro">{pizzaria.vegana}</td>
                          <td className="textoCentro">{pizzaria.categoria}</td>
                          
                        </tr>
                      );
                    }


                    if(check=="yes" && pizzaria.vegana=="sim")
                    {
                      return (




                        <tr key={pizzaria.id}>
                          <td className="textoCentro">{pizzaria.id}</td>
                          <td>{pizzaria.nome}</td>
                          <td className="textoCentro">{pizzaria.telefone}</td>
                          <td>{pizzaria.endereco}</td>
                          <td className="textoCentro">{pizzaria.vegana}</td>
                          <td className="textoCentro">{pizzaria.categoria}</td>
                          
                        </tr>
                      );
                    }
                      







                    }



                    )
                    
                }
              </tbody>
            </Table>

          </Container>
        </Container>



        <a href="/Login" style={{ color: "yellow", margin: "2%" }}>Login</a>
      </div>


    );
  }
}

export default Home;
