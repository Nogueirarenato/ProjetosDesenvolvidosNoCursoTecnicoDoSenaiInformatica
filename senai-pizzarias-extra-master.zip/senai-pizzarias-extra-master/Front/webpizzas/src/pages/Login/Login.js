
import React, { Component } from "react";
import Axios from "axios";
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import Row from "../../../node_modules/react-bootstrap/Row"
import Col from "../../../node_modules/react-bootstrap/Col"
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import Logo from "../../assets/pics/logo.png"
import Nav from "../../../node_modules/react-bootstrap/Nav"
import { getToken} from "../../Services/auth";

class Login extends React.Component{

    constructor(){
        super();
        this.state = {
            nome: "",
            senha: "",
            erro: "",
        };
    }

    atualizaEstadoNome(event) {
        this.setState({nome: event.target.value});
    }

    atualizaEstadoSenha(event){
        this.setState({senha: event.target.value});
    }


efetuarLogin(event){
    event.preventDefault();
    Axios
    .post("http://localhost:5000/api/Login", {
        nome: this.state.nome,
        senha: this.state.senha,

    })
    .then(data=>{
        if(data.status === 200){
             localStorage.setItem("webpizzas",data.data.token);
             if(getToken().regra !=null)
             {this.props.history.push("/PainelDoAdm/");}
                       
             
         
        }
        else{this.setState({erro: "Usuário ou Senha inválidos, digite corretamente!!"});
             console.log("erro");

         }
    })

    .catch(erro=>{
        this.setState({erro: "Usuário ou senha inválidos!" });
        console.log("erro");
    });

}

componentDidMount(){
  document.title = "Login"
}

    render() {
        return (
            <div>


     
<Navbar >
  <Navbar.Brand href="/" ><img src ={Logo} width="100" /></Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
    
     
    </Nav>
    <Form inline>
      <div>
      <Button href="/">Listar Pizzarias</Button>
      <br/>
      </div>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color:"yellow", fontSize:"3em", textAlign:"center"}}>Login para Administrador</p>



<Form className="container"style={{margin:"5%", padding:"5%"}}onSubmit ={this.efetuarLogin.bind(this)}>
  <Form.Group as={Row} controlId="formHorizontalEmail">
    <Form.Label column sm={2} style={{color:"yellow", textAlign:"right", fontSize: "1.5em"}}>
      Nome
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Digite seu nome..."   value ={this.state.nome}
                onChange= {this.atualizaEstadoNome.bind(this)}/>
    </Col>
  </Form.Group>

  <Form.Group as={Row} controlId="formHorizontalPassword">
    <Form.Label column sm={2} style={{color:"yellow", textAlign:"right", fontSize: "1.5em"}}>
      Senha
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="password" placeholder="Digite sua senha..."  value ={this.state.senha}
    onChange= {this.atualizaEstadoSenha.bind(this)}/>
    </Col>
  </Form.Group>
  <fieldset>
    <Form.Group as={Row}>
     
      <Col sm={10}>
   
      </Col>
    </Form.Group>
  </fieldset>
  
  
  <Form.Group as={Row}>
    <Col sm={{ span: 10, offset: 2 }}>
    <p style={{color:"yellow", fontSize:"2em"}}> {this.state.erro} </p>
      <Button type="submit">Entrar</Button>
    </Col>
    
  </Form.Group>
  
</Form>



            </div>
    
  
                    
  
        )   
    }






}



export default Login;

