import React, { Component } from "react";
import Navbar from "../../../node_modules/react-bootstrap/Navbar"
import Form from "../../../node_modules/react-bootstrap/Form"
import Button from "../../../node_modules/react-bootstrap/Button"
import ButtonGroup from "../../../node_modules/react-bootstrap/ButtonGroup"
import Nav from "../../../node_modules/react-bootstrap/Nav"
import Logo from "../../assets/pics/logo.png"




class PainelDoAdm extends Component {
  
  componentDidMount(){
    document.title = "Painel do ADM"
}

    render() {
      return (
        <div>       
     
     <Navbar >
  <Navbar.Brand href="/" ><img src ={Logo} width="100" /></Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
    
     
    </Nav>
    <Form inline>
      <div>
      <Button href="/">Listar Pizzarias</Button>
      <br/>
      </div>
    </Form>
  </Navbar.Collapse>
</Navbar>

<p style={{color:"yellow", fontSize:"3em", textAlign:"center"}}>Painel do Administrador</p>

<div className="d-flex flex-row" style={{alignContent:"center", marginLeft:"40%"}}>
<ButtonGroup style={{marginTop:"3%"}}vertical className="center" size="lg">
  <Button style={{marginTop:"3%"}} href="/AdicionarPizzaria/" >AdicionarPizzaria</Button>
 

  
</ButtonGroup>


</div>





        </div>
      )
    }
  }
  
  export default PainelDoAdm;
  