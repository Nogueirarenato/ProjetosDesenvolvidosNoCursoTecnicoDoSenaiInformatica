import React from 'react';
import {Route, BrowserRouter as Router, Redirect} from "react-router-dom"
import ReactDOM from 'react-dom';
import './index.css';
import Home from './pages/Home/home';
import * as serviceWorker from './serviceWorker';
import PainelDoAdm from './pages/PainelDoAdm/PainelDoAdm';
import Login from './pages/Login/Login'
import AdicionarPizzaria from "./pages/AdicionarPizzaria/AdicionarPizzaria"
import {usuarioAutenticado, getToken} from "../src/Services/auth"

const PermissaoADM = ({ component: Component, ...rest }) => (
    <Route
      {...rest}
      render={props =>
        usuarioAutenticado()  && getToken().regra == "Gandolf" ?(
          <Component {...props} />
        ) : (
          <Redirect to={{ pathname: "/", state: { from: props.location } }} />
        )
      }
    />
  );
const routing=(
    <Router>
        <div>
            <Route exact path="/" component ={Home}/>
            <Route exact path="/PainelDoAdm/" component ={PainelDoAdm}/>
            <Route exact path="/Login" component ={Login}/>
            <PermissaoADM Route exact path="/AdicionarPizzaria" component = {AdicionarPizzaria}/>

        </div>
    </Router>
)


ReactDOM.render(routing, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
