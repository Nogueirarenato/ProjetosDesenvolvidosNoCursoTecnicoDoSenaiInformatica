using Pizzaria.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IPizzariasRepository
    {

        List<Pizzarias> Listar();
        void Cadastrar(Pizzarias pizzaria);
        Pizzarias Editar(Pizzarias pizzaria);
        Pizzarias BuscarPorNome(string Nome);
        void Apagar(int id);


    }
}
