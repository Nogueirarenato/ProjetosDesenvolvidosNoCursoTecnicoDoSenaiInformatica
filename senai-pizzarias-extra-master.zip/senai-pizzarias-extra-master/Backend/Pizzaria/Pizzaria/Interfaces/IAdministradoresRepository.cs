using Pizzaria.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SPMedicalGroup.DatabaseFirst.Interfaces
{
    interface IAdministradoresRepository
    {

        List<Administradores> Listar();
        void Cadastrar(Administradores administrador);
        Administradores Editar(Administradores administrador);
        Administradores BuscarPorNomeSenha(string Nome, string Senha);

    }
}
