using Microsoft.EntityFrameworkCore;
using Pizzaria.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pizzaria.Repositories
{




    public class PizzariasRepository : IPizzariasRepository
    {
        PizzariaContext ctx = new PizzariaContext();

        public void Apagar(int id)
        {
            Pizzarias pizzariaProcurada = ctx.Pizzarias.Find(id);
            ctx.Pizzarias.Remove(pizzariaProcurada);
            ctx.SaveChanges();
        }

        public Pizzarias BuscarPorNome(string Nome)
        {
            throw new NotImplementedException();
        }

        public void Cadastrar(Pizzarias pizzaria)
        {
            ctx.Pizzarias.Add(pizzaria);
            ctx.SaveChanges();
        }

        public Pizzarias Editar(Pizzarias pizzaria)
        {
            {
                Pizzarias pizzariaExiste = ctx.Pizzarias.Find(pizzaria.Id);

                if (pizzariaExiste != null)
                {
                    pizzariaExiste.Nome = pizzaria.Nome;
                    pizzariaExiste.Endereco = pizzaria.Endereco;
                    pizzariaExiste.Telefone = pizzaria.Telefone;
                    pizzariaExiste.Vegana = pizzaria.Vegana;
                    pizzariaExiste.Categoria = pizzaria.Categoria;

                        ctx.Pizzarias.Update(pizzariaExiste);
                    ctx.SaveChanges();

                    return pizzariaExiste;
                }

                return null;
            }
        }

        public List<Pizzarias> Listar()
        {
            return (ctx.Pizzarias.ToList());
        }
    }
}