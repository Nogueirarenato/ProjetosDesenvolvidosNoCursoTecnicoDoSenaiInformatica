using Microsoft.EntityFrameworkCore;
using Pizzaria.Domains;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pizzaria.Repositories
{




    public class AdministradoresRepository : IAdministradoresRepository
    {
        PizzariaContext ctx = new PizzariaContext();

        public Administradores BuscarPorNomeSenha(string Nome, string Senha)
        {
            Administradores administradorProcuradoNome = new Administradores();
            administradorProcuradoNome = ctx.Administradores.ToList().Find(d => d.Nome == Nome && d.Senha == Senha);
            return (administradorProcuradoNome);
        }

        public void Cadastrar(Administradores administrador)
        {
            ctx.Administradores.Add(administrador);
            ctx.SaveChanges();
        }

        public Administradores Editar(Administradores administrador)
        {

            { 
                Administradores administradorExiste = ctx.Administradores.Find(administrador.Id);

                if (administradorExiste != null)
                {
                administradorExiste.Nome = administrador.Nome;
                administradorExiste.Senha = administrador.Senha;
                  


                    ctx.Administradores.Update(administradorExiste);
                    ctx.SaveChanges();

                    return administradorExiste;
                }

                return null;
            }
        }

        public List<Administradores> Listar()
        {
            return (ctx.Administradores.ToList());
        }
    }
}
