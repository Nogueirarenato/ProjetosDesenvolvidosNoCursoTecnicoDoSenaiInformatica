﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Pizzaria.Domains;
using Pizzaria.Repositories;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;

namespace Pizzaria.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PizzariasController : Controller
    {
        private IPizzariasRepository PizzariaRepository { get; set; }

        public PizzariasController()
        {
            PizzariaRepository = new PizzariasRepository();
        }

       

        //Listar as Pizzarias
        [HttpGet]
        public IActionResult Get()
        {
            try
            {

                return Ok(PizzariaRepository.Listar());

            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Uma pizzaria
        [Authorize]
        [HttpPost]
        public IActionResult Post(Pizzarias pizzaria)
        {
            try
            {
                PizzariaRepository.Cadastrar(pizzaria);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }

        //Modificar uma pizzaria
        [Authorize]
        [HttpPut()]
        public IActionResult Put(Pizzarias pizzaria)
        {

            PizzariaRepository.Editar(pizzaria);
            if (PizzariaRepository.Editar(pizzaria) == null) { return NotFound(); }
            return Ok();

        }


        // Apagar uma Pizzaria
        [Authorize]
        [HttpDelete()]
        public IActionResult Delete(Pizzarias pizzaria)
        {
            int id = new int();
            id = pizzaria.Id;
             
            try
            {
                PizzariaRepository.Apagar(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }

        }

        //


    }
}