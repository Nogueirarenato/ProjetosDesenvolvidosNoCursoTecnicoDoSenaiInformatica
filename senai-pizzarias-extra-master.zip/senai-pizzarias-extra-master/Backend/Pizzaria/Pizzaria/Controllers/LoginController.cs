﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Pizzaria.Domains;
using Pizzaria.Repositories;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;

namespace Pizzaria.Controllers
{

    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IAdministradoresRepository AdministradorRepository { get; set; }


        public LoginController()
        {
            AdministradorRepository = new AdministradoresRepository();

        }


        [HttpPost]
        public IActionResult Post(LoginViewModel login)
        {
            //Verifica se o usuario buscado está entre os médicos
            Administradores administradorBuscado = AdministradorRepository.BuscarPorNomeSenha(login.Nome, login.Senha);




            if (administradorBuscado != null)
            {
                //Define os dados que serão fornecidos no token - PayLoad
                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Email, administradorBuscado.Nome),
                    new Claim(JwtRegisteredClaimNames.Jti, administradorBuscado.Id.ToString()),
                    new Claim(ClaimTypes.Role, administradorBuscado.Nome.ToString(), administradorBuscado.Id.ToString(), "logado"),
                    new Claim("regra", administradorBuscado.Nome.ToString())

                };

                // Chave de acesso do token
                var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("pizzaria-chave-autenticacao"));

                //Credenciais do Token - Header
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                //Gera o token
                var token = new JwtSecurityToken(
                    issuer: "pizzaria",
                    audience: "pizzaria",
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(30),
                    signingCredentials: creds
                );

                //Retorna Ok com o Token
                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token)
                });

            }




            return BadRequest(new { mensagem = "Email ou senha inválido" });


        }

    }
}