﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Pizzaria.Domains;
using Pizzaria.Repositories;
using Senai.SPMedicalGroup.DatabaseFirst.Interfaces;

namespace Pizzaria.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdministradoresController : Controller
    {

        private IAdministradoresRepository AdministradorRepository { get; set; }

        public AdministradoresController()
        {
            AdministradorRepository = new AdministradoresRepository();
        }

        //Listar os Administradores
        
        [HttpGet]
        public IActionResult Get()
        {
            try
            {

                return Ok(AdministradorRepository.Listar());

            }

            catch
            {
                return BadRequest();
            }
        }

        //Adicionar Um Administrador
        [Authorize]
        [HttpPost]
        public IActionResult Post(Administradores administrador)
        {
            try
            {
                AdministradorRepository.Cadastrar(administrador);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest();
            }
        }



        //Modificar um Administrador
        [Authorize]
        [HttpPut()]
        public IActionResult Put(Administradores administrador)
        {

            AdministradorRepository.Editar(administrador);
            if (AdministradorRepository.Editar(administrador) == null) { return NotFound(); }
            return Ok();

        }

    }
}
