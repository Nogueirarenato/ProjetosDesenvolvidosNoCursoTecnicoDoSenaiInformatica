USE PIZZARIA


INSERT INTO PIZZARIAS (NOME, ENDERECO, TELEFONE, VEGANA, CATEGORIA )
VALUES  ('Saulo Pizzas',	'Rua Saulo, 171',	'11111-1111',	1, 'a')
		,('Fernando Pizzas',	'Rua Fernando, 272',	'22222-2222',	0, 'a')
		,('Helena Pizzas',	'Rua Helena, 373',	'33333-3333',	1, 'a')
		,('Renato Pizzas',	'Rua Renato, 474',	'44444-4444',	0, 'b')

