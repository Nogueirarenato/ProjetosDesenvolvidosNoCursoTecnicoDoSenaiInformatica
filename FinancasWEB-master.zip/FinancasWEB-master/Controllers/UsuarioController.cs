using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using Senai.Financas.Web.Mvc.Models;

namespace Senai.Financas.Web.Mvc.Controllers
{
   
   
    public class UsuarioController : Controller
    {
            [HttpGet]
            public ActionResult Cadastrar(){

                return View();
        }
    
        [HttpPost]
        public ActionResult Cadastrar(IFormCollection form){

            Models.UsuarioModel usuario =new Models.UsuarioModel();
            usuario.Nome = form ["nome"];
            usuario.Email =form ["email"];
            usuario.Senha=form["senha"];
            usuario.DataNascimento=DateTime.Parse(form["dataNascimento"]);

            using(StreamWriter sw = new StreamWriter("usuario.csv", true) ){
                sw.WriteLine($"{usuario.Nome};{usuario.Email};{usuario.Senha};{usuario.DataNascimento};");
            }


            

            ViewBag.Mensagem = "Usuário Cadastrado";

            return View();
        }

        [HttpGet]

        public IActionResult Login(){
            return View();
        }

        [HttpPost]

        public IActionResult Login (IFormCollection form){
            UsuarioModel usuario = new UsuarioModel();
            usuario.Email =form["email"];
            usuario.Senha = form["senha"];

            using(StreamReader sr = new StreamReader("usuario.csv")){
                while(!sr.EndOfStream){
                    string [] linha = sr.ReadLine().Split(";");
                    if(linha[1]== usuario.Email && linha[2]==usuario.Senha){
                        HttpContext.Session.SetString("emailUsuario", usuario.Email);
                        return RedirectToAction("Cadastrar","Transacao");
                    }
                }

            }

            ViewBag.Mensagem ="Usuário Inválido";
            return View();
        }
    
    }
}